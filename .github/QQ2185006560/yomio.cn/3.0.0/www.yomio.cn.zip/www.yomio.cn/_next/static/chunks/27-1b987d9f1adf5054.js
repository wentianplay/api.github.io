(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [27], {
        325: function(t, e, r) {
            "use strict";
            r.d(e, {
                Au: function() {
                    return o
                },
                G3: function() {
                    return g
                },
                Ki: function() {
                    return u
                },
                d3: function() {
                    return p
                },
                hL: function() {
                    return f
                },
                lx: function() {
                    return m
                },
                qX: function() {
                    return d
                },
                tm: function() {
                    return h
                }
            });
            var n, i, s = r(6076),
                a = r.n(s),
                o = function(t) {
                    return "function" === ArrayBuffer.isView ? ArrayBuffer.isView(t) : t && t.buffer instanceof ArrayBuffer
                },
                u = function(t) {
                    return t instanceof Uint8Array ? t : (Array.isArray(t) || o(t) || t instanceof ArrayBuffer || (t = "number" != typeof t || "number" == typeof t && t != t ? 0 : [t]), new Uint8Array(t && t.buffer || t, t && t.byteOffset || 0, t && t.byteLength || 0))
                },
                l = a().BigInt || Number,
                c = [l("0x1"), l("0x100"), l("0x10000"), l("0x1000000"), l("0x100000000"), l("0x10000000000"), l("0x1000000000000"), l("0x100000000000000"), l("0x10000000000000000")];
            255 === (i = new Uint8Array((n = new Uint16Array([65484])).buffer, n.byteOffset, n.byteLength))[0] || i[0];
            var h = function(t, e) {
                    var r = void 0 === e ? {} : e,
                        n = r.signed,
                        i = r.le,
                        s = void 0 !== i && i;
                    t = u(t);
                    var a = s ? "reduce" : "reduceRight",
                        o = (t[a] ? t[a] : Array.prototype[a]).call(t, function(e, r, n) {
                            var i = s ? n : Math.abs(n + 1 - t.length);
                            return e + l(r) * c[i]
                        }, l(0));
                    if (void 0 !== n && n) {
                        var h = c[t.length] / l(2) - l(1);
                        (o = l(o)) > h && (o -= h, o -= h, o -= l(2))
                    }
                    return Number(o)
                },
                f = function(t, e) {
                    var r = (void 0 === e ? {} : e).le,
                        n = void 0 !== r && r;
                    ("bigint" != typeof t && "number" != typeof t || "number" == typeof t && t != t) && (t = 0);
                    for (var i = Math.ceil((t = l(t)).toString(2).length / 8), s = new Uint8Array(new ArrayBuffer(i)), a = 0; a < i; a++) {
                        var o = n ? a : Math.abs(a + 1 - s.length);
                        s[o] = Number(t / c[a] & l(255)), t < 0 && (s[o] = Math.abs(~s[o]), s[o] -= 0 === a ? 1 : 2)
                    }
                    return s
                },
                p = function(t) {
                    if (!t) return "";
                    t = Array.prototype.slice.call(t);
                    var e = String.fromCharCode.apply(null, u(t));
                    try {
                        return decodeURIComponent(escape(e))
                    } catch (t) {}
                    return e
                },
                d = function(t, e) {
                    if ("string" != typeof t && t && "function" == typeof t.toString && (t = t.toString()), "string" != typeof t) return new Uint8Array;
                    e || (t = unescape(encodeURIComponent(t)));
                    for (var r = new Uint8Array(t.length), n = 0; n < t.length; n++) r[n] = t.charCodeAt(n);
                    return r
                },
                m = function() {
                    for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                    if ((e = e.filter(function(t) {
                            return t && (t.byteLength || t.length) && "string" != typeof t
                        })).length <= 1) return u(e[0]);
                    var n = new Uint8Array(e.reduce(function(t, e, r) {
                            return t + (e.byteLength || e.length)
                        }, 0)),
                        i = 0;
                    return e.forEach(function(t) {
                        t = u(t), n.set(t, i), i += t.byteLength
                    }), n
                },
                g = function(t, e, r) {
                    var n = void 0 === r ? {} : r,
                        i = n.offset,
                        s = void 0 === i ? 0 : i,
                        a = n.mask,
                        o = void 0 === a ? [] : a;
                    t = u(t);
                    var l = (e = u(e)).every ? e.every : Array.prototype.every;
                    return e.length && t.length - s >= e.length && l.call(e, function(e, r) {
                        return e === (o[r] ? o[r] & t[s + r] : t[s + r])
                    })
                }
        },
        2352: function(t, e, r) {
            "use strict";
            r.d(e, {
                Hi: function() {
                    return d
                },
                Jg: function() {
                    return c
                },
                KL: function() {
                    return h
                },
                _5: function() {
                    return f
                },
                kS: function() {
                    return l
                },
                lA: function() {
                    return m
                },
                p7: function() {
                    return p
                },
                ws: function() {
                    return u
                },
                xz: function() {
                    return g
                }
            });
            var n = r(6076),
                i = r.n(n),
                s = {
                    mp4: /^(av0?1|avc0?[1234]|vp0?9|flac|opus|mp3|mp4a|mp4v|stpp.ttml.im1t)/,
                    webm: /^(vp0?[89]|av0?1|opus|vorbis)/,
                    ogg: /^(vp0?[89]|theora|flac|opus|vorbis)/,
                    video: /^(av0?1|avc0?[1234]|vp0?[89]|hvc1|hev1|theora|mp4v)/,
                    audio: /^(mp4a|flac|vorbis|opus|ac-[34]|ec-3|alac|mp3|speex|aac)/,
                    text: /^(stpp.ttml.im1t)/,
                    muxerVideo: /^(avc0?1)/,
                    muxerAudio: /^(mp4a)/,
                    muxerText: /a^/
                },
                a = ["video", "audio", "text"],
                o = ["Video", "Audio", "Text"],
                u = function(t) {
                    return t ? t.replace(/avc1\.(\d+)\.(\d+)/i, function(t, e, r) {
                        return "avc1." + ("00" + Number(e).toString(16)).slice(-2) + "00" + ("00" + Number(r).toString(16)).slice(-2)
                    }) : t
                },
                l = function(t) {
                    void 0 === t && (t = "");
                    var e = t.split(","),
                        r = [];
                    return e.forEach(function(t) {
                        var e;
                        t = t.trim(), a.forEach(function(n) {
                            var i = s[n].exec(t.toLowerCase());
                            if (i && !(i.length <= 1)) {
                                e = n;
                                var a = t.substring(0, i[1].length),
                                    o = t.replace(a, "");
                                r.push({
                                    type: a,
                                    details: o,
                                    mediaType: n
                                })
                            }
                        }), e || r.push({
                            type: t,
                            details: "",
                            mediaType: "unknown"
                        })
                    }), r
                },
                c = function(t, e) {
                    if (!t.mediaGroups.AUDIO || !e) return null;
                    var r = t.mediaGroups.AUDIO[e];
                    if (!r) return null;
                    for (var n in r) {
                        var i = r[n];
                        if (i.default && i.playlists) return l(i.playlists[0].attributes.CODECS)
                    }
                    return null
                },
                h = function(t) {
                    return void 0 === t && (t = ""), s.audio.test(t.trim().toLowerCase())
                },
                f = function(t) {
                    if (t && "string" == typeof t) {
                        var e, r = t.toLowerCase().split(",").map(function(t) {
                                return u(t.trim())
                            }),
                            n = "video";
                        1 === r.length && h(r[0]) ? n = "audio" : 1 === r.length && (void 0 === (e = r[0]) && (e = ""), s.text.test(e.trim().toLowerCase())) && (n = "application");
                        var i = "mp4";
                        return r.every(function(t) {
                            return s.mp4.test(t)
                        }) ? i = "mp4" : r.every(function(t) {
                            return s.webm.test(t)
                        }) ? i = "webm" : r.every(function(t) {
                            return s.ogg.test(t)
                        }) && (i = "ogg"), n + "/" + i + ';codecs="' + t + '"'
                    }
                },
                p = function(t) {
                    return void 0 === t && (t = ""), i().MediaSource && i().MediaSource.isTypeSupported && i().MediaSource.isTypeSupported(f(t)) || !1
                },
                d = function(t) {
                    return void 0 === t && (t = ""), t.toLowerCase().split(",").every(function(t) {
                        t = t.trim();
                        for (var e = 0; e < o.length; e++)
                            if (s["muxer" + o[e]].test(t)) return !0;
                        return !1
                    })
                },
                m = "mp4a.40.2",
                g = "avc1.4d400d"
        },
        1040: function(t, e, r) {
            "use strict";
            r.d(e, {
                Xm: function() {
                    return x
                },
                cz: function() {
                    return S
                }
            });
            var n, i = r(325);
            new Uint8Array([79, 112, 117, 115, 72, 101, 97, 100]);
            var s = function(t) {
                    return "string" == typeof t ? (0, i.qX)(t) : t
                },
                a = function(t) {
                    t = (0, i.Ki)(t);
                    for (var e = [], r = 0; t.length > r;) {
                        var s = t[r],
                            a = 0,
                            o = 0,
                            u = t[++o];
                        for (o++; 128 & u;) a = (127 & u) << 7, u = t[o], o++;
                        a += 127 & u;
                        for (var l = 0; l < n.length; l++) {
                            var c = n[l],
                                h = c.id,
                                f = c.parser;
                            if (s === h) {
                                e.push(f(t.subarray(o, o + a)));
                                break
                            }
                        }
                        r += a + o
                    }
                    return e
                };
            n = [{
                id: 3,
                parser: function(t) {
                    var e = {
                        tag: 3,
                        id: t[0] << 8 | t[1],
                        flags: t[2],
                        size: 3,
                        dependsOnEsId: 0,
                        ocrEsId: 0,
                        descriptors: [],
                        url: ""
                    };
                    if (128 & e.flags && (e.dependsOnEsId = t[e.size] << 8 | t[e.size + 1], e.size += 2), 64 & e.flags) {
                        var r = t[e.size];
                        e.url = (0, i.d3)(t.subarray(e.size + 1, e.size + 1 + r)), e.size += r
                    }
                    return 32 & e.flags && (e.ocrEsId = t[e.size] << 8 | t[e.size + 1], e.size += 2), e.descriptors = a(t.subarray(e.size)) || [], e
                }
            }, {
                id: 4,
                parser: function(t) {
                    return {
                        tag: 4,
                        oti: t[0],
                        streamType: t[1],
                        bufferSize: t[2] << 16 | t[3] << 8 | t[4],
                        maxBitrate: t[5] << 24 | t[6] << 16 | t[7] << 8 | t[8],
                        avgBitrate: t[9] << 24 | t[10] << 16 | t[11] << 8 | t[12],
                        descriptors: a(t.subarray(13))
                    }
                }
            }, {
                id: 5,
                parser: function(t) {
                    return {
                        tag: 5,
                        bytes: t
                    }
                }
            }, {
                id: 6,
                parser: function(t) {
                    return {
                        tag: 6,
                        bytes: t
                    }
                }
            }];
            var o = function t(e, r, n) {
                    void 0 === n && (n = !1), r = Array.isArray(a = r) ? a.map(function(t) {
                        return s(t)
                    }) : [s(a)], e = (0, i.Ki)(e);
                    var a, o = [];
                    if (!r.length) return o;
                    for (var u = 0; u < e.length;) {
                        var l = (e[u] << 24 | e[u + 1] << 16 | e[u + 2] << 8 | e[u + 3]) >>> 0,
                            c = e.subarray(u + 4, u + 8);
                        if (0 === l) break;
                        var h = u + l;
                        if (h > e.length) {
                            if (n) break;
                            h = e.length
                        }
                        var f = e.subarray(u + 8, h);
                        (0, i.G3)(c, r[0]) && (1 === r.length ? o.push(f) : o.push.apply(o, t(f, r.slice(1), n))), u = h
                    }
                    return o
                },
                u = {
                    EBML: (0, i.Ki)([26, 69, 223, 163]),
                    DocType: (0, i.Ki)([66, 130]),
                    Segment: (0, i.Ki)([24, 83, 128, 103]),
                    SegmentInfo: (0, i.Ki)([21, 73, 169, 102]),
                    Tracks: (0, i.Ki)([22, 84, 174, 107]),
                    Track: (0, i.Ki)([174]),
                    TrackNumber: (0, i.Ki)([215]),
                    DefaultDuration: (0, i.Ki)([35, 227, 131]),
                    TrackEntry: (0, i.Ki)([174]),
                    TrackType: (0, i.Ki)([131]),
                    FlagDefault: (0, i.Ki)([136]),
                    CodecID: (0, i.Ki)([134]),
                    CodecPrivate: (0, i.Ki)([99, 162]),
                    VideoTrack: (0, i.Ki)([224]),
                    AudioTrack: (0, i.Ki)([225]),
                    Cluster: (0, i.Ki)([31, 67, 182, 117]),
                    Timestamp: (0, i.Ki)([231]),
                    TimestampScale: (0, i.Ki)([42, 215, 177]),
                    BlockGroup: (0, i.Ki)([160]),
                    BlockDuration: (0, i.Ki)([155]),
                    Block: (0, i.Ki)([161]),
                    SimpleBlock: (0, i.Ki)([163])
                },
                l = [128, 64, 32, 16, 8, 4, 2, 1],
                c = function(t) {
                    for (var e = 1, r = 0; r < l.length && !(t & l[r]); r++) e++;
                    return e
                },
                h = function(t, e, r, n) {
                    void 0 === r && (r = !0), void 0 === n && (n = !1);
                    var s = c(t[e]),
                        a = t.subarray(e, e + s);
                    return r && (a = Array.prototype.slice.call(t, e, e + s), a[0] ^= l[s - 1]), {
                        length: s,
                        value: (0, i.tm)(a, {
                            signed: n
                        }),
                        bytes: a
                    }
                },
                f = function t(e) {
                    return "string" == typeof e ? e.match(/.{1,2}/g).map(function(e) {
                        return t(e)
                    }) : "number" == typeof e ? (0, i.hL)(e) : e
                },
                p = function t(e, r, n) {
                    if (n >= r.length) return r.length;
                    var s = h(r, n, !1);
                    if ((0, i.G3)(e.bytes, s.bytes)) return n;
                    var a = h(r, n + s.length);
                    return t(e, r, n + a.length + a.value + s.length)
                },
                d = function t(e, r) {
                    r = Array.isArray(n = r) ? n.map(function(t) {
                        return f(t)
                    }) : [f(n)], e = (0, i.Ki)(e);
                    var n, s = [];
                    if (!r.length) return s;
                    for (var a = 0; a < e.length;) {
                        var o = h(e, a, !1),
                            u = h(e, a + o.length),
                            l = a + o.length + u.length;
                        127 === u.value && (u.value = p(o, e, l), u.value !== e.length && (u.value -= l));
                        var c = l + u.value > e.length ? e.length : l + u.value,
                            d = e.subarray(l, c);
                        (0, i.G3)(r[0], o.bytes) && (1 === r.length ? s.push(d) : s = s.concat(t(d, r.slice(1)))), a += o.length + u.length + d.length
                    }
                    return s
                },
                m = r(4842),
                g = (0, i.Ki)([0, 0, 0, 1]),
                y = (0, i.Ki)([0, 0, 1]),
                v = (0, i.Ki)([0, 0, 3]),
                b = function(t) {
                    for (var e = [], r = 1; r < t.length - 2;)(0, i.G3)(t.subarray(r, r + 3), v) && (e.push(r + 2), r++), r++;
                    if (0 === e.length) return t;
                    var n = t.length - e.length,
                        s = new Uint8Array(n),
                        a = 0;
                    for (r = 0; r < n; a++, r++) a === e[0] && (a++, e.shift()), s[r] = t[a];
                    return s
                },
                E = function(t, e, r, n) {
                    void 0 === n && (n = 1 / 0), t = (0, i.Ki)(t), r = [].concat(r);
                    for (var s, a = 0, o = 0; a < t.length && (o < n || s);) {
                        var u = void 0;
                        if ((0, i.G3)(t.subarray(a), g) ? u = 4 : (0, i.G3)(t.subarray(a), y) && (u = 3), !u) {
                            a++;
                            continue
                        }
                        if (o++, s) return b(t.subarray(s, a));
                        var l = void 0;
                        "h264" === e ? l = 31 & t[a + u] : "h265" === e && (l = t[a + u] >> 1 & 63), -1 !== r.indexOf(l) && (s = a + u), a += u + ("h264" === e ? 1 : 2)
                    }
                    return t.subarray(0, 0)
                },
                w = {
                    webm: (0, i.Ki)([119, 101, 98, 109]),
                    matroska: (0, i.Ki)([109, 97, 116, 114, 111, 115, 107, 97]),
                    flac: (0, i.Ki)([102, 76, 97, 67]),
                    ogg: (0, i.Ki)([79, 103, 103, 83]),
                    ac3: (0, i.Ki)([11, 119]),
                    riff: (0, i.Ki)([82, 73, 70, 70]),
                    avi: (0, i.Ki)([65, 86, 73]),
                    wav: (0, i.Ki)([87, 65, 86, 69]),
                    "3gp": (0, i.Ki)([102, 116, 121, 112, 51, 103]),
                    mp4: (0, i.Ki)([102, 116, 121, 112]),
                    fmp4: (0, i.Ki)([115, 116, 121, 112]),
                    mov: (0, i.Ki)([102, 116, 121, 112, 113, 116]),
                    moov: (0, i.Ki)([109, 111, 111, 118]),
                    moof: (0, i.Ki)([109, 111, 111, 102])
                },
                T = {
                    aac: function(t) {
                        var e = (0, m.c)(t);
                        return (0, i.G3)(t, [255, 16], {
                            offset: e,
                            mask: [255, 22]
                        })
                    },
                    mp3: function(t) {
                        var e = (0, m.c)(t);
                        return (0, i.G3)(t, [255, 2], {
                            offset: e,
                            mask: [255, 6]
                        })
                    },
                    webm: function(t) {
                        var e = d(t, [u.EBML, u.DocType])[0];
                        return (0, i.G3)(e, w.webm)
                    },
                    mkv: function(t) {
                        var e = d(t, [u.EBML, u.DocType])[0];
                        return (0, i.G3)(e, w.matroska)
                    },
                    mp4: function(t) {
                        return !(T["3gp"](t) || T.mov(t)) && (!!((0, i.G3)(t, w.mp4, {
                            offset: 4
                        }) || (0, i.G3)(t, w.fmp4, {
                            offset: 4
                        }) || (0, i.G3)(t, w.moof, {
                            offset: 4
                        }) || (0, i.G3)(t, w.moov, {
                            offset: 4
                        })) || void 0)
                    },
                    mov: function(t) {
                        return (0, i.G3)(t, w.mov, {
                            offset: 4
                        })
                    },
                    "3gp": function(t) {
                        return (0, i.G3)(t, w["3gp"], {
                            offset: 4
                        })
                    },
                    ac3: function(t) {
                        var e = (0, m.c)(t);
                        return (0, i.G3)(t, w.ac3, {
                            offset: e
                        })
                    },
                    ts: function(t) {
                        if (t.length < 189 && t.length >= 1) return 71 === t[0];
                        for (var e = 0; e + 188 < t.length && e < 188;) {
                            if (71 === t[e] && 71 === t[e + 188]) return !0;
                            e += 1
                        }
                        return !1
                    },
                    flac: function(t) {
                        var e = (0, m.c)(t);
                        return (0, i.G3)(t, w.flac, {
                            offset: e
                        })
                    },
                    ogg: function(t) {
                        return (0, i.G3)(t, w.ogg)
                    },
                    avi: function(t) {
                        return (0, i.G3)(t, w.riff) && (0, i.G3)(t, w.avi, {
                            offset: 8
                        })
                    },
                    wav: function(t) {
                        return (0, i.G3)(t, w.riff) && (0, i.G3)(t, w.wav, {
                            offset: 8
                        })
                    },
                    h264: function(t) {
                        return E(t, "h264", 7, 3).length
                    },
                    h265: function(t) {
                        return E(t, "h265", [32, 33], 3).length
                    }
                },
                D = Object.keys(T).filter(function(t) {
                    return "ts" !== t && "h264" !== t && "h265" !== t
                }).concat(["ts", "h264", "h265"]);
            D.forEach(function(t) {
                var e = T[t];
                T[t] = function(t) {
                    return e((0, i.Ki)(t))
                }
            });
            var x = function(t) {
                    t = (0, i.Ki)(t);
                    for (var e = 0; e < D.length; e++) {
                        var r = D[e];
                        if (T[r](t)) return r
                    }
                    return ""
                },
                S = function(t) {
                    return o(t, ["moof"]).length > 0
                }
        },
        4842: function(t, e, r) {
            "use strict";
            r.d(e, {
                c: function() {
                    return a
                }
            });
            var n = r(325),
                i = (0, n.Ki)([73, 68, 51]),
                s = function(t, e) {
                    void 0 === e && (e = 0);
                    var r = (t = (0, n.Ki)(t))[e + 5],
                        i = t[e + 6] << 21 | t[e + 7] << 14 | t[e + 8] << 7 | t[e + 9];
                    return (16 & r) >> 4 ? i + 20 : i + 10
                },
                a = function t(e, r) {
                    return (void 0 === r && (r = 0), (e = (0, n.Ki)(e)).length - r < 10 || !(0, n.G3)(e, i, {
                        offset: r
                    })) ? r : (r += s(e, r), t(e, r))
                }
        },
        3712: function(t, e, r) {
            "use strict";
            r.d(e, {
                t: function() {
                    return s
                }
            });
            var n = /^(audio|video|application)\/(x-|vnd\.apple\.)?mpegurl/i,
                i = /^application\/dash\+xml/i,
                s = function(t) {
                    return n.test(t) ? "hls" : i.test(t) ? "dash" : "application/vnd.videojs.vhs+json" === t ? "vhs-json" : null
                }
        },
        150: function(t, e, r) {
            "use strict";
            var n = r(3029),
                i = r.n(n),
                s = r(6076),
                a = r.n(s),
                o = "http://example.com";
            e.Z = function(t, e) {
                if (/^[a-z]+:/i.test(e)) return e;
                /^data:/.test(t) && (t = a().location && a().location.href || "");
                var r = "function" == typeof a().URL,
                    n = /^\/\//.test(t),
                    s = !a().location && !/\/\//i.test(t);
                if (r ? t = new(a()).URL(t, a().location || o) : /\/\//i.test(t) || (t = i().buildAbsoluteURL(a().location && a().location.href || "", t)), r) {
                    var u = new URL(e, t);
                    return s ? u.href.slice(o.length) : n ? u.href.slice(u.protocol.length) : u.href
                }
                return i().buildAbsoluteURL(t, e)
            }
        },
        8019: function(t, e, r) {
            "use strict";
            var n = r(6076);
            t.exports = function(t, e) {
                return void 0 === e && (e = !1),
                    function(r, i, s) {
                        if (r) {
                            t(r);
                            return
                        }
                        if (i.statusCode >= 400 && i.statusCode <= 599) {
                            var a = s;
                            if (e) {
                                if (n.TextDecoder) {
                                    var o, u = (void 0 === (o = i.headers && i.headers["content-type"]) && (o = ""), o.toLowerCase().split(";").reduce(function(t, e) {
                                        var r = e.split("="),
                                            n = r[0],
                                            i = r[1];
                                        return "charset" === n.trim() ? i.trim() : t
                                    }, "utf-8"));
                                    try {
                                        a = new TextDecoder(u).decode(s)
                                    } catch (t) {}
                                } else a = String.fromCharCode.apply(null, new Uint8Array(s))
                            }
                            t({
                                cause: a
                            });
                            return
                        }
                        t(null, s)
                    }
            }
        },
        4639: function(t, e, r) {
            "use strict";
            var n = r(6076),
                i = r(5380),
                s = r(4361);
            u.httpHandler = r(8019);
            /**
             * @license
             * slighly modified parse-headers 2.0.2 <https://github.com/kesla/parse-headers/>
             * Copyright (c) 2014 David Björklund
             * Available under the MIT license
             * <https://github.com/kesla/parse-headers/blob/master/LICENCE>
             */
            var a = function(t) {
                var e = {};
                return t && t.trim().split("\n").forEach(function(t) {
                    var r = t.indexOf(":"),
                        n = t.slice(0, r).trim().toLowerCase(),
                        i = t.slice(r + 1).trim();
                    void 0 === e[n] ? e[n] = i : Array.isArray(e[n]) ? e[n].push(i) : e[n] = [e[n], i]
                }), e
            };

            function o(t, e, r) {
                var n = t;
                return s(e) ? (r = e, "string" == typeof t && (n = {
                    uri: t
                })) : n = i({}, e, {
                    uri: t
                }), n.callback = r, n
            }

            function u(t, e, r) {
                return l(e = o(t, e, r))
            }

            function l(t) {
                if (void 0 === t.callback) throw Error("callback argument missing");
                var e, r, n, i = !1,
                    s = function(e, r, n) {
                        i || (i = !0, t.callback(e, r, n))
                    };

                function o(t) {
                    return clearTimeout(n), t instanceof Error || (t = Error("" + (t || "Unknown XMLHttpRequest Error"))), t.statusCode = 0, s(t, y)
                }

                function l() {
                    if (!r) {
                        clearTimeout(n);
                        var e, i = y,
                            o = null;
                        return 0 !== (e = t.useXDR && void 0 === c.status ? 200 : 1223 === c.status ? 204 : c.status) ? (i = {
                            body: function() {
                                var t = void 0;
                                if (t = c.response ? c.response : c.responseText || function(t) {
                                        try {
                                            if ("document" === t.responseType) return t.responseXML;
                                            var e = t.responseXML && "parsererror" === t.responseXML.documentElement.nodeName;
                                            if ("" === t.responseType && !e) return t.responseXML
                                        } catch (t) {}
                                        return null
                                    }(c), g) try {
                                    t = JSON.parse(t)
                                } catch (t) {}
                                return t
                            }(),
                            statusCode: e,
                            method: f,
                            headers: {},
                            url: h,
                            rawRequest: c
                        }, c.getAllResponseHeaders && (i.headers = a(c.getAllResponseHeaders()))) : o = Error("Internal XMLHttpRequest Error"), s(o, i, i.body)
                    }
                }
                var c = t.xhr || null;
                c || (c = t.cors || t.useXDR ? new u.XDomainRequest : new u.XMLHttpRequest);
                var h = c.url = t.uri || t.url,
                    f = c.method = t.method || "GET",
                    p = t.body || t.data,
                    d = c.headers = t.headers || {},
                    m = !!t.sync,
                    g = !1,
                    y = {
                        body: void 0,
                        headers: {},
                        statusCode: 0,
                        method: f,
                        url: h,
                        rawRequest: c
                    };
                if ("json" in t && !1 !== t.json && (g = !0, d.accept || d.Accept || (d.Accept = "application/json"), "GET" !== f && "HEAD" !== f && (d["content-type"] || d["Content-Type"] || (d["Content-Type"] = "application/json"), p = JSON.stringify(!0 === t.json ? p : t.json))), c.onreadystatechange = function() {
                        4 === c.readyState && setTimeout(l, 0)
                    }, c.onload = l, c.onerror = o, c.onprogress = function() {}, c.onabort = function() {
                        r = !0
                    }, c.ontimeout = o, c.open(f, h, !m, t.username, t.password), m || (c.withCredentials = !!t.withCredentials), !m && t.timeout > 0 && (n = setTimeout(function() {
                        if (!r) {
                            r = !0, c.abort("timeout");
                            var t = Error("XMLHttpRequest timeout");
                            t.code = "ETIMEDOUT", o(t)
                        }
                    }, t.timeout)), c.setRequestHeader)
                    for (e in d) d.hasOwnProperty(e) && c.setRequestHeader(e, d[e]);
                else if (t.headers && ! function(t) {
                        for (var e in t)
                            if (t.hasOwnProperty(e)) return !1;
                        return !0
                    }(t.headers)) throw Error("Headers cannot be set on an XDomainRequest object");
                return "responseType" in t && (c.responseType = t.responseType), "beforeSend" in t && "function" == typeof t.beforeSend && t.beforeSend(c), c.send(p || null), c
            }
            t.exports = u, t.exports.default = u, u.XMLHttpRequest = n.XMLHttpRequest || function() {}, u.XDomainRequest = "withCredentials" in new u.XMLHttpRequest ? u.XMLHttpRequest : n.XDomainRequest,
                function(t, e) {
                    for (var r = 0; r < t.length; r++) e(t[r])
                }(["get", "put", "post", "patch", "head", "delete"], function(t) {
                    u["delete" === t ? "del" : t] = function(e, r, n) {
                        return (r = o(e, r, n)).method = t.toUpperCase(), l(r)
                    }
                })
        },
        1461: function(t, e) {
            "use strict";

            function r(t, e) {
                return void 0 === e && (e = Object), e && "function" == typeof e.freeze ? e.freeze(t) : t
            }
            var n = r({
                    HTML: "text/html",
                    isHTML: function(t) {
                        return t === n.HTML
                    },
                    XML_APPLICATION: "application/xml",
                    XML_TEXT: "text/xml",
                    XML_XHTML_APPLICATION: "application/xhtml+xml",
                    XML_SVG_IMAGE: "image/svg+xml"
                }),
                i = r({
                    HTML: "http://www.w3.org/1999/xhtml",
                    isHTML: function(t) {
                        return t === i.HTML
                    },
                    SVG: "http://www.w3.org/2000/svg",
                    XML: "http://www.w3.org/XML/1998/namespace",
                    XMLNS: "http://www.w3.org/2000/xmlns/"
                });
            e.assign = function(t, e) {
                if (null === t || "object" != typeof t) throw TypeError("target is not an object");
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return t
            }, e.find = function(t, e, r) {
                if (void 0 === r && (r = Array.prototype), t && "function" == typeof r.find) return r.find.call(t, e);
                for (var n = 0; n < t.length; n++)
                    if (Object.prototype.hasOwnProperty.call(t, n)) {
                        var i = t[n];
                        if (e.call(void 0, i, n, t)) return i
                    }
            }, e.freeze = r, e.MIME_TYPE = n, e.NAMESPACE = i
        },
        505: function(t, e, r) {
            var n = r(1461),
                i = r(2556),
                s = r(43),
                a = r(4465),
                o = i.DOMImplementation,
                u = n.NAMESPACE,
                l = a.ParseError,
                c = a.XMLReader;

            function h(t) {
                return t.replace(/\r[\n\u0085]/g, "\n").replace(/[\r\u0085\u2028]/g, "\n")
            }

            function f(t) {
                this.options = t || {
                    locator: {}
                }
            }

            function p() {
                this.cdata = !1
            }

            function d(t, e) {
                e.lineNumber = t.lineNumber, e.columnNumber = t.columnNumber
            }

            function m(t) {
                if (t) return "\n@" + (t.systemId || "") + "#[line:" + t.lineNumber + ",col:" + t.columnNumber + "]"
            }

            function g(t, e, r) {
                return "string" == typeof t ? t.substr(e, r) : t.length >= e + r || e ? new java.lang.String(t, e, r) + "" : t
            }

            function y(t, e) {
                t.currentElement ? t.currentElement.appendChild(e) : t.doc.appendChild(e)
            }
            f.prototype.parseFromString = function(t, e) {
                var r = this.options,
                    n = new c,
                    i = r.domBuilder || new p,
                    a = r.errorHandler,
                    o = r.locator,
                    l = r.xmlns || {},
                    f = /\/x?html?$/.test(e),
                    d = f ? s.HTML_ENTITIES : s.XML_ENTITIES;
                o && i.setDocumentLocator(o), n.errorHandler = function(t, e, r) {
                    if (!t) {
                        if (e instanceof p) return e;
                        t = e
                    }
                    var n = {},
                        i = t instanceof Function;

                    function s(e) {
                        var s = t[e];
                        !s && i && (s = 2 == t.length ? function(r) {
                            t(e, r)
                        } : t), n[e] = s && function(t) {
                            s("[xmldom " + e + "]	" + t + m(r))
                        } || function() {}
                    }
                    return r = r || {}, s("warning"), s("error"), s("fatalError"), n
                }(a, i, o), n.domBuilder = r.domBuilder || i, f && (l[""] = u.HTML), l.xml = l.xml || u.XML;
                var g = r.normalizeLineEndings || h;
                return t && "string" == typeof t ? n.parse(g(t), l, d) : n.errorHandler.error("invalid doc source"), i.doc
            }, p.prototype = {
                startDocument: function() {
                    this.doc = new o().createDocument(null, null, null), this.locator && (this.doc.documentURI = this.locator.systemId)
                },
                startElement: function(t, e, r, n) {
                    var i = this.doc,
                        s = i.createElementNS(t, r || e),
                        a = n.length;
                    y(this, s), this.currentElement = s, this.locator && d(this.locator, s);
                    for (var o = 0; o < a; o++) {
                        var t = n.getURI(o),
                            u = n.getValue(o),
                            r = n.getQName(o),
                            l = i.createAttributeNS(t, r);
                        this.locator && d(n.getLocator(o), l), l.value = l.nodeValue = u, s.setAttributeNode(l)
                    }
                },
                endElement: function(t, e, r) {
                    var n = this.currentElement;
                    n.tagName, this.currentElement = n.parentNode
                },
                startPrefixMapping: function(t, e) {},
                endPrefixMapping: function(t) {},
                processingInstruction: function(t, e) {
                    var r = this.doc.createProcessingInstruction(t, e);
                    this.locator && d(this.locator, r), y(this, r)
                },
                ignorableWhitespace: function(t, e, r) {},
                characters: function(t, e, r) {
                    if (t = g.apply(this, arguments)) {
                        if (this.cdata) var n = this.doc.createCDATASection(t);
                        else var n = this.doc.createTextNode(t);
                        this.currentElement ? this.currentElement.appendChild(n) : /^\s*$/.test(t) && this.doc.appendChild(n), this.locator && d(this.locator, n)
                    }
                },
                skippedEntity: function(t) {},
                endDocument: function() {
                    this.doc.normalize()
                },
                setDocumentLocator: function(t) {
                    (this.locator = t) && (t.lineNumber = 0)
                },
                comment: function(t, e, r) {
                    t = g.apply(this, arguments);
                    var n = this.doc.createComment(t);
                    this.locator && d(this.locator, n), y(this, n)
                },
                startCDATA: function() {
                    this.cdata = !0
                },
                endCDATA: function() {
                    this.cdata = !1
                },
                startDTD: function(t, e, r) {
                    var n = this.doc.implementation;
                    if (n && n.createDocumentType) {
                        var i = n.createDocumentType(t, e, r);
                        this.locator && d(this.locator, i), y(this, i), this.doc.doctype = i
                    }
                },
                warning: function(t) {
                    console.warn("[xmldom warning]	" + t, m(this.locator))
                },
                error: function(t) {
                    console.error("[xmldom error]	" + t, m(this.locator))
                },
                fatalError: function(t) {
                    throw new l(t, this.locator)
                }
            }, "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g, function(t) {
                p.prototype[t] = function() {
                    return null
                }
            }), e.DOMParser = f
        },
        2556: function(t, e, r) {
            var n = r(1461),
                i = n.find,
                s = n.NAMESPACE;

            function a(t) {
                return "" !== t
            }

            function o(t, e) {
                return t.hasOwnProperty(e) || (t[e] = !0), t
            }

            function u(t) {
                return t ? Object.keys((t ? t.split(/[\t\n\f\r ]+/).filter(a) : []).reduce(o, {})) : []
            }

            function l(t, e) {
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
            }

            function c(t, e) {
                var r = t.prototype;
                if (!(r instanceof e)) {
                    function n() {}
                    n.prototype = e.prototype, l(r, n = new n), t.prototype = r = n
                }
                r.constructor != t && ("function" != typeof t && console.error("unknown Class:" + t), r.constructor = t)
            }
            var h = {},
                f = h.ELEMENT_NODE = 1,
                p = h.ATTRIBUTE_NODE = 2,
                d = h.TEXT_NODE = 3,
                m = h.CDATA_SECTION_NODE = 4,
                g = h.ENTITY_REFERENCE_NODE = 5,
                y = h.ENTITY_NODE = 6,
                v = h.PROCESSING_INSTRUCTION_NODE = 7,
                b = h.COMMENT_NODE = 8,
                E = h.DOCUMENT_NODE = 9,
                w = h.DOCUMENT_TYPE_NODE = 10,
                T = h.DOCUMENT_FRAGMENT_NODE = 11,
                D = h.NOTATION_NODE = 12,
                x = {},
                S = {};
            x.INDEX_SIZE_ERR = (S[1] = "Index size error", 1), x.DOMSTRING_SIZE_ERR = (S[2] = "DOMString size error", 2);
            var A = x.HIERARCHY_REQUEST_ERR = (S[3] = "Hierarchy request error", 3);
            x.WRONG_DOCUMENT_ERR = (S[4] = "Wrong document", 4), x.INVALID_CHARACTER_ERR = (S[5] = "Invalid character", 5), x.NO_DATA_ALLOWED_ERR = (S[6] = "No data allowed", 6), x.NO_MODIFICATION_ALLOWED_ERR = (S[7] = "No modification allowed", 7);
            var R = x.NOT_FOUND_ERR = (S[8] = "Not found", 8);
            x.NOT_SUPPORTED_ERR = (S[9] = "Not supported", 9);
            var N = x.INUSE_ATTRIBUTE_ERR = (S[10] = "Attribute in use", 10);

            function P(t, e) {
                if (e instanceof Error) var r = e;
                else r = this, Error.call(this, S[t]), this.message = S[t], Error.captureStackTrace && Error.captureStackTrace(this, P);
                return r.code = t, e && (this.message = this.message + ": " + e), r
            }

            function C() {}

            function O(t, e) {
                this._node = t, this._refresh = e, I(this)
            }

            function I(t) {
                var e = t._node._inc || t._node.ownerDocument._inc;
                if (t._inc !== e) {
                    var r = t._refresh(t._node);
                    if (tm(t, "length", r.length), !t.$$length || r.length < t.$$length)
                        for (var n = r.length;
                            (n in t); n++) Object.prototype.hasOwnProperty.call(t, n) && delete t[n];
                    l(r, t), t._inc = e
                }
            }

            function L() {}

            function M(t, e) {
                for (var r = t.length; r--;)
                    if (t[r] === e) return r
            }

            function k(t, e, r, n) {
                if (n ? e[M(e, n)] = r : e[e.length++] = r, t) {
                    r.ownerElement = t;
                    var i = t.ownerDocument;
                    i && (n && F(i, t, n), i && i._inc++, r.namespaceURI === s.XMLNS && (t._nsMap[r.prefix ? r.localName : ""] = r.value))
                }
            }

            function U(t, e, r) {
                var n = M(e, r);
                if (n >= 0) {
                    for (var i = e.length - 1; n < i;) e[n] = e[++n];
                    if (e.length = i, t) {
                        var s = t.ownerDocument;
                        s && (F(s, t, r), r.ownerElement = null)
                    }
                } else throw new P(R, Error(t.tagName + "@" + r))
            }

            function B() {}

            function V() {}

            function j(t) {
                return "<" == t && "&lt;" || ">" == t && "&gt;" || "&" == t && "&amp;" || '"' == t && "&quot;" || "&#" + t.charCodeAt() + ";"
            }

            function _(t, e) {
                if (e(t)) return !0;
                if (t = t.firstChild)
                    do
                        if (_(t, e)) return !0; while (t = t.nextSibling)
            }

            function q() {
                this.ownerDocument = this
            }

            function F(t, e, r, n) {
                t && t._inc++, r.namespaceURI === s.XMLNS && delete e._nsMap[r.prefix ? r.localName : ""]
            }

            function X(t, e, r) {
                if (t && t._inc) {
                    t._inc++;
                    var n = e.childNodes;
                    if (r) n[n.length++] = r;
                    else {
                        for (var i = e.firstChild, s = 0; i;) n[s++] = i, i = i.nextSibling;
                        n.length = s, delete n[n.length]
                    }
                }
            }

            function G(t, e) {
                var r = e.previousSibling,
                    n = e.nextSibling;
                return r ? r.nextSibling = n : t.firstChild = n, n ? n.previousSibling = r : t.lastChild = r, e.parentNode = null, e.previousSibling = null, e.nextSibling = null, X(t.ownerDocument, t), e
            }

            function H(t) {
                return t && t.nodeType === V.DOCUMENT_TYPE_NODE
            }

            function $(t) {
                return t && t.nodeType === V.ELEMENT_NODE
            }

            function z(t) {
                return t && t.nodeType === V.TEXT_NODE
            }

            function W(t, e) {
                var r = t.childNodes || [];
                if (i(r, $) || H(e)) return !1;
                var n = i(r, H);
                return !(e && n && r.indexOf(n) > r.indexOf(e))
            }

            function K(t, e) {
                var r = t.childNodes || [];
                if (i(r, function(t) {
                        return $(t) && t !== e
                    })) return !1;
                var n = i(r, H);
                return !(e && n && r.indexOf(n) > r.indexOf(e))
            }

            function Y(t, e, r) {
                var n = t.childNodes || [],
                    s = e.childNodes || [];
                if (e.nodeType === V.DOCUMENT_FRAGMENT_NODE) {
                    var a = s.filter($);
                    if (a.length > 1 || i(s, z)) throw new P(A, "More than one element or text in fragment");
                    if (1 === a.length && !K(t, r)) throw new P(A, "Element in fragment can not be inserted before doctype")
                }
                if ($(e) && !K(t, r)) throw new P(A, "Only one element can be added and only after doctype");
                if (H(e)) {
                    if (i(n, function(t) {
                            return H(t) && t !== r
                        })) throw new P(A, "Only one doctype is allowed");
                    var o = i(n, $);
                    if (r && n.indexOf(o) < n.indexOf(r)) throw new P(A, "Doctype can only be inserted before an element")
                }
            }

            function Z(t, e, r, n) {
                ! function(t, e, r) {
                    if (!(t && (t.nodeType === V.DOCUMENT_NODE || t.nodeType === V.DOCUMENT_FRAGMENT_NODE || t.nodeType === V.ELEMENT_NODE))) throw new P(A, "Unexpected parent node type " + t.nodeType);
                    if (r && r.parentNode !== t) throw new P(R, "child not in parent");
                    if (!(e && ($(e) || z(e) || H(e) || e.nodeType === V.DOCUMENT_FRAGMENT_NODE || e.nodeType === V.COMMENT_NODE || e.nodeType === V.PROCESSING_INSTRUCTION_NODE)) || H(e) && t.nodeType !== V.DOCUMENT_NODE) throw new P(A, "Unexpected node type " + e.nodeType + " for parent node type " + t.nodeType)
                }(t, e, r), t.nodeType === V.DOCUMENT_NODE && (n || function(t, e, r) {
                    var n = t.childNodes || [],
                        s = e.childNodes || [];
                    if (e.nodeType === V.DOCUMENT_FRAGMENT_NODE) {
                        var a = s.filter($);
                        if (a.length > 1 || i(s, z)) throw new P(A, "More than one element or text in fragment");
                        if (1 === a.length && !W(t, r)) throw new P(A, "Element in fragment can not be inserted before doctype")
                    }
                    if ($(e) && !W(t, r)) throw new P(A, "Only one element can be added and only after doctype");
                    if (H(e)) {
                        if (i(n, H)) throw new P(A, "Only one doctype is allowed");
                        var o = i(n, $);
                        if (r && n.indexOf(o) < n.indexOf(r)) throw new P(A, "Doctype can only be inserted before an element");
                        if (!r && o) throw new P(A, "Doctype can not be appended since element is present")
                    }
                })(t, e, r);
                var s = e.parentNode;
                if (s && s.removeChild(e), e.nodeType === T) {
                    var a = e.firstChild;
                    if (null == a) return e;
                    var o = e.lastChild
                } else a = o = e;
                var u = r ? r.previousSibling : t.lastChild;
                a.previousSibling = u, o.nextSibling = r, u ? u.nextSibling = a : t.firstChild = a, null == r ? t.lastChild = o : r.previousSibling = o;
                do a.parentNode = t; while (a !== o && (a = a.nextSibling));
                return X(t.ownerDocument || t, t), e.nodeType == T && (e.firstChild = e.lastChild = null), e
            }

            function J() {
                this._nsMap = {}
            }

            function Q() {}

            function tt() {}

            function te() {}

            function tr() {}

            function tn() {}

            function ti() {}

            function ts() {}

            function ta() {}

            function to() {}

            function tu() {}

            function tl() {}

            function tc() {}

            function th(t, e) {
                var r = [],
                    n = 9 == this.nodeType && this.documentElement || this,
                    i = n.prefix,
                    s = n.namespaceURI;
                if (s && null == i) {
                    var i = n.lookupPrefix(s);
                    if (null == i) var a = [{
                        namespace: s,
                        prefix: null
                    }]
                }
                return td(this, r, t, e, a), r.join("")
            }

            function tf(t, e, r) {
                var n = t.prefix || "",
                    i = t.namespaceURI;
                if (!i || "xml" === n && i === s.XML || i === s.XMLNS) return !1;
                for (var a = r.length; a--;) {
                    var o = r[a];
                    if (o.prefix === n) return o.namespace !== i
                }
                return !0
            }

            function tp(t, e, r) {
                t.push(" ", e, '="', r.replace(/[<>&"\t\n\r]/g, j), '"')
            }

            function td(t, e, r, n, i) {
                if (i || (i = []), n) {
                    if (!(t = n(t))) return;
                    if ("string" == typeof t) {
                        e.push(t);
                        return
                    }
                }
                switch (t.nodeType) {
                    case f:
                        var a, o = t.attributes,
                            u = o.length,
                            l = t.firstChild,
                            c = t.tagName;
                        r = s.isHTML(t.namespaceURI) || r;
                        var h = c;
                        if (!r && !t.prefix && t.namespaceURI) {
                            for (var y = 0; y < o.length; y++)
                                if ("xmlns" === o.item(y).name) {
                                    a = o.item(y).value;
                                    break
                                }
                            if (!a)
                                for (var D = i.length - 1; D >= 0; D--) {
                                    var x = i[D];
                                    if ("" === x.prefix && x.namespace === t.namespaceURI) {
                                        a = x.namespace;
                                        break
                                    }
                                }
                            if (a !== t.namespaceURI)
                                for (var D = i.length - 1; D >= 0; D--) {
                                    var x = i[D];
                                    if (x.namespace === t.namespaceURI) {
                                        x.prefix && (h = x.prefix + ":" + c);
                                        break
                                    }
                                }
                        }
                        e.push("<", h);
                        for (var S = 0; S < u; S++) {
                            var A = o.item(S);
                            "xmlns" == A.prefix ? i.push({
                                prefix: A.localName,
                                namespace: A.value
                            }) : "xmlns" == A.nodeName && i.push({
                                prefix: "",
                                namespace: A.value
                            })
                        }
                        for (var S = 0; S < u; S++) {
                            var A = o.item(S);
                            if (tf(A, r, i)) {
                                var R = A.prefix || "",
                                    N = A.namespaceURI;
                                tp(e, R ? "xmlns:" + R : "xmlns", N), i.push({
                                    prefix: R,
                                    namespace: N
                                })
                            }
                            td(A, e, r, n, i)
                        }
                        if (c === h && tf(t, r, i)) {
                            var R = t.prefix || "",
                                N = t.namespaceURI;
                            tp(e, R ? "xmlns:" + R : "xmlns", N), i.push({
                                prefix: R,
                                namespace: N
                            })
                        }
                        if (l || r && !/^(?:meta|link|img|br|hr|input)$/i.test(c)) {
                            if (e.push(">"), r && /^script$/i.test(c))
                                for (; l;) l.data ? e.push(l.data) : td(l, e, r, n, i.slice()), l = l.nextSibling;
                            else
                                for (; l;) td(l, e, r, n, i.slice()), l = l.nextSibling;
                            e.push("</", h, ">")
                        } else e.push("/>");
                        return;
                    case E:
                    case T:
                        for (var l = t.firstChild; l;) td(l, e, r, n, i.slice()), l = l.nextSibling;
                        return;
                    case p:
                        return tp(e, t.name, t.value);
                    case d:
                        return e.push(t.data.replace(/[<&>]/g, j));
                    case m:
                        return e.push("<![CDATA[", t.data, "]]>");
                    case b:
                        return e.push("<!--", t.data, "-->");
                    case w:
                        var P = t.publicId,
                            C = t.systemId;
                        if (e.push("<!DOCTYPE ", t.name), P) e.push(" PUBLIC ", P), C && "." != C && e.push(" ", C), e.push(">");
                        else if (C && "." != C) e.push(" SYSTEM ", C, ">");
                        else {
                            var O = t.internalSubset;
                            O && e.push(" [", O, "]"), e.push(">")
                        }
                        return;
                    case v:
                        return e.push("<?", t.target, " ", t.data, "?>");
                    case g:
                        return e.push("&", t.nodeName, ";");
                    default:
                        e.push("??", t.nodeName)
                }
            }

            function tm(t, e, r) {
                t[e] = r
            }
            x.INVALID_STATE_ERR = (S[11] = "Invalid state", 11), x.SYNTAX_ERR = (S[12] = "Syntax error", 12), x.INVALID_MODIFICATION_ERR = (S[13] = "Invalid modification", 13), x.NAMESPACE_ERR = (S[14] = "Invalid namespace", 14), x.INVALID_ACCESS_ERR = (S[15] = "Invalid access", 15), P.prototype = Error.prototype, l(x, P), C.prototype = {
                length: 0,
                item: function(t) {
                    return t >= 0 && t < this.length ? this[t] : null
                },
                toString: function(t, e) {
                    for (var r = [], n = 0; n < this.length; n++) td(this[n], r, t, e);
                    return r.join("")
                },
                filter: function(t) {
                    return Array.prototype.filter.call(this, t)
                },
                indexOf: function(t) {
                    return Array.prototype.indexOf.call(this, t)
                }
            }, O.prototype.item = function(t) {
                return I(this), this[t] || null
            }, c(O, C), L.prototype = {
                length: 0,
                item: C.prototype.item,
                getNamedItem: function(t) {
                    for (var e = this.length; e--;) {
                        var r = this[e];
                        if (r.nodeName == t) return r
                    }
                },
                setNamedItem: function(t) {
                    var e = t.ownerElement;
                    if (e && e != this._ownerElement) throw new P(N);
                    var r = this.getNamedItem(t.nodeName);
                    return k(this._ownerElement, this, t, r), r
                },
                setNamedItemNS: function(t) {
                    var e, r = t.ownerElement;
                    if (r && r != this._ownerElement) throw new P(N);
                    return e = this.getNamedItemNS(t.namespaceURI, t.localName), k(this._ownerElement, this, t, e), e
                },
                removeNamedItem: function(t) {
                    var e = this.getNamedItem(t);
                    return U(this._ownerElement, this, e), e
                },
                removeNamedItemNS: function(t, e) {
                    var r = this.getNamedItemNS(t, e);
                    return U(this._ownerElement, this, r), r
                },
                getNamedItemNS: function(t, e) {
                    for (var r = this.length; r--;) {
                        var n = this[r];
                        if (n.localName == e && n.namespaceURI == t) return n
                    }
                    return null
                }
            }, B.prototype = {
                hasFeature: function(t, e) {
                    return !0
                },
                createDocument: function(t, e, r) {
                    var n = new q;
                    if (n.implementation = this, n.childNodes = new C, n.doctype = r || null, r && n.appendChild(r), e) {
                        var i = n.createElementNS(t, e);
                        n.appendChild(i)
                    }
                    return n
                },
                createDocumentType: function(t, e, r) {
                    var n = new ti;
                    return n.name = t, n.nodeName = t, n.publicId = e || "", n.systemId = r || "", n
                }
            }, V.prototype = {
                firstChild: null,
                lastChild: null,
                previousSibling: null,
                nextSibling: null,
                attributes: null,
                parentNode: null,
                childNodes: null,
                ownerDocument: null,
                nodeValue: null,
                namespaceURI: null,
                prefix: null,
                localName: null,
                insertBefore: function(t, e) {
                    return Z(this, t, e)
                },
                replaceChild: function(t, e) {
                    Z(this, t, e, Y), e && this.removeChild(e)
                },
                removeChild: function(t) {
                    return G(this, t)
                },
                appendChild: function(t) {
                    return this.insertBefore(t, null)
                },
                hasChildNodes: function() {
                    return null != this.firstChild
                },
                cloneNode: function(t) {
                    return function t(e, r, n) {
                        var i = new r.constructor;
                        for (var s in r)
                            if (Object.prototype.hasOwnProperty.call(r, s)) {
                                var a = r[s];
                                "object" != typeof a && a != i[s] && (i[s] = a)
                            }
                        switch (r.childNodes && (i.childNodes = new C), i.ownerDocument = e, i.nodeType) {
                            case f:
                                var o = r.attributes,
                                    u = i.attributes = new L,
                                    l = o.length;
                                u._ownerElement = i;
                                for (var c = 0; c < l; c++) i.setAttributeNode(t(e, o.item(c), !0));
                                break;
                            case p:
                                n = !0
                        }
                        if (n)
                            for (var h = r.firstChild; h;) i.appendChild(t(e, h, n)), h = h.nextSibling;
                        return i
                    }(this.ownerDocument || this, this, t)
                },
                normalize: function() {
                    for (var t = this.firstChild; t;) {
                        var e = t.nextSibling;
                        e && e.nodeType == d && t.nodeType == d ? (this.removeChild(e), t.appendData(e.data)) : (t.normalize(), t = e)
                    }
                },
                isSupported: function(t, e) {
                    return this.ownerDocument.implementation.hasFeature(t, e)
                },
                hasAttributes: function() {
                    return this.attributes.length > 0
                },
                lookupPrefix: function(t) {
                    for (var e = this; e;) {
                        var r = e._nsMap;
                        if (r) {
                            for (var n in r)
                                if (Object.prototype.hasOwnProperty.call(r, n) && r[n] === t) return n
                        }
                        e = e.nodeType == p ? e.ownerDocument : e.parentNode
                    }
                    return null
                },
                lookupNamespaceURI: function(t) {
                    for (var e = this; e;) {
                        var r = e._nsMap;
                        if (r && Object.prototype.hasOwnProperty.call(r, t)) return r[t];
                        e = e.nodeType == p ? e.ownerDocument : e.parentNode
                    }
                    return null
                },
                isDefaultNamespace: function(t) {
                    return null == this.lookupPrefix(t)
                }
            }, l(h, V), l(h, V.prototype), q.prototype = {
                nodeName: "#document",
                nodeType: E,
                doctype: null,
                documentElement: null,
                _inc: 1,
                insertBefore: function(t, e) {
                    if (t.nodeType == T) {
                        for (var r = t.firstChild; r;) {
                            var n = r.nextSibling;
                            this.insertBefore(r, e), r = n
                        }
                        return t
                    }
                    return Z(this, t, e), t.ownerDocument = this, null === this.documentElement && t.nodeType === f && (this.documentElement = t), t
                },
                removeChild: function(t) {
                    return this.documentElement == t && (this.documentElement = null), G(this, t)
                },
                replaceChild: function(t, e) {
                    Z(this, t, e, Y), t.ownerDocument = this, e && this.removeChild(e), $(t) && (this.documentElement = t)
                },
                importNode: function(t, e) {
                    return function t(e, r, n) {
                        var i;
                        switch (r.nodeType) {
                            case f:
                                (i = r.cloneNode(!1)).ownerDocument = e;
                            case T:
                                break;
                            case p:
                                n = !0
                        }
                        if (i || (i = r.cloneNode(!1)), i.ownerDocument = e, i.parentNode = null, n)
                            for (var s = r.firstChild; s;) i.appendChild(t(e, s, n)), s = s.nextSibling;
                        return i
                    }(this, t, e)
                },
                getElementById: function(t) {
                    var e = null;
                    return _(this.documentElement, function(r) {
                        if (r.nodeType == f && r.getAttribute("id") == t) return e = r, !0
                    }), e
                },
                getElementsByClassName: function(t) {
                    var e = u(t);
                    return new O(this, function(r) {
                        var n = [];
                        return e.length > 0 && _(r.documentElement, function(i) {
                            if (i !== r && i.nodeType === f) {
                                var s = i.getAttribute("class");
                                if (s) {
                                    var a = t === s;
                                    if (!a) {
                                        var o = u(s);
                                        a = e.every(function(t) {
                                            return o && -1 !== o.indexOf(t)
                                        })
                                    }
                                    a && n.push(i)
                                }
                            }
                        }), n
                    })
                },
                createElement: function(t) {
                    var e = new J;
                    return e.ownerDocument = this, e.nodeName = t, e.tagName = t, e.localName = t, e.childNodes = new C, (e.attributes = new L)._ownerElement = e, e
                },
                createDocumentFragment: function() {
                    var t = new tu;
                    return t.ownerDocument = this, t.childNodes = new C, t
                },
                createTextNode: function(t) {
                    var e = new te;
                    return e.ownerDocument = this, e.appendData(t), e
                },
                createComment: function(t) {
                    var e = new tr;
                    return e.ownerDocument = this, e.appendData(t), e
                },
                createCDATASection: function(t) {
                    var e = new tn;
                    return e.ownerDocument = this, e.appendData(t), e
                },
                createProcessingInstruction: function(t, e) {
                    var r = new tl;
                    return r.ownerDocument = this, r.tagName = r.nodeName = r.target = t, r.nodeValue = r.data = e, r
                },
                createAttribute: function(t) {
                    var e = new Q;
                    return e.ownerDocument = this, e.name = t, e.nodeName = t, e.localName = t, e.specified = !0, e
                },
                createEntityReference: function(t) {
                    var e = new to;
                    return e.ownerDocument = this, e.nodeName = t, e
                },
                createElementNS: function(t, e) {
                    var r = new J,
                        n = e.split(":"),
                        i = r.attributes = new L;
                    return r.childNodes = new C, r.ownerDocument = this, r.nodeName = e, r.tagName = e, r.namespaceURI = t, 2 == n.length ? (r.prefix = n[0], r.localName = n[1]) : r.localName = e, i._ownerElement = r, r
                },
                createAttributeNS: function(t, e) {
                    var r = new Q,
                        n = e.split(":");
                    return r.ownerDocument = this, r.nodeName = e, r.name = e, r.namespaceURI = t, r.specified = !0, 2 == n.length ? (r.prefix = n[0], r.localName = n[1]) : r.localName = e, r
                }
            }, c(q, V), J.prototype = {
                nodeType: f,
                hasAttribute: function(t) {
                    return null != this.getAttributeNode(t)
                },
                getAttribute: function(t) {
                    var e = this.getAttributeNode(t);
                    return e && e.value || ""
                },
                getAttributeNode: function(t) {
                    return this.attributes.getNamedItem(t)
                },
                setAttribute: function(t, e) {
                    var r = this.ownerDocument.createAttribute(t);
                    r.value = r.nodeValue = "" + e, this.setAttributeNode(r)
                },
                removeAttribute: function(t) {
                    var e = this.getAttributeNode(t);
                    e && this.removeAttributeNode(e)
                },
                appendChild: function(t) {
                    return t.nodeType === T ? this.insertBefore(t, null) : (t.parentNode && t.parentNode.removeChild(t), t.parentNode = this, t.previousSibling = this.lastChild, t.nextSibling = null, t.previousSibling ? t.previousSibling.nextSibling = t : this.firstChild = t, this.lastChild = t, X(this.ownerDocument, this, t), t)
                },
                setAttributeNode: function(t) {
                    return this.attributes.setNamedItem(t)
                },
                setAttributeNodeNS: function(t) {
                    return this.attributes.setNamedItemNS(t)
                },
                removeAttributeNode: function(t) {
                    return this.attributes.removeNamedItem(t.nodeName)
                },
                removeAttributeNS: function(t, e) {
                    var r = this.getAttributeNodeNS(t, e);
                    r && this.removeAttributeNode(r)
                },
                hasAttributeNS: function(t, e) {
                    return null != this.getAttributeNodeNS(t, e)
                },
                getAttributeNS: function(t, e) {
                    var r = this.getAttributeNodeNS(t, e);
                    return r && r.value || ""
                },
                setAttributeNS: function(t, e, r) {
                    var n = this.ownerDocument.createAttributeNS(t, e);
                    n.value = n.nodeValue = "" + r, this.setAttributeNode(n)
                },
                getAttributeNodeNS: function(t, e) {
                    return this.attributes.getNamedItemNS(t, e)
                },
                getElementsByTagName: function(t) {
                    return new O(this, function(e) {
                        var r = [];
                        return _(e, function(n) {
                            n !== e && n.nodeType == f && ("*" === t || n.tagName == t) && r.push(n)
                        }), r
                    })
                },
                getElementsByTagNameNS: function(t, e) {
                    return new O(this, function(r) {
                        var n = [];
                        return _(r, function(i) {
                            i !== r && i.nodeType === f && ("*" === t || i.namespaceURI === t) && ("*" === e || i.localName == e) && n.push(i)
                        }), n
                    })
                }
            }, q.prototype.getElementsByTagName = J.prototype.getElementsByTagName, q.prototype.getElementsByTagNameNS = J.prototype.getElementsByTagNameNS, c(J, V), Q.prototype.nodeType = p, c(Q, V), tt.prototype = {
                data: "",
                substringData: function(t, e) {
                    return this.data.substring(t, t + e)
                },
                appendData: function(t) {
                    t = this.data + t, this.nodeValue = this.data = t, this.length = t.length
                },
                insertData: function(t, e) {
                    this.replaceData(t, 0, e)
                },
                appendChild: function(t) {
                    throw Error(S[A])
                },
                deleteData: function(t, e) {
                    this.replaceData(t, e, "")
                },
                replaceData: function(t, e, r) {
                    r = this.data.substring(0, t) + r + this.data.substring(t + e), this.nodeValue = this.data = r, this.length = r.length
                }
            }, c(tt, V), te.prototype = {
                nodeName: "#text",
                nodeType: d,
                splitText: function(t) {
                    var e = this.data,
                        r = e.substring(t);
                    e = e.substring(0, t), this.data = this.nodeValue = e, this.length = e.length;
                    var n = this.ownerDocument.createTextNode(r);
                    return this.parentNode && this.parentNode.insertBefore(n, this.nextSibling), n
                }
            }, c(te, tt), tr.prototype = {
                nodeName: "#comment",
                nodeType: b
            }, c(tr, tt), tn.prototype = {
                nodeName: "#cdata-section",
                nodeType: m
            }, c(tn, tt), ti.prototype.nodeType = w, c(ti, V), ts.prototype.nodeType = D, c(ts, V), ta.prototype.nodeType = y, c(ta, V), to.prototype.nodeType = g, c(to, V), tu.prototype.nodeName = "#document-fragment", tu.prototype.nodeType = T, c(tu, V), tl.prototype.nodeType = v, c(tl, V), tc.prototype.serializeToString = function(t, e, r) {
                return th.call(t, e, r)
            }, V.prototype.toString = th;
            try {
                Object.defineProperty && (Object.defineProperty(O.prototype, "length", {
                    get: function() {
                        return I(this), this.$$length
                    }
                }), Object.defineProperty(V.prototype, "textContent", {
                    get: function() {
                        return function t(e) {
                            switch (e.nodeType) {
                                case f:
                                case T:
                                    var r = [];
                                    for (e = e.firstChild; e;) 7 !== e.nodeType && 8 !== e.nodeType && r.push(t(e)), e = e.nextSibling;
                                    return r.join("");
                                default:
                                    return e.nodeValue
                            }
                        }(this)
                    },
                    set: function(t) {
                        switch (this.nodeType) {
                            case f:
                            case T:
                                for (; this.firstChild;) this.removeChild(this.firstChild);
                                (t || String(t)) && this.appendChild(this.ownerDocument.createTextNode(t));
                                break;
                            default:
                                this.data = t, this.value = t, this.nodeValue = t
                        }
                    }
                }), tm = function(t, e, r) {
                    t["$$" + e] = r
                })
            } catch (t) {}
            e.DocumentType = ti, e.DOMException = P, e.DOMImplementation = B, e.Element = J, e.Node = V, e.NodeList = C, e.XMLSerializer = tc
        },
        43: function(t, e, r) {
            "use strict";
            var n = r(1461).freeze;
            e.XML_ENTITIES = n({
                amp: "&",
                apos: "'",
                gt: ">",
                lt: "<",
                quot: '"'
            }), e.HTML_ENTITIES = n({
                Aacute: "\xc1",
                aacute: "\xe1",
                Abreve: "Ă",
                abreve: "ă",
                ac: "∾",
                acd: "∿",
                acE: "∾̳",
                Acirc: "\xc2",
                acirc: "\xe2",
                acute: "\xb4",
                Acy: "А",
                acy: "а",
                AElig: "\xc6",
                aelig: "\xe6",
                af: "⁡",
                Afr: "\uD835\uDD04",
                afr: "\uD835\uDD1E",
                Agrave: "\xc0",
                agrave: "\xe0",
                alefsym: "ℵ",
                aleph: "ℵ",
                Alpha: "Α",
                alpha: "α",
                Amacr: "Ā",
                amacr: "ā",
                amalg: "⨿",
                AMP: "&",
                amp: "&",
                And: "⩓",
                and: "∧",
                andand: "⩕",
                andd: "⩜",
                andslope: "⩘",
                andv: "⩚",
                ang: "∠",
                ange: "⦤",
                angle: "∠",
                angmsd: "∡",
                angmsdaa: "⦨",
                angmsdab: "⦩",
                angmsdac: "⦪",
                angmsdad: "⦫",
                angmsdae: "⦬",
                angmsdaf: "⦭",
                angmsdag: "⦮",
                angmsdah: "⦯",
                angrt: "∟",
                angrtvb: "⊾",
                angrtvbd: "⦝",
                angsph: "∢",
                angst: "\xc5",
                angzarr: "⍼",
                Aogon: "Ą",
                aogon: "ą",
                Aopf: "\uD835\uDD38",
                aopf: "\uD835\uDD52",
                ap: "≈",
                apacir: "⩯",
                apE: "⩰",
                ape: "≊",
                apid: "≋",
                apos: "'",
                ApplyFunction: "⁡",
                approx: "≈",
                approxeq: "≊",
                Aring: "\xc5",
                aring: "\xe5",
                Ascr: "\uD835\uDC9C",
                ascr: "\uD835\uDCB6",
                Assign: "≔",
                ast: "*",
                asymp: "≈",
                asympeq: "≍",
                Atilde: "\xc3",
                atilde: "\xe3",
                Auml: "\xc4",
                auml: "\xe4",
                awconint: "∳",
                awint: "⨑",
                backcong: "≌",
                backepsilon: "϶",
                backprime: "‵",
                backsim: "∽",
                backsimeq: "⋍",
                Backslash: "∖",
                Barv: "⫧",
                barvee: "⊽",
                Barwed: "⌆",
                barwed: "⌅",
                barwedge: "⌅",
                bbrk: "⎵",
                bbrktbrk: "⎶",
                bcong: "≌",
                Bcy: "Б",
                bcy: "б",
                bdquo: "„",
                becaus: "∵",
                Because: "∵",
                because: "∵",
                bemptyv: "⦰",
                bepsi: "϶",
                bernou: "ℬ",
                Bernoullis: "ℬ",
                Beta: "Β",
                beta: "β",
                beth: "ℶ",
                between: "≬",
                Bfr: "\uD835\uDD05",
                bfr: "\uD835\uDD1F",
                bigcap: "⋂",
                bigcirc: "◯",
                bigcup: "⋃",
                bigodot: "⨀",
                bigoplus: "⨁",
                bigotimes: "⨂",
                bigsqcup: "⨆",
                bigstar: "★",
                bigtriangledown: "▽",
                bigtriangleup: "△",
                biguplus: "⨄",
                bigvee: "⋁",
                bigwedge: "⋀",
                bkarow: "⤍",
                blacklozenge: "⧫",
                blacksquare: "▪",
                blacktriangle: "▴",
                blacktriangledown: "▾",
                blacktriangleleft: "◂",
                blacktriangleright: "▸",
                blank: "␣",
                blk12: "▒",
                blk14: "░",
                blk34: "▓",
                block: "█",
                bne: "=⃥",
                bnequiv: "≡⃥",
                bNot: "⫭",
                bnot: "⌐",
                Bopf: "\uD835\uDD39",
                bopf: "\uD835\uDD53",
                bot: "⊥",
                bottom: "⊥",
                bowtie: "⋈",
                boxbox: "⧉",
                boxDL: "╗",
                boxDl: "╖",
                boxdL: "╕",
                boxdl: "┐",
                boxDR: "╔",
                boxDr: "╓",
                boxdR: "╒",
                boxdr: "┌",
                boxH: "═",
                boxh: "─",
                boxHD: "╦",
                boxHd: "╤",
                boxhD: "╥",
                boxhd: "┬",
                boxHU: "╩",
                boxHu: "╧",
                boxhU: "╨",
                boxhu: "┴",
                boxminus: "⊟",
                boxplus: "⊞",
                boxtimes: "⊠",
                boxUL: "╝",
                boxUl: "╜",
                boxuL: "╛",
                boxul: "┘",
                boxUR: "╚",
                boxUr: "╙",
                boxuR: "╘",
                boxur: "└",
                boxV: "║",
                boxv: "│",
                boxVH: "╬",
                boxVh: "╫",
                boxvH: "╪",
                boxvh: "┼",
                boxVL: "╣",
                boxVl: "╢",
                boxvL: "╡",
                boxvl: "┤",
                boxVR: "╠",
                boxVr: "╟",
                boxvR: "╞",
                boxvr: "├",
                bprime: "‵",
                Breve: "˘",
                breve: "˘",
                brvbar: "\xa6",
                Bscr: "ℬ",
                bscr: "\uD835\uDCB7",
                bsemi: "⁏",
                bsim: "∽",
                bsime: "⋍",
                bsol: "\\",
                bsolb: "⧅",
                bsolhsub: "⟈",
                bull: "•",
                bullet: "•",
                bump: "≎",
                bumpE: "⪮",
                bumpe: "≏",
                Bumpeq: "≎",
                bumpeq: "≏",
                Cacute: "Ć",
                cacute: "ć",
                Cap: "⋒",
                cap: "∩",
                capand: "⩄",
                capbrcup: "⩉",
                capcap: "⩋",
                capcup: "⩇",
                capdot: "⩀",
                CapitalDifferentialD: "ⅅ",
                caps: "∩︀",
                caret: "⁁",
                caron: "ˇ",
                Cayleys: "ℭ",
                ccaps: "⩍",
                Ccaron: "Č",
                ccaron: "č",
                Ccedil: "\xc7",
                ccedil: "\xe7",
                Ccirc: "Ĉ",
                ccirc: "ĉ",
                Cconint: "∰",
                ccups: "⩌",
                ccupssm: "⩐",
                Cdot: "Ċ",
                cdot: "ċ",
                cedil: "\xb8",
                Cedilla: "\xb8",
                cemptyv: "⦲",
                cent: "\xa2",
                CenterDot: "\xb7",
                centerdot: "\xb7",
                Cfr: "ℭ",
                cfr: "\uD835\uDD20",
                CHcy: "Ч",
                chcy: "ч",
                check: "✓",
                checkmark: "✓",
                Chi: "Χ",
                chi: "χ",
                cir: "○",
                circ: "ˆ",
                circeq: "≗",
                circlearrowleft: "↺",
                circlearrowright: "↻",
                circledast: "⊛",
                circledcirc: "⊚",
                circleddash: "⊝",
                CircleDot: "⊙",
                circledR: "\xae",
                circledS: "Ⓢ",
                CircleMinus: "⊖",
                CirclePlus: "⊕",
                CircleTimes: "⊗",
                cirE: "⧃",
                cire: "≗",
                cirfnint: "⨐",
                cirmid: "⫯",
                cirscir: "⧂",
                ClockwiseContourIntegral: "∲",
                CloseCurlyDoubleQuote: "”",
                CloseCurlyQuote: "’",
                clubs: "♣",
                clubsuit: "♣",
                Colon: "∷",
                colon: ":",
                Colone: "⩴",
                colone: "≔",
                coloneq: "≔",
                comma: ",",
                commat: "@",
                comp: "∁",
                compfn: "∘",
                complement: "∁",
                complexes: "ℂ",
                cong: "≅",
                congdot: "⩭",
                Congruent: "≡",
                Conint: "∯",
                conint: "∮",
                ContourIntegral: "∮",
                Copf: "ℂ",
                copf: "\uD835\uDD54",
                coprod: "∐",
                Coproduct: "∐",
                COPY: "\xa9",
                copy: "\xa9",
                copysr: "℗",
                CounterClockwiseContourIntegral: "∳",
                crarr: "↵",
                Cross: "⨯",
                cross: "✗",
                Cscr: "\uD835\uDC9E",
                cscr: "\uD835\uDCB8",
                csub: "⫏",
                csube: "⫑",
                csup: "⫐",
                csupe: "⫒",
                ctdot: "⋯",
                cudarrl: "⤸",
                cudarrr: "⤵",
                cuepr: "⋞",
                cuesc: "⋟",
                cularr: "↶",
                cularrp: "⤽",
                Cup: "⋓",
                cup: "∪",
                cupbrcap: "⩈",
                CupCap: "≍",
                cupcap: "⩆",
                cupcup: "⩊",
                cupdot: "⊍",
                cupor: "⩅",
                cups: "∪︀",
                curarr: "↷",
                curarrm: "⤼",
                curlyeqprec: "⋞",
                curlyeqsucc: "⋟",
                curlyvee: "⋎",
                curlywedge: "⋏",
                curren: "\xa4",
                curvearrowleft: "↶",
                curvearrowright: "↷",
                cuvee: "⋎",
                cuwed: "⋏",
                cwconint: "∲",
                cwint: "∱",
                cylcty: "⌭",
                Dagger: "‡",
                dagger: "†",
                daleth: "ℸ",
                Darr: "↡",
                dArr: "⇓",
                darr: "↓",
                dash: "‐",
                Dashv: "⫤",
                dashv: "⊣",
                dbkarow: "⤏",
                dblac: "˝",
                Dcaron: "Ď",
                dcaron: "ď",
                Dcy: "Д",
                dcy: "д",
                DD: "ⅅ",
                dd: "ⅆ",
                ddagger: "‡",
                ddarr: "⇊",
                DDotrahd: "⤑",
                ddotseq: "⩷",
                deg: "\xb0",
                Del: "∇",
                Delta: "Δ",
                delta: "δ",
                demptyv: "⦱",
                dfisht: "⥿",
                Dfr: "\uD835\uDD07",
                dfr: "\uD835\uDD21",
                dHar: "⥥",
                dharl: "⇃",
                dharr: "⇂",
                DiacriticalAcute: "\xb4",
                DiacriticalDot: "˙",
                DiacriticalDoubleAcute: "˝",
                DiacriticalGrave: "`",
                DiacriticalTilde: "˜",
                diam: "⋄",
                Diamond: "⋄",
                diamond: "⋄",
                diamondsuit: "♦",
                diams: "♦",
                die: "\xa8",
                DifferentialD: "ⅆ",
                digamma: "ϝ",
                disin: "⋲",
                div: "\xf7",
                divide: "\xf7",
                divideontimes: "⋇",
                divonx: "⋇",
                DJcy: "Ђ",
                djcy: "ђ",
                dlcorn: "⌞",
                dlcrop: "⌍",
                dollar: "$",
                Dopf: "\uD835\uDD3B",
                dopf: "\uD835\uDD55",
                Dot: "\xa8",
                dot: "˙",
                DotDot: "⃜",
                doteq: "≐",
                doteqdot: "≑",
                DotEqual: "≐",
                dotminus: "∸",
                dotplus: "∔",
                dotsquare: "⊡",
                doublebarwedge: "⌆",
                DoubleContourIntegral: "∯",
                DoubleDot: "\xa8",
                DoubleDownArrow: "⇓",
                DoubleLeftArrow: "⇐",
                DoubleLeftRightArrow: "⇔",
                DoubleLeftTee: "⫤",
                DoubleLongLeftArrow: "⟸",
                DoubleLongLeftRightArrow: "⟺",
                DoubleLongRightArrow: "⟹",
                DoubleRightArrow: "⇒",
                DoubleRightTee: "⊨",
                DoubleUpArrow: "⇑",
                DoubleUpDownArrow: "⇕",
                DoubleVerticalBar: "∥",
                DownArrow: "↓",
                Downarrow: "⇓",
                downarrow: "↓",
                DownArrowBar: "⤓",
                DownArrowUpArrow: "⇵",
                DownBreve: "̑",
                downdownarrows: "⇊",
                downharpoonleft: "⇃",
                downharpoonright: "⇂",
                DownLeftRightVector: "⥐",
                DownLeftTeeVector: "⥞",
                DownLeftVector: "↽",
                DownLeftVectorBar: "⥖",
                DownRightTeeVector: "⥟",
                DownRightVector: "⇁",
                DownRightVectorBar: "⥗",
                DownTee: "⊤",
                DownTeeArrow: "↧",
                drbkarow: "⤐",
                drcorn: "⌟",
                drcrop: "⌌",
                Dscr: "\uD835\uDC9F",
                dscr: "\uD835\uDCB9",
                DScy: "Ѕ",
                dscy: "ѕ",
                dsol: "⧶",
                Dstrok: "Đ",
                dstrok: "đ",
                dtdot: "⋱",
                dtri: "▿",
                dtrif: "▾",
                duarr: "⇵",
                duhar: "⥯",
                dwangle: "⦦",
                DZcy: "Џ",
                dzcy: "џ",
                dzigrarr: "⟿",
                Eacute: "\xc9",
                eacute: "\xe9",
                easter: "⩮",
                Ecaron: "Ě",
                ecaron: "ě",
                ecir: "≖",
                Ecirc: "\xca",
                ecirc: "\xea",
                ecolon: "≕",
                Ecy: "Э",
                ecy: "э",
                eDDot: "⩷",
                Edot: "Ė",
                eDot: "≑",
                edot: "ė",
                ee: "ⅇ",
                efDot: "≒",
                Efr: "\uD835\uDD08",
                efr: "\uD835\uDD22",
                eg: "⪚",
                Egrave: "\xc8",
                egrave: "\xe8",
                egs: "⪖",
                egsdot: "⪘",
                el: "⪙",
                Element: "∈",
                elinters: "⏧",
                ell: "ℓ",
                els: "⪕",
                elsdot: "⪗",
                Emacr: "Ē",
                emacr: "ē",
                empty: "∅",
                emptyset: "∅",
                EmptySmallSquare: "◻",
                emptyv: "∅",
                EmptyVerySmallSquare: "▫",
                emsp: " ",
                emsp13: " ",
                emsp14: " ",
                ENG: "Ŋ",
                eng: "ŋ",
                ensp: " ",
                Eogon: "Ę",
                eogon: "ę",
                Eopf: "\uD835\uDD3C",
                eopf: "\uD835\uDD56",
                epar: "⋕",
                eparsl: "⧣",
                eplus: "⩱",
                epsi: "ε",
                Epsilon: "Ε",
                epsilon: "ε",
                epsiv: "ϵ",
                eqcirc: "≖",
                eqcolon: "≕",
                eqsim: "≂",
                eqslantgtr: "⪖",
                eqslantless: "⪕",
                Equal: "⩵",
                equals: "=",
                EqualTilde: "≂",
                equest: "≟",
                Equilibrium: "⇌",
                equiv: "≡",
                equivDD: "⩸",
                eqvparsl: "⧥",
                erarr: "⥱",
                erDot: "≓",
                Escr: "ℰ",
                escr: "ℯ",
                esdot: "≐",
                Esim: "⩳",
                esim: "≂",
                Eta: "Η",
                eta: "η",
                ETH: "\xd0",
                eth: "\xf0",
                Euml: "\xcb",
                euml: "\xeb",
                euro: "€",
                excl: "!",
                exist: "∃",
                Exists: "∃",
                expectation: "ℰ",
                ExponentialE: "ⅇ",
                exponentiale: "ⅇ",
                fallingdotseq: "≒",
                Fcy: "Ф",
                fcy: "ф",
                female: "♀",
                ffilig: "ﬃ",
                fflig: "ﬀ",
                ffllig: "ﬄ",
                Ffr: "\uD835\uDD09",
                ffr: "\uD835\uDD23",
                filig: "ﬁ",
                FilledSmallSquare: "◼",
                FilledVerySmallSquare: "▪",
                fjlig: "fj",
                flat: "♭",
                fllig: "ﬂ",
                fltns: "▱",
                fnof: "ƒ",
                Fopf: "\uD835\uDD3D",
                fopf: "\uD835\uDD57",
                ForAll: "∀",
                forall: "∀",
                fork: "⋔",
                forkv: "⫙",
                Fouriertrf: "ℱ",
                fpartint: "⨍",
                frac12: "\xbd",
                frac13: "⅓",
                frac14: "\xbc",
                frac15: "⅕",
                frac16: "⅙",
                frac18: "⅛",
                frac23: "⅔",
                frac25: "⅖",
                frac34: "\xbe",
                frac35: "⅗",
                frac38: "⅜",
                frac45: "⅘",
                frac56: "⅚",
                frac58: "⅝",
                frac78: "⅞",
                frasl: "⁄",
                frown: "⌢",
                Fscr: "ℱ",
                fscr: "\uD835\uDCBB",
                gacute: "ǵ",
                Gamma: "Γ",
                gamma: "γ",
                Gammad: "Ϝ",
                gammad: "ϝ",
                gap: "⪆",
                Gbreve: "Ğ",
                gbreve: "ğ",
                Gcedil: "Ģ",
                Gcirc: "Ĝ",
                gcirc: "ĝ",
                Gcy: "Г",
                gcy: "г",
                Gdot: "Ġ",
                gdot: "ġ",
                gE: "≧",
                ge: "≥",
                gEl: "⪌",
                gel: "⋛",
                geq: "≥",
                geqq: "≧",
                geqslant: "⩾",
                ges: "⩾",
                gescc: "⪩",
                gesdot: "⪀",
                gesdoto: "⪂",
                gesdotol: "⪄",
                gesl: "⋛︀",
                gesles: "⪔",
                Gfr: "\uD835\uDD0A",
                gfr: "\uD835\uDD24",
                Gg: "⋙",
                gg: "≫",
                ggg: "⋙",
                gimel: "ℷ",
                GJcy: "Ѓ",
                gjcy: "ѓ",
                gl: "≷",
                gla: "⪥",
                glE: "⪒",
                glj: "⪤",
                gnap: "⪊",
                gnapprox: "⪊",
                gnE: "≩",
                gne: "⪈",
                gneq: "⪈",
                gneqq: "≩",
                gnsim: "⋧",
                Gopf: "\uD835\uDD3E",
                gopf: "\uD835\uDD58",
                grave: "`",
                GreaterEqual: "≥",
                GreaterEqualLess: "⋛",
                GreaterFullEqual: "≧",
                GreaterGreater: "⪢",
                GreaterLess: "≷",
                GreaterSlantEqual: "⩾",
                GreaterTilde: "≳",
                Gscr: "\uD835\uDCA2",
                gscr: "ℊ",
                gsim: "≳",
                gsime: "⪎",
                gsiml: "⪐",
                Gt: "≫",
                GT: ">",
                gt: ">",
                gtcc: "⪧",
                gtcir: "⩺",
                gtdot: "⋗",
                gtlPar: "⦕",
                gtquest: "⩼",
                gtrapprox: "⪆",
                gtrarr: "⥸",
                gtrdot: "⋗",
                gtreqless: "⋛",
                gtreqqless: "⪌",
                gtrless: "≷",
                gtrsim: "≳",
                gvertneqq: "≩︀",
                gvnE: "≩︀",
                Hacek: "ˇ",
                hairsp: " ",
                half: "\xbd",
                hamilt: "ℋ",
                HARDcy: "Ъ",
                hardcy: "ъ",
                hArr: "⇔",
                harr: "↔",
                harrcir: "⥈",
                harrw: "↭",
                Hat: "^",
                hbar: "ℏ",
                Hcirc: "Ĥ",
                hcirc: "ĥ",
                hearts: "♥",
                heartsuit: "♥",
                hellip: "…",
                hercon: "⊹",
                Hfr: "ℌ",
                hfr: "\uD835\uDD25",
                HilbertSpace: "ℋ",
                hksearow: "⤥",
                hkswarow: "⤦",
                hoarr: "⇿",
                homtht: "∻",
                hookleftarrow: "↩",
                hookrightarrow: "↪",
                Hopf: "ℍ",
                hopf: "\uD835\uDD59",
                horbar: "―",
                HorizontalLine: "─",
                Hscr: "ℋ",
                hscr: "\uD835\uDCBD",
                hslash: "ℏ",
                Hstrok: "Ħ",
                hstrok: "ħ",
                HumpDownHump: "≎",
                HumpEqual: "≏",
                hybull: "⁃",
                hyphen: "‐",
                Iacute: "\xcd",
                iacute: "\xed",
                ic: "⁣",
                Icirc: "\xce",
                icirc: "\xee",
                Icy: "И",
                icy: "и",
                Idot: "İ",
                IEcy: "Е",
                iecy: "е",
                iexcl: "\xa1",
                iff: "⇔",
                Ifr: "ℑ",
                ifr: "\uD835\uDD26",
                Igrave: "\xcc",
                igrave: "\xec",
                ii: "ⅈ",
                iiiint: "⨌",
                iiint: "∭",
                iinfin: "⧜",
                iiota: "℩",
                IJlig: "Ĳ",
                ijlig: "ĳ",
                Im: "ℑ",
                Imacr: "Ī",
                imacr: "ī",
                image: "ℑ",
                ImaginaryI: "ⅈ",
                imagline: "ℐ",
                imagpart: "ℑ",
                imath: "ı",
                imof: "⊷",
                imped: "Ƶ",
                Implies: "⇒",
                in: "∈",
                incare: "℅",
                infin: "∞",
                infintie: "⧝",
                inodot: "ı",
                Int: "∬",
                int: "∫",
                intcal: "⊺",
                integers: "ℤ",
                Integral: "∫",
                intercal: "⊺",
                Intersection: "⋂",
                intlarhk: "⨗",
                intprod: "⨼",
                InvisibleComma: "⁣",
                InvisibleTimes: "⁢",
                IOcy: "Ё",
                iocy: "ё",
                Iogon: "Į",
                iogon: "į",
                Iopf: "\uD835\uDD40",
                iopf: "\uD835\uDD5A",
                Iota: "Ι",
                iota: "ι",
                iprod: "⨼",
                iquest: "\xbf",
                Iscr: "ℐ",
                iscr: "\uD835\uDCBE",
                isin: "∈",
                isindot: "⋵",
                isinE: "⋹",
                isins: "⋴",
                isinsv: "⋳",
                isinv: "∈",
                it: "⁢",
                Itilde: "Ĩ",
                itilde: "ĩ",
                Iukcy: "І",
                iukcy: "і",
                Iuml: "\xcf",
                iuml: "\xef",
                Jcirc: "Ĵ",
                jcirc: "ĵ",
                Jcy: "Й",
                jcy: "й",
                Jfr: "\uD835\uDD0D",
                jfr: "\uD835\uDD27",
                jmath: "ȷ",
                Jopf: "\uD835\uDD41",
                jopf: "\uD835\uDD5B",
                Jscr: "\uD835\uDCA5",
                jscr: "\uD835\uDCBF",
                Jsercy: "Ј",
                jsercy: "ј",
                Jukcy: "Є",
                jukcy: "є",
                Kappa: "Κ",
                kappa: "κ",
                kappav: "ϰ",
                Kcedil: "Ķ",
                kcedil: "ķ",
                Kcy: "К",
                kcy: "к",
                Kfr: "\uD835\uDD0E",
                kfr: "\uD835\uDD28",
                kgreen: "ĸ",
                KHcy: "Х",
                khcy: "х",
                KJcy: "Ќ",
                kjcy: "ќ",
                Kopf: "\uD835\uDD42",
                kopf: "\uD835\uDD5C",
                Kscr: "\uD835\uDCA6",
                kscr: "\uD835\uDCC0",
                lAarr: "⇚",
                Lacute: "Ĺ",
                lacute: "ĺ",
                laemptyv: "⦴",
                lagran: "ℒ",
                Lambda: "Λ",
                lambda: "λ",
                Lang: "⟪",
                lang: "⟨",
                langd: "⦑",
                langle: "⟨",
                lap: "⪅",
                Laplacetrf: "ℒ",
                laquo: "\xab",
                Larr: "↞",
                lArr: "⇐",
                larr: "←",
                larrb: "⇤",
                larrbfs: "⤟",
                larrfs: "⤝",
                larrhk: "↩",
                larrlp: "↫",
                larrpl: "⤹",
                larrsim: "⥳",
                larrtl: "↢",
                lat: "⪫",
                lAtail: "⤛",
                latail: "⤙",
                late: "⪭",
                lates: "⪭︀",
                lBarr: "⤎",
                lbarr: "⤌",
                lbbrk: "❲",
                lbrace: "{",
                lbrack: "[",
                lbrke: "⦋",
                lbrksld: "⦏",
                lbrkslu: "⦍",
                Lcaron: "Ľ",
                lcaron: "ľ",
                Lcedil: "Ļ",
                lcedil: "ļ",
                lceil: "⌈",
                lcub: "{",
                Lcy: "Л",
                lcy: "л",
                ldca: "⤶",
                ldquo: "“",
                ldquor: "„",
                ldrdhar: "⥧",
                ldrushar: "⥋",
                ldsh: "↲",
                lE: "≦",
                le: "≤",
                LeftAngleBracket: "⟨",
                LeftArrow: "←",
                Leftarrow: "⇐",
                leftarrow: "←",
                LeftArrowBar: "⇤",
                LeftArrowRightArrow: "⇆",
                leftarrowtail: "↢",
                LeftCeiling: "⌈",
                LeftDoubleBracket: "⟦",
                LeftDownTeeVector: "⥡",
                LeftDownVector: "⇃",
                LeftDownVectorBar: "⥙",
                LeftFloor: "⌊",
                leftharpoondown: "↽",
                leftharpoonup: "↼",
                leftleftarrows: "⇇",
                LeftRightArrow: "↔",
                Leftrightarrow: "⇔",
                leftrightarrow: "↔",
                leftrightarrows: "⇆",
                leftrightharpoons: "⇋",
                leftrightsquigarrow: "↭",
                LeftRightVector: "⥎",
                LeftTee: "⊣",
                LeftTeeArrow: "↤",
                LeftTeeVector: "⥚",
                leftthreetimes: "⋋",
                LeftTriangle: "⊲",
                LeftTriangleBar: "⧏",
                LeftTriangleEqual: "⊴",
                LeftUpDownVector: "⥑",
                LeftUpTeeVector: "⥠",
                LeftUpVector: "↿",
                LeftUpVectorBar: "⥘",
                LeftVector: "↼",
                LeftVectorBar: "⥒",
                lEg: "⪋",
                leg: "⋚",
                leq: "≤",
                leqq: "≦",
                leqslant: "⩽",
                les: "⩽",
                lescc: "⪨",
                lesdot: "⩿",
                lesdoto: "⪁",
                lesdotor: "⪃",
                lesg: "⋚︀",
                lesges: "⪓",
                lessapprox: "⪅",
                lessdot: "⋖",
                lesseqgtr: "⋚",
                lesseqqgtr: "⪋",
                LessEqualGreater: "⋚",
                LessFullEqual: "≦",
                LessGreater: "≶",
                lessgtr: "≶",
                LessLess: "⪡",
                lesssim: "≲",
                LessSlantEqual: "⩽",
                LessTilde: "≲",
                lfisht: "⥼",
                lfloor: "⌊",
                Lfr: "\uD835\uDD0F",
                lfr: "\uD835\uDD29",
                lg: "≶",
                lgE: "⪑",
                lHar: "⥢",
                lhard: "↽",
                lharu: "↼",
                lharul: "⥪",
                lhblk: "▄",
                LJcy: "Љ",
                ljcy: "љ",
                Ll: "⋘",
                ll: "≪",
                llarr: "⇇",
                llcorner: "⌞",
                Lleftarrow: "⇚",
                llhard: "⥫",
                lltri: "◺",
                Lmidot: "Ŀ",
                lmidot: "ŀ",
                lmoust: "⎰",
                lmoustache: "⎰",
                lnap: "⪉",
                lnapprox: "⪉",
                lnE: "≨",
                lne: "⪇",
                lneq: "⪇",
                lneqq: "≨",
                lnsim: "⋦",
                loang: "⟬",
                loarr: "⇽",
                lobrk: "⟦",
                LongLeftArrow: "⟵",
                Longleftarrow: "⟸",
                longleftarrow: "⟵",
                LongLeftRightArrow: "⟷",
                Longleftrightarrow: "⟺",
                longleftrightarrow: "⟷",
                longmapsto: "⟼",
                LongRightArrow: "⟶",
                Longrightarrow: "⟹",
                longrightarrow: "⟶",
                looparrowleft: "↫",
                looparrowright: "↬",
                lopar: "⦅",
                Lopf: "\uD835\uDD43",
                lopf: "\uD835\uDD5D",
                loplus: "⨭",
                lotimes: "⨴",
                lowast: "∗",
                lowbar: "_",
                LowerLeftArrow: "↙",
                LowerRightArrow: "↘",
                loz: "◊",
                lozenge: "◊",
                lozf: "⧫",
                lpar: "(",
                lparlt: "⦓",
                lrarr: "⇆",
                lrcorner: "⌟",
                lrhar: "⇋",
                lrhard: "⥭",
                lrm: "‎",
                lrtri: "⊿",
                lsaquo: "‹",
                Lscr: "ℒ",
                lscr: "\uD835\uDCC1",
                Lsh: "↰",
                lsh: "↰",
                lsim: "≲",
                lsime: "⪍",
                lsimg: "⪏",
                lsqb: "[",
                lsquo: "‘",
                lsquor: "‚",
                Lstrok: "Ł",
                lstrok: "ł",
                Lt: "≪",
                LT: "<",
                lt: "<",
                ltcc: "⪦",
                ltcir: "⩹",
                ltdot: "⋖",
                lthree: "⋋",
                ltimes: "⋉",
                ltlarr: "⥶",
                ltquest: "⩻",
                ltri: "◃",
                ltrie: "⊴",
                ltrif: "◂",
                ltrPar: "⦖",
                lurdshar: "⥊",
                luruhar: "⥦",
                lvertneqq: "≨︀",
                lvnE: "≨︀",
                macr: "\xaf",
                male: "♂",
                malt: "✠",
                maltese: "✠",
                Map: "⤅",
                map: "↦",
                mapsto: "↦",
                mapstodown: "↧",
                mapstoleft: "↤",
                mapstoup: "↥",
                marker: "▮",
                mcomma: "⨩",
                Mcy: "М",
                mcy: "м",
                mdash: "—",
                mDDot: "∺",
                measuredangle: "∡",
                MediumSpace: " ",
                Mellintrf: "ℳ",
                Mfr: "\uD835\uDD10",
                mfr: "\uD835\uDD2A",
                mho: "℧",
                micro: "\xb5",
                mid: "∣",
                midast: "*",
                midcir: "⫰",
                middot: "\xb7",
                minus: "−",
                minusb: "⊟",
                minusd: "∸",
                minusdu: "⨪",
                MinusPlus: "∓",
                mlcp: "⫛",
                mldr: "…",
                mnplus: "∓",
                models: "⊧",
                Mopf: "\uD835\uDD44",
                mopf: "\uD835\uDD5E",
                mp: "∓",
                Mscr: "ℳ",
                mscr: "\uD835\uDCC2",
                mstpos: "∾",
                Mu: "Μ",
                mu: "μ",
                multimap: "⊸",
                mumap: "⊸",
                nabla: "∇",
                Nacute: "Ń",
                nacute: "ń",
                nang: "∠⃒",
                nap: "≉",
                napE: "⩰̸",
                napid: "≋̸",
                napos: "ŉ",
                napprox: "≉",
                natur: "♮",
                natural: "♮",
                naturals: "ℕ",
                nbsp: "\xa0",
                nbump: "≎̸",
                nbumpe: "≏̸",
                ncap: "⩃",
                Ncaron: "Ň",
                ncaron: "ň",
                Ncedil: "Ņ",
                ncedil: "ņ",
                ncong: "≇",
                ncongdot: "⩭̸",
                ncup: "⩂",
                Ncy: "Н",
                ncy: "н",
                ndash: "–",
                ne: "≠",
                nearhk: "⤤",
                neArr: "⇗",
                nearr: "↗",
                nearrow: "↗",
                nedot: "≐̸",
                NegativeMediumSpace: "​",
                NegativeThickSpace: "​",
                NegativeThinSpace: "​",
                NegativeVeryThinSpace: "​",
                nequiv: "≢",
                nesear: "⤨",
                nesim: "≂̸",
                NestedGreaterGreater: "≫",
                NestedLessLess: "≪",
                NewLine: "\n",
                nexist: "∄",
                nexists: "∄",
                Nfr: "\uD835\uDD11",
                nfr: "\uD835\uDD2B",
                ngE: "≧̸",
                nge: "≱",
                ngeq: "≱",
                ngeqq: "≧̸",
                ngeqslant: "⩾̸",
                nges: "⩾̸",
                nGg: "⋙̸",
                ngsim: "≵",
                nGt: "≫⃒",
                ngt: "≯",
                ngtr: "≯",
                nGtv: "≫̸",
                nhArr: "⇎",
                nharr: "↮",
                nhpar: "⫲",
                ni: "∋",
                nis: "⋼",
                nisd: "⋺",
                niv: "∋",
                NJcy: "Њ",
                njcy: "њ",
                nlArr: "⇍",
                nlarr: "↚",
                nldr: "‥",
                nlE: "≦̸",
                nle: "≰",
                nLeftarrow: "⇍",
                nleftarrow: "↚",
                nLeftrightarrow: "⇎",
                nleftrightarrow: "↮",
                nleq: "≰",
                nleqq: "≦̸",
                nleqslant: "⩽̸",
                nles: "⩽̸",
                nless: "≮",
                nLl: "⋘̸",
                nlsim: "≴",
                nLt: "≪⃒",
                nlt: "≮",
                nltri: "⋪",
                nltrie: "⋬",
                nLtv: "≪̸",
                nmid: "∤",
                NoBreak: "⁠",
                NonBreakingSpace: "\xa0",
                Nopf: "ℕ",
                nopf: "\uD835\uDD5F",
                Not: "⫬",
                not: "\xac",
                NotCongruent: "≢",
                NotCupCap: "≭",
                NotDoubleVerticalBar: "∦",
                NotElement: "∉",
                NotEqual: "≠",
                NotEqualTilde: "≂̸",
                NotExists: "∄",
                NotGreater: "≯",
                NotGreaterEqual: "≱",
                NotGreaterFullEqual: "≧̸",
                NotGreaterGreater: "≫̸",
                NotGreaterLess: "≹",
                NotGreaterSlantEqual: "⩾̸",
                NotGreaterTilde: "≵",
                NotHumpDownHump: "≎̸",
                NotHumpEqual: "≏̸",
                notin: "∉",
                notindot: "⋵̸",
                notinE: "⋹̸",
                notinva: "∉",
                notinvb: "⋷",
                notinvc: "⋶",
                NotLeftTriangle: "⋪",
                NotLeftTriangleBar: "⧏̸",
                NotLeftTriangleEqual: "⋬",
                NotLess: "≮",
                NotLessEqual: "≰",
                NotLessGreater: "≸",
                NotLessLess: "≪̸",
                NotLessSlantEqual: "⩽̸",
                NotLessTilde: "≴",
                NotNestedGreaterGreater: "⪢̸",
                NotNestedLessLess: "⪡̸",
                notni: "∌",
                notniva: "∌",
                notnivb: "⋾",
                notnivc: "⋽",
                NotPrecedes: "⊀",
                NotPrecedesEqual: "⪯̸",
                NotPrecedesSlantEqual: "⋠",
                NotReverseElement: "∌",
                NotRightTriangle: "⋫",
                NotRightTriangleBar: "⧐̸",
                NotRightTriangleEqual: "⋭",
                NotSquareSubset: "⊏̸",
                NotSquareSubsetEqual: "⋢",
                NotSquareSuperset: "⊐̸",
                NotSquareSupersetEqual: "⋣",
                NotSubset: "⊂⃒",
                NotSubsetEqual: "⊈",
                NotSucceeds: "⊁",
                NotSucceedsEqual: "⪰̸",
                NotSucceedsSlantEqual: "⋡",
                NotSucceedsTilde: "≿̸",
                NotSuperset: "⊃⃒",
                NotSupersetEqual: "⊉",
                NotTilde: "≁",
                NotTildeEqual: "≄",
                NotTildeFullEqual: "≇",
                NotTildeTilde: "≉",
                NotVerticalBar: "∤",
                npar: "∦",
                nparallel: "∦",
                nparsl: "⫽⃥",
                npart: "∂̸",
                npolint: "⨔",
                npr: "⊀",
                nprcue: "⋠",
                npre: "⪯̸",
                nprec: "⊀",
                npreceq: "⪯̸",
                nrArr: "⇏",
                nrarr: "↛",
                nrarrc: "⤳̸",
                nrarrw: "↝̸",
                nRightarrow: "⇏",
                nrightarrow: "↛",
                nrtri: "⋫",
                nrtrie: "⋭",
                nsc: "⊁",
                nsccue: "⋡",
                nsce: "⪰̸",
                Nscr: "\uD835\uDCA9",
                nscr: "\uD835\uDCC3",
                nshortmid: "∤",
                nshortparallel: "∦",
                nsim: "≁",
                nsime: "≄",
                nsimeq: "≄",
                nsmid: "∤",
                nspar: "∦",
                nsqsube: "⋢",
                nsqsupe: "⋣",
                nsub: "⊄",
                nsubE: "⫅̸",
                nsube: "⊈",
                nsubset: "⊂⃒",
                nsubseteq: "⊈",
                nsubseteqq: "⫅̸",
                nsucc: "⊁",
                nsucceq: "⪰̸",
                nsup: "⊅",
                nsupE: "⫆̸",
                nsupe: "⊉",
                nsupset: "⊃⃒",
                nsupseteq: "⊉",
                nsupseteqq: "⫆̸",
                ntgl: "≹",
                Ntilde: "\xd1",
                ntilde: "\xf1",
                ntlg: "≸",
                ntriangleleft: "⋪",
                ntrianglelefteq: "⋬",
                ntriangleright: "⋫",
                ntrianglerighteq: "⋭",
                Nu: "Ν",
                nu: "ν",
                num: "#",
                numero: "№",
                numsp: " ",
                nvap: "≍⃒",
                nVDash: "⊯",
                nVdash: "⊮",
                nvDash: "⊭",
                nvdash: "⊬",
                nvge: "≥⃒",
                nvgt: ">⃒",
                nvHarr: "⤄",
                nvinfin: "⧞",
                nvlArr: "⤂",
                nvle: "≤⃒",
                nvlt: "<⃒",
                nvltrie: "⊴⃒",
                nvrArr: "⤃",
                nvrtrie: "⊵⃒",
                nvsim: "∼⃒",
                nwarhk: "⤣",
                nwArr: "⇖",
                nwarr: "↖",
                nwarrow: "↖",
                nwnear: "⤧",
                Oacute: "\xd3",
                oacute: "\xf3",
                oast: "⊛",
                ocir: "⊚",
                Ocirc: "\xd4",
                ocirc: "\xf4",
                Ocy: "О",
                ocy: "о",
                odash: "⊝",
                Odblac: "Ő",
                odblac: "ő",
                odiv: "⨸",
                odot: "⊙",
                odsold: "⦼",
                OElig: "Œ",
                oelig: "œ",
                ofcir: "⦿",
                Ofr: "\uD835\uDD12",
                ofr: "\uD835\uDD2C",
                ogon: "˛",
                Ograve: "\xd2",
                ograve: "\xf2",
                ogt: "⧁",
                ohbar: "⦵",
                ohm: "Ω",
                oint: "∮",
                olarr: "↺",
                olcir: "⦾",
                olcross: "⦻",
                oline: "‾",
                olt: "⧀",
                Omacr: "Ō",
                omacr: "ō",
                Omega: "Ω",
                omega: "ω",
                Omicron: "Ο",
                omicron: "ο",
                omid: "⦶",
                ominus: "⊖",
                Oopf: "\uD835\uDD46",
                oopf: "\uD835\uDD60",
                opar: "⦷",
                OpenCurlyDoubleQuote: "“",
                OpenCurlyQuote: "‘",
                operp: "⦹",
                oplus: "⊕",
                Or: "⩔",
                or: "∨",
                orarr: "↻",
                ord: "⩝",
                order: "ℴ",
                orderof: "ℴ",
                ordf: "\xaa",
                ordm: "\xba",
                origof: "⊶",
                oror: "⩖",
                orslope: "⩗",
                orv: "⩛",
                oS: "Ⓢ",
                Oscr: "\uD835\uDCAA",
                oscr: "ℴ",
                Oslash: "\xd8",
                oslash: "\xf8",
                osol: "⊘",
                Otilde: "\xd5",
                otilde: "\xf5",
                Otimes: "⨷",
                otimes: "⊗",
                otimesas: "⨶",
                Ouml: "\xd6",
                ouml: "\xf6",
                ovbar: "⌽",
                OverBar: "‾",
                OverBrace: "⏞",
                OverBracket: "⎴",
                OverParenthesis: "⏜",
                par: "∥",
                para: "\xb6",
                parallel: "∥",
                parsim: "⫳",
                parsl: "⫽",
                part: "∂",
                PartialD: "∂",
                Pcy: "П",
                pcy: "п",
                percnt: "%",
                period: ".",
                permil: "‰",
                perp: "⊥",
                pertenk: "‱",
                Pfr: "\uD835\uDD13",
                pfr: "\uD835\uDD2D",
                Phi: "Φ",
                phi: "φ",
                phiv: "ϕ",
                phmmat: "ℳ",
                phone: "☎",
                Pi: "Π",
                pi: "π",
                pitchfork: "⋔",
                piv: "ϖ",
                planck: "ℏ",
                planckh: "ℎ",
                plankv: "ℏ",
                plus: "+",
                plusacir: "⨣",
                plusb: "⊞",
                pluscir: "⨢",
                plusdo: "∔",
                plusdu: "⨥",
                pluse: "⩲",
                PlusMinus: "\xb1",
                plusmn: "\xb1",
                plussim: "⨦",
                plustwo: "⨧",
                pm: "\xb1",
                Poincareplane: "ℌ",
                pointint: "⨕",
                Popf: "ℙ",
                popf: "\uD835\uDD61",
                pound: "\xa3",
                Pr: "⪻",
                pr: "≺",
                prap: "⪷",
                prcue: "≼",
                prE: "⪳",
                pre: "⪯",
                prec: "≺",
                precapprox: "⪷",
                preccurlyeq: "≼",
                Precedes: "≺",
                PrecedesEqual: "⪯",
                PrecedesSlantEqual: "≼",
                PrecedesTilde: "≾",
                preceq: "⪯",
                precnapprox: "⪹",
                precneqq: "⪵",
                precnsim: "⋨",
                precsim: "≾",
                Prime: "″",
                prime: "′",
                primes: "ℙ",
                prnap: "⪹",
                prnE: "⪵",
                prnsim: "⋨",
                prod: "∏",
                Product: "∏",
                profalar: "⌮",
                profline: "⌒",
                profsurf: "⌓",
                prop: "∝",
                Proportion: "∷",
                Proportional: "∝",
                propto: "∝",
                prsim: "≾",
                prurel: "⊰",
                Pscr: "\uD835\uDCAB",
                pscr: "\uD835\uDCC5",
                Psi: "Ψ",
                psi: "ψ",
                puncsp: " ",
                Qfr: "\uD835\uDD14",
                qfr: "\uD835\uDD2E",
                qint: "⨌",
                Qopf: "ℚ",
                qopf: "\uD835\uDD62",
                qprime: "⁗",
                Qscr: "\uD835\uDCAC",
                qscr: "\uD835\uDCC6",
                quaternions: "ℍ",
                quatint: "⨖",
                quest: "?",
                questeq: "≟",
                QUOT: '"',
                quot: '"',
                rAarr: "⇛",
                race: "∽̱",
                Racute: "Ŕ",
                racute: "ŕ",
                radic: "√",
                raemptyv: "⦳",
                Rang: "⟫",
                rang: "⟩",
                rangd: "⦒",
                range: "⦥",
                rangle: "⟩",
                raquo: "\xbb",
                Rarr: "↠",
                rArr: "⇒",
                rarr: "→",
                rarrap: "⥵",
                rarrb: "⇥",
                rarrbfs: "⤠",
                rarrc: "⤳",
                rarrfs: "⤞",
                rarrhk: "↪",
                rarrlp: "↬",
                rarrpl: "⥅",
                rarrsim: "⥴",
                Rarrtl: "⤖",
                rarrtl: "↣",
                rarrw: "↝",
                rAtail: "⤜",
                ratail: "⤚",
                ratio: "∶",
                rationals: "ℚ",
                RBarr: "⤐",
                rBarr: "⤏",
                rbarr: "⤍",
                rbbrk: "❳",
                rbrace: "}",
                rbrack: "]",
                rbrke: "⦌",
                rbrksld: "⦎",
                rbrkslu: "⦐",
                Rcaron: "Ř",
                rcaron: "ř",
                Rcedil: "Ŗ",
                rcedil: "ŗ",
                rceil: "⌉",
                rcub: "}",
                Rcy: "Р",
                rcy: "р",
                rdca: "⤷",
                rdldhar: "⥩",
                rdquo: "”",
                rdquor: "”",
                rdsh: "↳",
                Re: "ℜ",
                real: "ℜ",
                realine: "ℛ",
                realpart: "ℜ",
                reals: "ℝ",
                rect: "▭",
                REG: "\xae",
                reg: "\xae",
                ReverseElement: "∋",
                ReverseEquilibrium: "⇋",
                ReverseUpEquilibrium: "⥯",
                rfisht: "⥽",
                rfloor: "⌋",
                Rfr: "ℜ",
                rfr: "\uD835\uDD2F",
                rHar: "⥤",
                rhard: "⇁",
                rharu: "⇀",
                rharul: "⥬",
                Rho: "Ρ",
                rho: "ρ",
                rhov: "ϱ",
                RightAngleBracket: "⟩",
                RightArrow: "→",
                Rightarrow: "⇒",
                rightarrow: "→",
                RightArrowBar: "⇥",
                RightArrowLeftArrow: "⇄",
                rightarrowtail: "↣",
                RightCeiling: "⌉",
                RightDoubleBracket: "⟧",
                RightDownTeeVector: "⥝",
                RightDownVector: "⇂",
                RightDownVectorBar: "⥕",
                RightFloor: "⌋",
                rightharpoondown: "⇁",
                rightharpoonup: "⇀",
                rightleftarrows: "⇄",
                rightleftharpoons: "⇌",
                rightrightarrows: "⇉",
                rightsquigarrow: "↝",
                RightTee: "⊢",
                RightTeeArrow: "↦",
                RightTeeVector: "⥛",
                rightthreetimes: "⋌",
                RightTriangle: "⊳",
                RightTriangleBar: "⧐",
                RightTriangleEqual: "⊵",
                RightUpDownVector: "⥏",
                RightUpTeeVector: "⥜",
                RightUpVector: "↾",
                RightUpVectorBar: "⥔",
                RightVector: "⇀",
                RightVectorBar: "⥓",
                ring: "˚",
                risingdotseq: "≓",
                rlarr: "⇄",
                rlhar: "⇌",
                rlm: "‏",
                rmoust: "⎱",
                rmoustache: "⎱",
                rnmid: "⫮",
                roang: "⟭",
                roarr: "⇾",
                robrk: "⟧",
                ropar: "⦆",
                Ropf: "ℝ",
                ropf: "\uD835\uDD63",
                roplus: "⨮",
                rotimes: "⨵",
                RoundImplies: "⥰",
                rpar: ")",
                rpargt: "⦔",
                rppolint: "⨒",
                rrarr: "⇉",
                Rrightarrow: "⇛",
                rsaquo: "›",
                Rscr: "ℛ",
                rscr: "\uD835\uDCC7",
                Rsh: "↱",
                rsh: "↱",
                rsqb: "]",
                rsquo: "’",
                rsquor: "’",
                rthree: "⋌",
                rtimes: "⋊",
                rtri: "▹",
                rtrie: "⊵",
                rtrif: "▸",
                rtriltri: "⧎",
                RuleDelayed: "⧴",
                ruluhar: "⥨",
                rx: "℞",
                Sacute: "Ś",
                sacute: "ś",
                sbquo: "‚",
                Sc: "⪼",
                sc: "≻",
                scap: "⪸",
                Scaron: "Š",
                scaron: "š",
                sccue: "≽",
                scE: "⪴",
                sce: "⪰",
                Scedil: "Ş",
                scedil: "ş",
                Scirc: "Ŝ",
                scirc: "ŝ",
                scnap: "⪺",
                scnE: "⪶",
                scnsim: "⋩",
                scpolint: "⨓",
                scsim: "≿",
                Scy: "С",
                scy: "с",
                sdot: "⋅",
                sdotb: "⊡",
                sdote: "⩦",
                searhk: "⤥",
                seArr: "⇘",
                searr: "↘",
                searrow: "↘",
                sect: "\xa7",
                semi: ";",
                seswar: "⤩",
                setminus: "∖",
                setmn: "∖",
                sext: "✶",
                Sfr: "\uD835\uDD16",
                sfr: "\uD835\uDD30",
                sfrown: "⌢",
                sharp: "♯",
                SHCHcy: "Щ",
                shchcy: "щ",
                SHcy: "Ш",
                shcy: "ш",
                ShortDownArrow: "↓",
                ShortLeftArrow: "←",
                shortmid: "∣",
                shortparallel: "∥",
                ShortRightArrow: "→",
                ShortUpArrow: "↑",
                shy: "\xad",
                Sigma: "Σ",
                sigma: "σ",
                sigmaf: "ς",
                sigmav: "ς",
                sim: "∼",
                simdot: "⩪",
                sime: "≃",
                simeq: "≃",
                simg: "⪞",
                simgE: "⪠",
                siml: "⪝",
                simlE: "⪟",
                simne: "≆",
                simplus: "⨤",
                simrarr: "⥲",
                slarr: "←",
                SmallCircle: "∘",
                smallsetminus: "∖",
                smashp: "⨳",
                smeparsl: "⧤",
                smid: "∣",
                smile: "⌣",
                smt: "⪪",
                smte: "⪬",
                smtes: "⪬︀",
                SOFTcy: "Ь",
                softcy: "ь",
                sol: "/",
                solb: "⧄",
                solbar: "⌿",
                Sopf: "\uD835\uDD4A",
                sopf: "\uD835\uDD64",
                spades: "♠",
                spadesuit: "♠",
                spar: "∥",
                sqcap: "⊓",
                sqcaps: "⊓︀",
                sqcup: "⊔",
                sqcups: "⊔︀",
                Sqrt: "√",
                sqsub: "⊏",
                sqsube: "⊑",
                sqsubset: "⊏",
                sqsubseteq: "⊑",
                sqsup: "⊐",
                sqsupe: "⊒",
                sqsupset: "⊐",
                sqsupseteq: "⊒",
                squ: "□",
                Square: "□",
                square: "□",
                SquareIntersection: "⊓",
                SquareSubset: "⊏",
                SquareSubsetEqual: "⊑",
                SquareSuperset: "⊐",
                SquareSupersetEqual: "⊒",
                SquareUnion: "⊔",
                squarf: "▪",
                squf: "▪",
                srarr: "→",
                Sscr: "\uD835\uDCAE",
                sscr: "\uD835\uDCC8",
                ssetmn: "∖",
                ssmile: "⌣",
                sstarf: "⋆",
                Star: "⋆",
                star: "☆",
                starf: "★",
                straightepsilon: "ϵ",
                straightphi: "ϕ",
                strns: "\xaf",
                Sub: "⋐",
                sub: "⊂",
                subdot: "⪽",
                subE: "⫅",
                sube: "⊆",
                subedot: "⫃",
                submult: "⫁",
                subnE: "⫋",
                subne: "⊊",
                subplus: "⪿",
                subrarr: "⥹",
                Subset: "⋐",
                subset: "⊂",
                subseteq: "⊆",
                subseteqq: "⫅",
                SubsetEqual: "⊆",
                subsetneq: "⊊",
                subsetneqq: "⫋",
                subsim: "⫇",
                subsub: "⫕",
                subsup: "⫓",
                succ: "≻",
                succapprox: "⪸",
                succcurlyeq: "≽",
                Succeeds: "≻",
                SucceedsEqual: "⪰",
                SucceedsSlantEqual: "≽",
                SucceedsTilde: "≿",
                succeq: "⪰",
                succnapprox: "⪺",
                succneqq: "⪶",
                succnsim: "⋩",
                succsim: "≿",
                SuchThat: "∋",
                Sum: "∑",
                sum: "∑",
                sung: "♪",
                Sup: "⋑",
                sup: "⊃",
                sup1: "\xb9",
                sup2: "\xb2",
                sup3: "\xb3",
                supdot: "⪾",
                supdsub: "⫘",
                supE: "⫆",
                supe: "⊇",
                supedot: "⫄",
                Superset: "⊃",
                SupersetEqual: "⊇",
                suphsol: "⟉",
                suphsub: "⫗",
                suplarr: "⥻",
                supmult: "⫂",
                supnE: "⫌",
                supne: "⊋",
                supplus: "⫀",
                Supset: "⋑",
                supset: "⊃",
                supseteq: "⊇",
                supseteqq: "⫆",
                supsetneq: "⊋",
                supsetneqq: "⫌",
                supsim: "⫈",
                supsub: "⫔",
                supsup: "⫖",
                swarhk: "⤦",
                swArr: "⇙",
                swarr: "↙",
                swarrow: "↙",
                swnwar: "⤪",
                szlig: "\xdf",
                Tab: "	",
                target: "⌖",
                Tau: "Τ",
                tau: "τ",
                tbrk: "⎴",
                Tcaron: "Ť",
                tcaron: "ť",
                Tcedil: "Ţ",
                tcedil: "ţ",
                Tcy: "Т",
                tcy: "т",
                tdot: "⃛",
                telrec: "⌕",
                Tfr: "\uD835\uDD17",
                tfr: "\uD835\uDD31",
                there4: "∴",
                Therefore: "∴",
                therefore: "∴",
                Theta: "Θ",
                theta: "θ",
                thetasym: "ϑ",
                thetav: "ϑ",
                thickapprox: "≈",
                thicksim: "∼",
                ThickSpace: "  ",
                thinsp: " ",
                ThinSpace: " ",
                thkap: "≈",
                thksim: "∼",
                THORN: "\xde",
                thorn: "\xfe",
                Tilde: "∼",
                tilde: "˜",
                TildeEqual: "≃",
                TildeFullEqual: "≅",
                TildeTilde: "≈",
                times: "\xd7",
                timesb: "⊠",
                timesbar: "⨱",
                timesd: "⨰",
                tint: "∭",
                toea: "⤨",
                top: "⊤",
                topbot: "⌶",
                topcir: "⫱",
                Topf: "\uD835\uDD4B",
                topf: "\uD835\uDD65",
                topfork: "⫚",
                tosa: "⤩",
                tprime: "‴",
                TRADE: "™",
                trade: "™",
                triangle: "▵",
                triangledown: "▿",
                triangleleft: "◃",
                trianglelefteq: "⊴",
                triangleq: "≜",
                triangleright: "▹",
                trianglerighteq: "⊵",
                tridot: "◬",
                trie: "≜",
                triminus: "⨺",
                TripleDot: "⃛",
                triplus: "⨹",
                trisb: "⧍",
                tritime: "⨻",
                trpezium: "⏢",
                Tscr: "\uD835\uDCAF",
                tscr: "\uD835\uDCC9",
                TScy: "Ц",
                tscy: "ц",
                TSHcy: "Ћ",
                tshcy: "ћ",
                Tstrok: "Ŧ",
                tstrok: "ŧ",
                twixt: "≬",
                twoheadleftarrow: "↞",
                twoheadrightarrow: "↠",
                Uacute: "\xda",
                uacute: "\xfa",
                Uarr: "↟",
                uArr: "⇑",
                uarr: "↑",
                Uarrocir: "⥉",
                Ubrcy: "Ў",
                ubrcy: "ў",
                Ubreve: "Ŭ",
                ubreve: "ŭ",
                Ucirc: "\xdb",
                ucirc: "\xfb",
                Ucy: "У",
                ucy: "у",
                udarr: "⇅",
                Udblac: "Ű",
                udblac: "ű",
                udhar: "⥮",
                ufisht: "⥾",
                Ufr: "\uD835\uDD18",
                ufr: "\uD835\uDD32",
                Ugrave: "\xd9",
                ugrave: "\xf9",
                uHar: "⥣",
                uharl: "↿",
                uharr: "↾",
                uhblk: "▀",
                ulcorn: "⌜",
                ulcorner: "⌜",
                ulcrop: "⌏",
                ultri: "◸",
                Umacr: "Ū",
                umacr: "ū",
                uml: "\xa8",
                UnderBar: "_",
                UnderBrace: "⏟",
                UnderBracket: "⎵",
                UnderParenthesis: "⏝",
                Union: "⋃",
                UnionPlus: "⊎",
                Uogon: "Ų",
                uogon: "ų",
                Uopf: "\uD835\uDD4C",
                uopf: "\uD835\uDD66",
                UpArrow: "↑",
                Uparrow: "⇑",
                uparrow: "↑",
                UpArrowBar: "⤒",
                UpArrowDownArrow: "⇅",
                UpDownArrow: "↕",
                Updownarrow: "⇕",
                updownarrow: "↕",
                UpEquilibrium: "⥮",
                upharpoonleft: "↿",
                upharpoonright: "↾",
                uplus: "⊎",
                UpperLeftArrow: "↖",
                UpperRightArrow: "↗",
                Upsi: "ϒ",
                upsi: "υ",
                upsih: "ϒ",
                Upsilon: "Υ",
                upsilon: "υ",
                UpTee: "⊥",
                UpTeeArrow: "↥",
                upuparrows: "⇈",
                urcorn: "⌝",
                urcorner: "⌝",
                urcrop: "⌎",
                Uring: "Ů",
                uring: "ů",
                urtri: "◹",
                Uscr: "\uD835\uDCB0",
                uscr: "\uD835\uDCCA",
                utdot: "⋰",
                Utilde: "Ũ",
                utilde: "ũ",
                utri: "▵",
                utrif: "▴",
                uuarr: "⇈",
                Uuml: "\xdc",
                uuml: "\xfc",
                uwangle: "⦧",
                vangrt: "⦜",
                varepsilon: "ϵ",
                varkappa: "ϰ",
                varnothing: "∅",
                varphi: "ϕ",
                varpi: "ϖ",
                varpropto: "∝",
                vArr: "⇕",
                varr: "↕",
                varrho: "ϱ",
                varsigma: "ς",
                varsubsetneq: "⊊︀",
                varsubsetneqq: "⫋︀",
                varsupsetneq: "⊋︀",
                varsupsetneqq: "⫌︀",
                vartheta: "ϑ",
                vartriangleleft: "⊲",
                vartriangleright: "⊳",
                Vbar: "⫫",
                vBar: "⫨",
                vBarv: "⫩",
                Vcy: "В",
                vcy: "в",
                VDash: "⊫",
                Vdash: "⊩",
                vDash: "⊨",
                vdash: "⊢",
                Vdashl: "⫦",
                Vee: "⋁",
                vee: "∨",
                veebar: "⊻",
                veeeq: "≚",
                vellip: "⋮",
                Verbar: "‖",
                verbar: "|",
                Vert: "‖",
                vert: "|",
                VerticalBar: "∣",
                VerticalLine: "|",
                VerticalSeparator: "❘",
                VerticalTilde: "≀",
                VeryThinSpace: " ",
                Vfr: "\uD835\uDD19",
                vfr: "\uD835\uDD33",
                vltri: "⊲",
                vnsub: "⊂⃒",
                vnsup: "⊃⃒",
                Vopf: "\uD835\uDD4D",
                vopf: "\uD835\uDD67",
                vprop: "∝",
                vrtri: "⊳",
                Vscr: "\uD835\uDCB1",
                vscr: "\uD835\uDCCB",
                vsubnE: "⫋︀",
                vsubne: "⊊︀",
                vsupnE: "⫌︀",
                vsupne: "⊋︀",
                Vvdash: "⊪",
                vzigzag: "⦚",
                Wcirc: "Ŵ",
                wcirc: "ŵ",
                wedbar: "⩟",
                Wedge: "⋀",
                wedge: "∧",
                wedgeq: "≙",
                weierp: "℘",
                Wfr: "\uD835\uDD1A",
                wfr: "\uD835\uDD34",
                Wopf: "\uD835\uDD4E",
                wopf: "\uD835\uDD68",
                wp: "℘",
                wr: "≀",
                wreath: "≀",
                Wscr: "\uD835\uDCB2",
                wscr: "\uD835\uDCCC",
                xcap: "⋂",
                xcirc: "◯",
                xcup: "⋃",
                xdtri: "▽",
                Xfr: "\uD835\uDD1B",
                xfr: "\uD835\uDD35",
                xhArr: "⟺",
                xharr: "⟷",
                Xi: "Ξ",
                xi: "ξ",
                xlArr: "⟸",
                xlarr: "⟵",
                xmap: "⟼",
                xnis: "⋻",
                xodot: "⨀",
                Xopf: "\uD835\uDD4F",
                xopf: "\uD835\uDD69",
                xoplus: "⨁",
                xotime: "⨂",
                xrArr: "⟹",
                xrarr: "⟶",
                Xscr: "\uD835\uDCB3",
                xscr: "\uD835\uDCCD",
                xsqcup: "⨆",
                xuplus: "⨄",
                xutri: "△",
                xvee: "⋁",
                xwedge: "⋀",
                Yacute: "\xdd",
                yacute: "\xfd",
                YAcy: "Я",
                yacy: "я",
                Ycirc: "Ŷ",
                ycirc: "ŷ",
                Ycy: "Ы",
                ycy: "ы",
                yen: "\xa5",
                Yfr: "\uD835\uDD1C",
                yfr: "\uD835\uDD36",
                YIcy: "Ї",
                yicy: "ї",
                Yopf: "\uD835\uDD50",
                yopf: "\uD835\uDD6A",
                Yscr: "\uD835\uDCB4",
                yscr: "\uD835\uDCCE",
                YUcy: "Ю",
                yucy: "ю",
                Yuml: "Ÿ",
                yuml: "\xff",
                Zacute: "Ź",
                zacute: "ź",
                Zcaron: "Ž",
                zcaron: "ž",
                Zcy: "З",
                zcy: "з",
                Zdot: "Ż",
                zdot: "ż",
                zeetrf: "ℨ",
                ZeroWidthSpace: "​",
                Zeta: "Ζ",
                zeta: "ζ",
                Zfr: "ℨ",
                zfr: "\uD835\uDD37",
                ZHcy: "Ж",
                zhcy: "ж",
                zigrarr: "⇝",
                Zopf: "ℤ",
                zopf: "\uD835\uDD6B",
                Zscr: "\uD835\uDCB5",
                zscr: "\uD835\uDCCF",
                zwj: "‍",
                zwnj: "‌"
            }), e.entityMap = e.HTML_ENTITIES
        },
        9432: function(t, e, r) {
            var n = r(2556);
            n.DOMImplementation, n.XMLSerializer, e.DOMParser = r(505).DOMParser
        },
        4465: function(t, e, r) {
            var n = r(1461).NAMESPACE,
                i = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
                s = RegExp("[\\-\\.0-9" + i.source.slice(1, -1) + "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]"),
                a = RegExp("^" + i.source + s.source + "*(?::" + i.source + s.source + "*)?$");

            function o(t, e) {
                this.message = t, this.locator = e, Error.captureStackTrace && Error.captureStackTrace(this, o)
            }

            function u() {}

            function l(t, e) {
                return e.lineNumber = t.lineNumber, e.columnNumber = t.columnNumber, e
            }

            function c(t, e, r) {
                for (var i = t.tagName, s = null, a = t.length; a--;) {
                    var o = t[a],
                        u = o.qName,
                        l = o.value,
                        c = u.indexOf(":");
                    if (c > 0) var f = o.prefix = u.slice(0, c),
                        p = u.slice(c + 1),
                        d = "xmlns" === f && p;
                    else p = u, f = null, d = "xmlns" === u && "";
                    o.localName = p, !1 !== d && (null == s && (s = {}, h(r, r = {})), r[d] = s[d] = l, o.uri = n.XMLNS, e.startPrefixMapping(d, l))
                }
                for (var a = t.length; a--;) {
                    var f = (o = t[a]).prefix;
                    f && ("xml" === f && (o.uri = n.XML), "xmlns" !== f && (o.uri = r[f || ""]))
                }
                var c = i.indexOf(":");
                c > 0 ? (f = t.prefix = i.slice(0, c), p = t.localName = i.slice(c + 1)) : (f = null, p = t.localName = i);
                var m = t.uri = r[f || ""];
                if (e.startElement(m, p, i, t), !t.closed) return t.currentNSMap = r, t.localNSMap = s, !0;
                if (e.endElement(m, p, i), s)
                    for (f in s) Object.prototype.hasOwnProperty.call(s, f) && e.endPrefixMapping(f)
            }

            function h(t, e) {
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
            }

            function f() {
                this.attributeNames = {}
            }
            o.prototype = Error(), o.prototype.name = o.name, u.prototype = {
                parse: function(t, e, r) {
                    var i = this.domBuilder;
                    i.startDocument(), h(e, e = {}),
                        function(t, e, r, i, s) {
                            function a(t) {
                                var e, n = t.slice(1, -1);
                                return Object.hasOwnProperty.call(r, n) ? r[n] : "#" !== n.charAt(0) ? (s.error("entity not found:" + t), t) : (e = parseInt(n.substr(1).replace("x", "0x"))) > 65535 ? String.fromCharCode(55296 + ((e -= 65536) >> 10), 56320 + (1023 & e)) : String.fromCharCode(e)
                            }

                            function u(e) {
                                if (e > b) {
                                    var r = t.substring(b, e).replace(/&#?\w+;/g, a);
                                    g && h(b), i.characters(r, 0, e - b), b = e
                                }
                            }

                            function h(e, r) {
                                for (; e >= d && (r = m.exec(t));) d = (p = r.index) + r[0].length, g.lineNumber++;
                                g.columnNumber = e - p + 1
                            }
                            for (var p = 0, d = 0, m = /.*(?:\r\n?|\n)|.*$/g, g = i.locator, y = [{
                                    currentNSMap: e
                                }], v = {}, b = 0;;) {
                                try {
                                    var E = t.indexOf("<", b);
                                    if (E < 0) {
                                        if (!t.substr(b).match(/^\s*$/)) {
                                            var w = i.doc,
                                                T = w.createTextNode(t.substr(b));
                                            w.appendChild(T), i.currentElement = T
                                        }
                                        return
                                    }
                                    switch (E > b && u(E), t.charAt(E + 1)) {
                                        case "/":
                                            var D = t.indexOf(">", E + 3),
                                                x = t.substring(E + 2, D).replace(/[ \t\n\r]+$/g, ""),
                                                S = y.pop();
                                            D < 0 ? (x = t.substring(E + 2).replace(/[\s<].*/, ""), s.error("end tag name: " + x + " is not complete:" + S.tagName), D = E + 1 + x.length) : x.match(/\s</) && (x = x.replace(/[\s<].*/, ""), s.error("end tag name: " + x + " maybe not complete"), D = E + 1 + x.length);
                                            var A = S.localNSMap,
                                                R = S.tagName == x;
                                            if (R || S.tagName && S.tagName.toLowerCase() == x.toLowerCase()) {
                                                if (i.endElement(S.uri, S.localName, x), A)
                                                    for (var N in A) Object.prototype.hasOwnProperty.call(A, N) && i.endPrefixMapping(N);
                                                R || s.fatalError("end tag name: " + x + " is not match the current start tagName:" + S.tagName)
                                            } else y.push(S);
                                            D++;
                                            break;
                                        case "?":
                                            g && h(E), D = function(t, e, r) {
                                                var n = t.indexOf("?>", e);
                                                if (n) {
                                                    var i = t.substring(e, n).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);
                                                    if (i) return i[0].length, r.processingInstruction(i[1], i[2]), n + 2
                                                }
                                                return -1
                                            }(t, E, i);
                                            break;
                                        case "!":
                                            g && h(E), D = function(t, e, r, n) {
                                                if ("-" === t.charAt(e + 2)) {
                                                    if ("-" === t.charAt(e + 3)) {
                                                        var i = t.indexOf("-->", e + 4);
                                                        if (i > e) return r.comment(t, e + 4, i - e - 4), i + 3;
                                                        n.error("Unclosed comment")
                                                    }
                                                } else {
                                                    if ("CDATA[" == t.substr(e + 3, 6)) {
                                                        var i = t.indexOf("]]>", e + 9);
                                                        return r.startCDATA(), r.characters(t, e + 9, i - e - 9), r.endCDATA(), i + 3
                                                    }
                                                    var s = function(t, e) {
                                                            var r, n = [],
                                                                i = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
                                                            for (i.lastIndex = e, i.exec(t); r = i.exec(t);)
                                                                if (n.push(r), r[1]) return n
                                                        }(t, e),
                                                        a = s.length;
                                                    if (a > 1 && /!doctype/i.test(s[0][0])) {
                                                        var o = s[1][0],
                                                            u = !1,
                                                            l = !1;
                                                        a > 3 && (/^public$/i.test(s[2][0]) ? (u = s[3][0], l = a > 4 && s[4][0]) : /^system$/i.test(s[2][0]) && (l = s[3][0]));
                                                        var c = s[a - 1];
                                                        return r.startDTD(o, u, l), r.endDTD(), c.index + c[0].length
                                                    }
                                                }
                                                return -1
                                            }(t, E, i, s);
                                            break;
                                        default:
                                            g && h(E);
                                            var P = new f,
                                                C = y[y.length - 1].currentNSMap,
                                                D = function(t, e, r, i, s, a) {
                                                    function o(t, e, n) {
                                                        r.attributeNames.hasOwnProperty(t) && a.fatalError("Attribute " + t + " redefined"), r.addValue(t, e.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, s), n)
                                                    }
                                                    for (var u, l, c = ++e, h = 0;;) {
                                                        var f = t.charAt(c);
                                                        switch (f) {
                                                            case "=":
                                                                if (1 === h) u = t.slice(e, c), h = 3;
                                                                else if (2 === h) h = 3;
                                                                else throw Error("attribute equal must after attrName");
                                                                break;
                                                            case "'":
                                                            case '"':
                                                                if (3 === h || 1 === h) {
                                                                    if (1 === h && (a.warning('attribute value must after "="'), u = t.slice(e, c)), e = c + 1, (c = t.indexOf(f, e)) > 0) o(u, l = t.slice(e, c), e - 1), h = 5;
                                                                    else throw Error("attribute value no end '" + f + "' match")
                                                                } else if (4 == h) o(u, l = t.slice(e, c), e), a.warning('attribute "' + u + '" missed start quot(' + f + ")!!"), e = c + 1, h = 5;
                                                                else throw Error('attribute value must after "="');
                                                                break;
                                                            case "/":
                                                                switch (h) {
                                                                    case 0:
                                                                        r.setTagName(t.slice(e, c));
                                                                    case 5:
                                                                    case 6:
                                                                    case 7:
                                                                        h = 7, r.closed = !0;
                                                                    case 4:
                                                                    case 1:
                                                                        break;
                                                                    case 2:
                                                                        r.closed = !0;
                                                                        break;
                                                                    default:
                                                                        throw Error("attribute invalid close char('/')")
                                                                }
                                                                break;
                                                            case "":
                                                                return a.error("unexpected end of input"), 0 == h && r.setTagName(t.slice(e, c)), c;
                                                            case ">":
                                                                switch (h) {
                                                                    case 0:
                                                                        r.setTagName(t.slice(e, c));
                                                                    case 5:
                                                                    case 6:
                                                                    case 7:
                                                                        break;
                                                                    case 4:
                                                                    case 1:
                                                                        "/" === (l = t.slice(e, c)).slice(-1) && (r.closed = !0, l = l.slice(0, -1));
                                                                    case 2:
                                                                        2 === h && (l = u), 4 == h ? (a.warning('attribute "' + l + '" missed quot(")!'), o(u, l, e)) : (n.isHTML(i[""]) && l.match(/^(?:disabled|checked|selected)$/i) || a.warning('attribute "' + l + '" missed value!! "' + l + '" instead!!'), o(l, l, e));
                                                                        break;
                                                                    case 3:
                                                                        throw Error("attribute value missed!!")
                                                                }
                                                                return c;
                                                            case "\x80":
                                                                f = " ";
                                                            default:
                                                                if (f <= " ") switch (h) {
                                                                    case 0:
                                                                        r.setTagName(t.slice(e, c)), h = 6;
                                                                        break;
                                                                    case 1:
                                                                        u = t.slice(e, c), h = 2;
                                                                        break;
                                                                    case 4:
                                                                        var l = t.slice(e, c);
                                                                        a.warning('attribute "' + l + '" missed quot(")!!'), o(u, l, e);
                                                                    case 5:
                                                                        h = 6
                                                                } else switch (h) {
                                                                    case 2:
                                                                        r.tagName, n.isHTML(i[""]) && u.match(/^(?:disabled|checked|selected)$/i) || a.warning('attribute "' + u + '" missed value!! "' + u + '" instead2!!'), o(u, u, e), e = c, h = 1;
                                                                        break;
                                                                    case 5:
                                                                        a.warning('attribute space is required"' + u + '"!!');
                                                                    case 6:
                                                                        h = 1, e = c;
                                                                        break;
                                                                    case 3:
                                                                        h = 4, e = c;
                                                                        break;
                                                                    case 7:
                                                                        throw Error("elements closed character '/' and '>' must be connected to")
                                                                }
                                                        }
                                                        c++
                                                    }
                                                }(t, E, P, C, a, s),
                                                O = P.length;
                                            if (!P.closed && function(t, e, r, n) {
                                                    var i = n[r];
                                                    return null == i && ((i = t.lastIndexOf("</" + r + ">")) < e && (i = t.lastIndexOf("</" + r)), n[r] = i), i < e
                                                }(t, D, P.tagName, v) && (P.closed = !0, r.nbsp || s.warning("unclosed xml attribute")), g && O) {
                                                for (var I = l(g, {}), L = 0; L < O; L++) {
                                                    var M = P[L];
                                                    h(M.offset), M.locator = l(g, {})
                                                }
                                                i.locator = I, c(P, i, C) && y.push(P), i.locator = g
                                            } else c(P, i, C) && y.push(P);
                                            n.isHTML(P.uri) && !P.closed ? D = function(t, e, r, n, i) {
                                                if (/^(?:script|textarea)$/i.test(r)) {
                                                    var s = t.indexOf("</" + r + ">", e),
                                                        a = t.substring(e + 1, s);
                                                    if (/[&<]/.test(a)) return /^script$/i.test(r) || (a = a.replace(/&#?\w+;/g, n)), i.characters(a, 0, a.length), s
                                                }
                                                return e + 1
                                            }(t, D, P.tagName, a, i) : D++
                                    }
                                } catch (t) {
                                    if (t instanceof o) throw t;
                                    s.error("element parse error: " + t), D = -1
                                }
                                D > b ? b = D : u(Math.max(E, b) + 1)
                            }
                        }(t, e, r, i, this.errorHandler), i.endDocument()
                }
            }, f.prototype = {
                setTagName: function(t) {
                    if (!a.test(t)) throw Error("invalid tagName:" + t);
                    this.tagName = t
                },
                addValue: function(t, e, r) {
                    if (!a.test(t)) throw Error("invalid attribute:" + t);
                    this.attributeNames[t] = this.length, this[this.length++] = {
                        qName: t,
                        value: e,
                        offset: r
                    }
                },
                length: 0,
                getLocalName: function(t) {
                    return this[t].localName
                },
                getLocator: function(t) {
                    return this[t].locator
                },
                getQName: function(t) {
                    return this[t].qName
                },
                getURI: function(t) {
                    return this[t].uri
                },
                getValue: function(t) {
                    return this[t].value
                }
            }, e.XMLReader = u, e.ParseError = o
        },
        4856: function(t, e, r) {
            var n, i = void 0 !== r.g ? r.g : "undefined" != typeof window ? window : {},
                s = r(7579);
            "undefined" != typeof document ? n = document : (n = i["__GLOBAL_DOCUMENT_CACHE@4"]) || (n = i["__GLOBAL_DOCUMENT_CACHE@4"] = s), t.exports = n
        },
        6076: function(t, e, r) {
            var n;
            "undefined" != typeof window ? n = window : void 0 !== r.g ? n = r.g : "undefined" != typeof self ? n = self : n = {}, t.exports = n
        },
        4361: function(t) {
            t.exports = function(t) {
                if (!t) return !1;
                var r = e.call(t);
                return "[object Function]" === r || "function" == typeof t && "[object RegExp]" !== r || "undefined" != typeof window && (t === window.setTimeout || t === window.alert || t === window.confirm || t === window.prompt)
            };
            var e = Object.prototype.toString
        },
        6377: function(t, e) {
            function r(t) {
                if (t && "object" == typeof t) {
                    var e = t.which || t.keyCode || t.charCode;
                    e && (t = e)
                }
                if ("number" == typeof t) return a[t];
                var r = String(t),
                    s = n[r.toLowerCase()];
                if (s) return s;
                var s = i[r.toLowerCase()];
                return s || (1 === r.length ? r.charCodeAt(0) : void 0)
            }
            r.isEventKey = function(t, e) {
                if (t && "object" == typeof t) {
                    var r = t.which || t.keyCode || t.charCode;
                    if (null == r) return !1;
                    if ("string" == typeof e) {
                        var s = n[e.toLowerCase()];
                        if (s) return s === r;
                        var s = i[e.toLowerCase()];
                        if (s) return s === r
                    } else if ("number" == typeof e) return e === r;
                    return !1
                }
            };
            var n = (e = t.exports = r).code = e.codes = {
                    backspace: 8,
                    tab: 9,
                    enter: 13,
                    shift: 16,
                    ctrl: 17,
                    alt: 18,
                    "pause/break": 19,
                    "caps lock": 20,
                    esc: 27,
                    space: 32,
                    "page up": 33,
                    "page down": 34,
                    end: 35,
                    home: 36,
                    left: 37,
                    up: 38,
                    right: 39,
                    down: 40,
                    insert: 45,
                    delete: 46,
                    command: 91,
                    "left command": 91,
                    "right command": 93,
                    "numpad *": 106,
                    "numpad +": 107,
                    "numpad -": 109,
                    "numpad .": 110,
                    "numpad /": 111,
                    "num lock": 144,
                    "scroll lock": 145,
                    "my computer": 182,
                    "my calculator": 183,
                    ";": 186,
                    "=": 187,
                    ",": 188,
                    "-": 189,
                    ".": 190,
                    "/": 191,
                    "`": 192,
                    "[": 219,
                    "\\": 220,
                    "]": 221,
                    "'": 222
                },
                i = e.aliases = {
                    windows: 91,
                    "⇧": 16,
                    "⌥": 18,
                    "⌃": 17,
                    "⌘": 91,
                    ctl: 17,
                    control: 17,
                    option: 18,
                    pause: 19,
                    break: 19,
                    caps: 20,
                    return: 13,
                    escape: 27,
                    spc: 32,
                    spacebar: 32,
                    pgup: 33,
                    pgdn: 34,
                    ins: 45,
                    del: 46,
                    cmd: 91
                };
            /*!
             * Programatically add the following
             */
            for (s = 97; s < 123; s++) n[String.fromCharCode(s)] = s - 32;
            for (var s = 48; s < 58; s++) n[s - 48] = s;
            for (s = 1; s < 13; s++) n["f" + s] = s + 111;
            for (s = 0; s < 10; s++) n["numpad " + s] = s + 96;
            var a = e.names = e.title = {};
            for (s in n) a[n[s]] = s;
            for (var o in i) n[o] = i[o]
        },
        7714: function(t, e, r) {
            "use strict";
            r.d(e, {
                _b: function() {
                    return m
                }
            });
            var n = function() {
                    function t() {
                        this.listeners = {}
                    }
                    var e = t.prototype;
                    return e.on = function(t, e) {
                        this.listeners[t] || (this.listeners[t] = []), this.listeners[t].push(e)
                    }, e.off = function(t, e) {
                        if (!this.listeners[t]) return !1;
                        var r = this.listeners[t].indexOf(e);
                        return this.listeners[t] = this.listeners[t].slice(0), this.listeners[t].splice(r, 1), r > -1
                    }, e.trigger = function(t) {
                        var e = this.listeners[t];
                        if (e) {
                            if (2 == arguments.length)
                                for (var r = e.length, n = 0; n < r; ++n) e[n].call(this, arguments[1]);
                            else
                                for (var i = Array.prototype.slice.call(arguments, 1), s = e.length, a = 0; a < s; ++a) e[a].apply(this, i)
                        }
                    }, e.dispose = function() {
                        this.listeners = {}
                    }, e.pipe = function(t) {
                        this.on("data", function(e) {
                            t.push(e)
                        })
                    }, t
                }(),
                i = r(2988),
                s = r(6076),
                a = r.n(s),
                o = r(6300).Buffer; /*! @name m3u8-parser @version 7.1.0 @license Apache-2.0 */
            class u extends n {
                constructor() {
                    super(), this.buffer = ""
                }
                push(t) {
                    let e;
                    for (this.buffer += t, e = this.buffer.indexOf("\n"); e > -1; e = this.buffer.indexOf("\n")) this.trigger("data", this.buffer.substring(0, e)), this.buffer = this.buffer.substring(e + 1)
                }
            }
            let l = function(t) {
                    let e = /([0-9.]*)?@?([0-9.]*)?/.exec(t || ""),
                        r = {};
                    return e[1] && (r.length = parseInt(e[1], 10)), e[2] && (r.offset = parseInt(e[2], 10)), r
                },
                c = function(t) {
                    let e;
                    let r = {};
                    if (!t) return r;
                    let n = t.split(RegExp('(?:^|,)((?:[^=]*)=(?:"[^"]*"|[^,]*))')),
                        i = n.length;
                    for (; i--;) "" !== n[i] && ((e = /([^=]*)=(.*)/.exec(n[i]).slice(1))[0] = e[0].replace(/^\s+|\s+$/g, ""), e[1] = e[1].replace(/^\s+|\s+$/g, ""), e[1] = e[1].replace(/^['"](.*)['"]$/g, "$1"), r[e[0]] = e[1]);
                    return r
                };
            class h extends n {
                constructor() {
                    super(), this.customParsers = [], this.tagMappers = []
                }
                push(t) {
                    let e, r;
                    if (0 !== (t = t.trim()).length) {
                        if ("#" !== t[0]) {
                            this.trigger("data", {
                                type: "uri",
                                uri: t
                            });
                            return
                        }
                        this.tagMappers.reduce((e, r) => {
                            let n = r(t);
                            return n === t ? e : e.concat([n])
                        }, [t]).forEach(t => {
                            for (let e = 0; e < this.customParsers.length; e++)
                                if (this.customParsers[e].call(this, t)) return;
                            if (0 !== t.indexOf("#EXT")) {
                                this.trigger("data", {
                                    type: "comment",
                                    text: t.slice(1)
                                });
                                return
                            }
                            if (t = t.replace("\r", ""), e = /^#EXTM3U/.exec(t)) {
                                this.trigger("data", {
                                    type: "tag",
                                    tagType: "m3u"
                                });
                                return
                            }
                            if (e = /^#EXTINF:([0-9\.]*)?,?(.*)?$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "inf"
                                }, e[1] && (r.duration = parseFloat(e[1])), e[2] && (r.title = e[2]), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-TARGETDURATION:([0-9.]*)?/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "targetduration"
                                }, e[1] && (r.duration = parseInt(e[1], 10)), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-VERSION:([0-9.]*)?/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "version"
                                }, e[1] && (r.version = parseInt(e[1], 10)), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-MEDIA-SEQUENCE:(\-?[0-9.]*)?/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "media-sequence"
                                }, e[1] && (r.number = parseInt(e[1], 10)), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-DISCONTINUITY-SEQUENCE:(\-?[0-9.]*)?/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "discontinuity-sequence"
                                }, e[1] && (r.number = parseInt(e[1], 10)), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-PLAYLIST-TYPE:(.*)?$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "playlist-type"
                                }, e[1] && (r.playlistType = e[1]), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-BYTERANGE:(.*)?$/.exec(t)) {
                                r = (0, i.Z)(l(e[1]), {
                                    type: "tag",
                                    tagType: "byterange"
                                }), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-ALLOW-CACHE:(YES|NO)?/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "allow-cache"
                                }, e[1] && (r.allowed = !/NO/.test(e[1])), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-MAP:(.*)$/.exec(t)) {
                                if (r = {
                                        type: "tag",
                                        tagType: "map"
                                    }, e[1]) {
                                    let t = c(e[1]);
                                    t.URI && (r.uri = t.URI), t.BYTERANGE && (r.byterange = l(t.BYTERANGE))
                                }
                                this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-STREAM-INF:(.*)$/.exec(t)) {
                                if (r = {
                                        type: "tag",
                                        tagType: "stream-inf"
                                    }, e[1]) {
                                    if (r.attributes = c(e[1]), r.attributes.RESOLUTION) {
                                        let t = r.attributes.RESOLUTION.split("x"),
                                            e = {};
                                        t[0] && (e.width = parseInt(t[0], 10)), t[1] && (e.height = parseInt(t[1], 10)), r.attributes.RESOLUTION = e
                                    }
                                    r.attributes.BANDWIDTH && (r.attributes.BANDWIDTH = parseInt(r.attributes.BANDWIDTH, 10)), r.attributes["FRAME-RATE"] && (r.attributes["FRAME-RATE"] = parseFloat(r.attributes["FRAME-RATE"])), r.attributes["PROGRAM-ID"] && (r.attributes["PROGRAM-ID"] = parseInt(r.attributes["PROGRAM-ID"], 10))
                                }
                                this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-MEDIA:(.*)$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "media"
                                }, e[1] && (r.attributes = c(e[1])), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-ENDLIST/.exec(t)) {
                                this.trigger("data", {
                                    type: "tag",
                                    tagType: "endlist"
                                });
                                return
                            }
                            if (e = /^#EXT-X-DISCONTINUITY/.exec(t)) {
                                this.trigger("data", {
                                    type: "tag",
                                    tagType: "discontinuity"
                                });
                                return
                            }
                            if (e = /^#EXT-X-PROGRAM-DATE-TIME:(.*)$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "program-date-time"
                                }, e[1] && (r.dateTimeString = e[1], r.dateTimeObject = new Date(e[1])), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-KEY:(.*)$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "key"
                                }, e[1] && (r.attributes = c(e[1]), r.attributes.IV && ("0x" === r.attributes.IV.substring(0, 2).toLowerCase() && (r.attributes.IV = r.attributes.IV.substring(2)), r.attributes.IV = r.attributes.IV.match(/.{8}/g), r.attributes.IV[0] = parseInt(r.attributes.IV[0], 16), r.attributes.IV[1] = parseInt(r.attributes.IV[1], 16), r.attributes.IV[2] = parseInt(r.attributes.IV[2], 16), r.attributes.IV[3] = parseInt(r.attributes.IV[3], 16), r.attributes.IV = new Uint32Array(r.attributes.IV))), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-START:(.*)$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "start"
                                }, e[1] && (r.attributes = c(e[1]), r.attributes["TIME-OFFSET"] = parseFloat(r.attributes["TIME-OFFSET"]), r.attributes.PRECISE = /YES/.test(r.attributes.PRECISE)), this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-CUE-OUT-CONT:(.*)?$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "cue-out-cont"
                                }, e[1] ? r.data = e[1] : r.data = "", this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-CUE-OUT:(.*)?$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "cue-out"
                                }, e[1] ? r.data = e[1] : r.data = "", this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-CUE-IN:(.*)?$/.exec(t)) {
                                r = {
                                    type: "tag",
                                    tagType: "cue-in"
                                }, e[1] ? r.data = e[1] : r.data = "", this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-SKIP:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "skip"
                                }).attributes = c(e[1]), r.attributes.hasOwnProperty("SKIPPED-SEGMENTS") && (r.attributes["SKIPPED-SEGMENTS"] = parseInt(r.attributes["SKIPPED-SEGMENTS"], 10)), r.attributes.hasOwnProperty("RECENTLY-REMOVED-DATERANGES") && (r.attributes["RECENTLY-REMOVED-DATERANGES"] = r.attributes["RECENTLY-REMOVED-DATERANGES"].split("	")), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-PART:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "part"
                                }).attributes = c(e[1]), ["DURATION"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = parseFloat(r.attributes[t]))
                                }), ["INDEPENDENT", "GAP"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = /YES/.test(r.attributes[t]))
                                }), r.attributes.hasOwnProperty("BYTERANGE") && (r.attributes.byterange = l(r.attributes.BYTERANGE)), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-SERVER-CONTROL:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "server-control"
                                }).attributes = c(e[1]), ["CAN-SKIP-UNTIL", "PART-HOLD-BACK", "HOLD-BACK"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = parseFloat(r.attributes[t]))
                                }), ["CAN-SKIP-DATERANGES", "CAN-BLOCK-RELOAD"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = /YES/.test(r.attributes[t]))
                                }), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-PART-INF:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "part-inf"
                                }).attributes = c(e[1]), ["PART-TARGET"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = parseFloat(r.attributes[t]))
                                }), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-PRELOAD-HINT:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "preload-hint"
                                }).attributes = c(e[1]), ["BYTERANGE-START", "BYTERANGE-LENGTH"].forEach(function(t) {
                                    if (r.attributes.hasOwnProperty(t)) {
                                        r.attributes[t] = parseInt(r.attributes[t], 10);
                                        let e = "BYTERANGE-LENGTH" === t ? "length" : "offset";
                                        r.attributes.byterange = r.attributes.byterange || {}, r.attributes.byterange[e] = r.attributes[t], delete r.attributes[t]
                                    }
                                }), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-RENDITION-REPORT:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "rendition-report"
                                }).attributes = c(e[1]), ["LAST-MSN", "LAST-PART"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = parseInt(r.attributes[t], 10))
                                }), this.trigger("data", r);
                                return
                            }
                            if ((e = /^#EXT-X-DATERANGE:(.*)$/.exec(t)) && e[1]) {
                                (r = {
                                    type: "tag",
                                    tagType: "daterange"
                                }).attributes = c(e[1]), ["ID", "CLASS"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = String(r.attributes[t]))
                                }), ["START-DATE", "END-DATE"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = new Date(r.attributes[t]))
                                }), ["DURATION", "PLANNED-DURATION"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = parseFloat(r.attributes[t]))
                                }), ["END-ON-NEXT"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = /YES/i.test(r.attributes[t]))
                                }), ["SCTE35-CMD", " SCTE35-OUT", "SCTE35-IN"].forEach(function(t) {
                                    r.attributes.hasOwnProperty(t) && (r.attributes[t] = r.attributes[t].toString(16))
                                });
                                let t = /^X-([A-Z]+-)+[A-Z]+$/;
                                for (let e in r.attributes) {
                                    if (!t.test(e)) continue;
                                    let n = /[0-9A-Fa-f]{6}/g.test(r.attributes[e]),
                                        i = /^\d+(\.\d+)?$/.test(r.attributes[e]);
                                    r.attributes[e] = n ? r.attributes[e].toString(16) : i ? parseFloat(r.attributes[e]) : String(r.attributes[e])
                                }
                                this.trigger("data", r);
                                return
                            }
                            if (e = /^#EXT-X-INDEPENDENT-SEGMENTS/.exec(t)) {
                                this.trigger("data", {
                                    type: "tag",
                                    tagType: "independent-segments"
                                });
                                return
                            }
                            if (e = /^#EXT-X-CONTENT-STEERING:(.*)$/.exec(t)) {
                                (r = {
                                    type: "tag",
                                    tagType: "content-steering"
                                }).attributes = c(e[1]), this.trigger("data", r);
                                return
                            }
                            this.trigger("data", {
                                type: "tag",
                                data: t.slice(4)
                            })
                        })
                    }
                }
                addParser({
                    expression: t,
                    customType: e,
                    dataParser: r,
                    segment: n
                }) {
                    "function" != typeof r && (r = t => t), this.customParsers.push(i => {
                        if (t.exec(i)) return this.trigger("data", {
                            type: "custom",
                            data: r(i),
                            customType: e,
                            segment: n
                        }), !0
                    })
                }
                addTagMapper({
                    expression: t,
                    map: e
                }) {
                    this.tagMappers.push(r => t.test(r) ? e(r) : r)
                }
            }
            let f = t => t.toLowerCase().replace(/-(\w)/g, t => t[1].toUpperCase()),
                p = function(t) {
                    let e = {};
                    return Object.keys(t).forEach(function(r) {
                        e[f(r)] = t[r]
                    }), e
                },
                d = function(t) {
                    let {
                        serverControl: e,
                        targetDuration: r,
                        partTargetDuration: n
                    } = t;
                    if (!e) return;
                    let i = "#EXT-X-SERVER-CONTROL",
                        s = "holdBack",
                        a = "partHoldBack",
                        o = r && 3 * r,
                        u = n && 2 * n;
                    r && !e.hasOwnProperty(s) && (e[s] = o, this.trigger("info", {
                        message: `${i} defaulting HOLD-BACK to targetDuration * 3 (${o}).`
                    })), o && e[s] < o && (this.trigger("warn", {
                        message: `${i} clamping HOLD-BACK (${e[s]}) to targetDuration * 3 (${o})`
                    }), e[s] = o), n && !e.hasOwnProperty(a) && (e[a] = 3 * n, this.trigger("info", {
                        message: `${i} defaulting PART-HOLD-BACK to partTargetDuration * 3 (${e[a]}).`
                    })), n && e[a] < u && (this.trigger("warn", {
                        message: `${i} clamping PART-HOLD-BACK (${e[a]}) to partTargetDuration * 2 (${u}).`
                    }), e[a] = u)
                };
            class m extends n {
                constructor() {
                    let t, e;
                    super(), this.lineStream = new u, this.parseStream = new h, this.lineStream.pipe(this.parseStream), this.lastProgramDateTime = null;
                    let r = this,
                        n = [],
                        s = {},
                        l = !1,
                        c = function() {},
                        f = {
                            AUDIO: {},
                            VIDEO: {},
                            "CLOSED-CAPTIONS": {},
                            SUBTITLES: {}
                        },
                        m = 0;
                    this.manifest = {
                        allowCache: !0,
                        discontinuityStarts: [],
                        dateRanges: [],
                        segments: []
                    };
                    let g = 0,
                        y = 0,
                        v = {};
                    this.on("end", () => {
                        !s.uri && (s.parts || s.preloadHints) && (!s.map && t && (s.map = t), !s.key && e && (s.key = e), s.timeline || "number" != typeof m || (s.timeline = m), this.manifest.preloadSegment = s)
                    }), this.parseStream.on("data", function(u) {
                        let h, b;
                        ({
                            tag() {
                                (({
                                    version() {
                                        u.version && (this.manifest.version = u.version)
                                    },
                                    "allow-cache" () {
                                        this.manifest.allowCache = u.allowed, "allowed" in u || (this.trigger("info", {
                                            message: "defaulting allowCache to YES"
                                        }), this.manifest.allowCache = !0)
                                    },
                                    byterange() {
                                        let t = {};
                                        "length" in u && (s.byterange = t, t.length = u.length, "offset" in u || (u.offset = g)), "offset" in u && (s.byterange = t, t.offset = u.offset), g = t.offset + t.length
                                    },
                                    endlist() {
                                        this.manifest.endList = !0
                                    },
                                    inf() {
                                        "mediaSequence" in this.manifest || (this.manifest.mediaSequence = 0, this.trigger("info", {
                                            message: "defaulting media sequence to zero"
                                        })), "discontinuitySequence" in this.manifest || (this.manifest.discontinuitySequence = 0, this.trigger("info", {
                                            message: "defaulting discontinuity sequence to zero"
                                        })), u.title && (s.title = u.title), u.duration > 0 && (s.duration = u.duration), 0 === u.duration && (s.duration = .01, this.trigger("info", {
                                            message: "updating zero segment duration to a small value"
                                        })), this.manifest.segments = n
                                    },
                                    key() {
                                        if (!u.attributes) {
                                            this.trigger("warn", {
                                                message: "ignoring key declaration without attribute list"
                                            });
                                            return
                                        }
                                        if ("NONE" === u.attributes.METHOD) {
                                            e = null;
                                            return
                                        }
                                        if (!u.attributes.URI) {
                                            this.trigger("warn", {
                                                message: "ignoring key declaration without URI"
                                            });
                                            return
                                        }
                                        if ("com.apple.streamingkeydelivery" === u.attributes.KEYFORMAT) {
                                            this.manifest.contentProtection = this.manifest.contentProtection || {}, this.manifest.contentProtection["com.apple.fps.1_0"] = {
                                                attributes: u.attributes
                                            };
                                            return
                                        }
                                        if ("com.microsoft.playready" === u.attributes.KEYFORMAT) {
                                            this.manifest.contentProtection = this.manifest.contentProtection || {}, this.manifest.contentProtection["com.microsoft.playready"] = {
                                                uri: u.attributes.URI
                                            };
                                            return
                                        }
                                        if ("urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed" === u.attributes.KEYFORMAT) {
                                            if (-1 === ["SAMPLE-AES", "SAMPLE-AES-CTR", "SAMPLE-AES-CENC"].indexOf(u.attributes.METHOD)) {
                                                this.trigger("warn", {
                                                    message: "invalid key method provided for Widevine"
                                                });
                                                return
                                            }
                                            if ("SAMPLE-AES-CENC" === u.attributes.METHOD && this.trigger("warn", {
                                                    message: "SAMPLE-AES-CENC is deprecated, please use SAMPLE-AES-CTR instead"
                                                }), "data:text/plain;base64," !== u.attributes.URI.substring(0, 23)) {
                                                this.trigger("warn", {
                                                    message: "invalid key URI provided for Widevine"
                                                });
                                                return
                                            }
                                            if (!(u.attributes.KEYID && "0x" === u.attributes.KEYID.substring(0, 2))) {
                                                this.trigger("warn", {
                                                    message: "invalid key ID provided for Widevine"
                                                });
                                                return
                                            }
                                            this.manifest.contentProtection = this.manifest.contentProtection || {}, this.manifest.contentProtection["com.widevine.alpha"] = {
                                                attributes: {
                                                    schemeIdUri: u.attributes.KEYFORMAT,
                                                    keyId: u.attributes.KEYID.substring(2)
                                                },
                                                pssh: function(t) {
                                                    for (var e = a().atob ? a().atob(t) : o.from(t, "base64").toString("binary"), r = new Uint8Array(e.length), n = 0; n < e.length; n++) r[n] = e.charCodeAt(n);
                                                    return r
                                                }(u.attributes.URI.split(",")[1])
                                            };
                                            return
                                        }
                                        u.attributes.METHOD || this.trigger("warn", {
                                            message: "defaulting key method to AES-128"
                                        }), e = {
                                            method: u.attributes.METHOD || "AES-128",
                                            uri: u.attributes.URI
                                        }, void 0 !== u.attributes.IV && (e.iv = u.attributes.IV)
                                    },
                                    "media-sequence" () {
                                        if (!isFinite(u.number)) {
                                            this.trigger("warn", {
                                                message: "ignoring invalid media sequence: " + u.number
                                            });
                                            return
                                        }
                                        this.manifest.mediaSequence = u.number
                                    },
                                    "discontinuity-sequence" () {
                                        if (!isFinite(u.number)) {
                                            this.trigger("warn", {
                                                message: "ignoring invalid discontinuity sequence: " + u.number
                                            });
                                            return
                                        }
                                        this.manifest.discontinuitySequence = u.number, m = u.number
                                    },
                                    "playlist-type" () {
                                        if (!/VOD|EVENT/.test(u.playlistType)) {
                                            this.trigger("warn", {
                                                message: "ignoring unknown playlist type: " + u.playlist
                                            });
                                            return
                                        }
                                        this.manifest.playlistType = u.playlistType
                                    },
                                    map() {
                                        t = {}, u.uri && (t.uri = u.uri), u.byterange && (t.byterange = u.byterange), e && (t.key = e)
                                    },
                                    "stream-inf" () {
                                        if (this.manifest.playlists = n, this.manifest.mediaGroups = this.manifest.mediaGroups || f, !u.attributes) {
                                            this.trigger("warn", {
                                                message: "ignoring empty stream-inf attributes"
                                            });
                                            return
                                        }
                                        s.attributes || (s.attributes = {}), (0, i.Z)(s.attributes, u.attributes)
                                    },
                                    media() {
                                        if (this.manifest.mediaGroups = this.manifest.mediaGroups || f, !(u.attributes && u.attributes.TYPE && u.attributes["GROUP-ID"] && u.attributes.NAME)) {
                                            this.trigger("warn", {
                                                message: "ignoring incomplete or missing media group"
                                            });
                                            return
                                        }
                                        let t = this.manifest.mediaGroups[u.attributes.TYPE];
                                        t[u.attributes["GROUP-ID"]] = t[u.attributes["GROUP-ID"]] || {}, h = t[u.attributes["GROUP-ID"]], (b = {
                                            default: /yes/i.test(u.attributes.DEFAULT)
                                        }).default ? b.autoselect = !0 : b.autoselect = /yes/i.test(u.attributes.AUTOSELECT), u.attributes.LANGUAGE && (b.language = u.attributes.LANGUAGE), u.attributes.URI && (b.uri = u.attributes.URI), u.attributes["INSTREAM-ID"] && (b.instreamId = u.attributes["INSTREAM-ID"]), u.attributes.CHARACTERISTICS && (b.characteristics = u.attributes.CHARACTERISTICS), u.attributes.FORCED && (b.forced = /yes/i.test(u.attributes.FORCED)), h[u.attributes.NAME] = b
                                    },
                                    discontinuity() {
                                        m += 1, s.discontinuity = !0, this.manifest.discontinuityStarts.push(n.length)
                                    },
                                    "program-date-time" () {
                                        void 0 === this.manifest.dateTimeString && (this.manifest.dateTimeString = u.dateTimeString, this.manifest.dateTimeObject = u.dateTimeObject), s.dateTimeString = u.dateTimeString, s.dateTimeObject = u.dateTimeObject;
                                        let {
                                            lastProgramDateTime: t
                                        } = this;
                                        this.lastProgramDateTime = new Date(u.dateTimeString).getTime(), null === t && this.manifest.segments.reduceRight((t, e) => (e.programDateTime = t - 1e3 * e.duration, e.programDateTime), this.lastProgramDateTime)
                                    },
                                    targetduration() {
                                        if (!isFinite(u.duration) || u.duration < 0) {
                                            this.trigger("warn", {
                                                message: "ignoring invalid target duration: " + u.duration
                                            });
                                            return
                                        }
                                        this.manifest.targetDuration = u.duration, d.call(this, this.manifest)
                                    },
                                    start() {
                                        if (!u.attributes || isNaN(u.attributes["TIME-OFFSET"])) {
                                            this.trigger("warn", {
                                                message: "ignoring start declaration without appropriate attribute list"
                                            });
                                            return
                                        }
                                        this.manifest.start = {
                                            timeOffset: u.attributes["TIME-OFFSET"],
                                            precise: u.attributes.PRECISE
                                        }
                                    },
                                    "cue-out" () {
                                        s.cueOut = u.data
                                    },
                                    "cue-out-cont" () {
                                        s.cueOutCont = u.data
                                    },
                                    "cue-in" () {
                                        s.cueIn = u.data
                                    },
                                    skip() {
                                        this.manifest.skip = p(u.attributes), this.warnOnMissingAttributes_("#EXT-X-SKIP", u.attributes, ["SKIPPED-SEGMENTS"])
                                    },
                                    part() {
                                        l = !0;
                                        let t = this.manifest.segments.length,
                                            e = p(u.attributes);
                                        s.parts = s.parts || [], s.parts.push(e), e.byterange && (e.byterange.hasOwnProperty("offset") || (e.byterange.offset = y), y = e.byterange.offset + e.byterange.length);
                                        let r = s.parts.length - 1;
                                        this.warnOnMissingAttributes_(`#EXT-X-PART #${r} for segment #${t}`, u.attributes, ["URI", "DURATION"]), this.manifest.renditionReports && this.manifest.renditionReports.forEach((t, e) => {
                                            t.hasOwnProperty("lastPart") || this.trigger("warn", {
                                                message: `#EXT-X-RENDITION-REPORT #${e} lacks required attribute(s): LAST-PART`
                                            })
                                        })
                                    },
                                    "server-control" () {
                                        let t = this.manifest.serverControl = p(u.attributes);
                                        t.hasOwnProperty("canBlockReload") || (t.canBlockReload = !1, this.trigger("info", {
                                            message: "#EXT-X-SERVER-CONTROL defaulting CAN-BLOCK-RELOAD to false"
                                        })), d.call(this, this.manifest), t.canSkipDateranges && !t.hasOwnProperty("canSkipUntil") && this.trigger("warn", {
                                            message: "#EXT-X-SERVER-CONTROL lacks required attribute CAN-SKIP-UNTIL which is required when CAN-SKIP-DATERANGES is set"
                                        })
                                    },
                                    "preload-hint" () {
                                        let t = this.manifest.segments.length,
                                            e = p(u.attributes),
                                            r = e.type && "PART" === e.type;
                                        s.preloadHints = s.preloadHints || [], s.preloadHints.push(e), e.byterange && !e.byterange.hasOwnProperty("offset") && (e.byterange.offset = r ? y : 0, r && (y = e.byterange.offset + e.byterange.length));
                                        let n = s.preloadHints.length - 1;
                                        if (this.warnOnMissingAttributes_(`#EXT-X-PRELOAD-HINT #${n} for segment #${t}`, u.attributes, ["TYPE", "URI"]), e.type)
                                            for (let r = 0; r < s.preloadHints.length - 1; r++) {
                                                let i = s.preloadHints[r];
                                                i.type && i.type === e.type && this.trigger("warn", {
                                                    message: `#EXT-X-PRELOAD-HINT #${n} for segment #${t} has the same TYPE ${e.type} as preload hint #${r}`
                                                })
                                            }
                                    },
                                    "rendition-report" () {
                                        let t = p(u.attributes);
                                        this.manifest.renditionReports = this.manifest.renditionReports || [], this.manifest.renditionReports.push(t);
                                        let e = this.manifest.renditionReports.length - 1,
                                            r = ["LAST-MSN", "URI"];
                                        l && r.push("LAST-PART"), this.warnOnMissingAttributes_(`#EXT-X-RENDITION-REPORT #${e}`, u.attributes, r)
                                    },
                                    "part-inf" () {
                                        this.manifest.partInf = p(u.attributes), this.warnOnMissingAttributes_("#EXT-X-PART-INF", u.attributes, ["PART-TARGET"]), this.manifest.partInf.partTarget && (this.manifest.partTargetDuration = this.manifest.partInf.partTarget), d.call(this, this.manifest)
                                    },
                                    daterange() {
                                        this.manifest.dateRanges.push(p(u.attributes));
                                        let t = this.manifest.dateRanges.length - 1;
                                        this.warnOnMissingAttributes_(`#EXT-X-DATERANGE #${t}`, u.attributes, ["ID", "START-DATE"]);
                                        let e = this.manifest.dateRanges[t];
                                        e.endDate && e.startDate && new Date(e.endDate) < new Date(e.startDate) && this.trigger("warn", {
                                            message: "EXT-X-DATERANGE END-DATE must be equal to or later than the value of the START-DATE"
                                        }), e.duration && e.duration < 0 && this.trigger("warn", {
                                            message: "EXT-X-DATERANGE DURATION must not be negative"
                                        }), e.plannedDuration && e.plannedDuration < 0 && this.trigger("warn", {
                                            message: "EXT-X-DATERANGE PLANNED-DURATION must not be negative"
                                        });
                                        let r = !!e.endOnNext;
                                        if (r && !e.class && this.trigger("warn", {
                                                message: "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must have a CLASS attribute"
                                            }), r && (e.duration || e.endDate) && this.trigger("warn", {
                                                message: "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must not contain DURATION or END-DATE attributes"
                                            }), e.duration && e.endDate) {
                                            let r = e.startDate.getTime() + 1e3 * e.duration;
                                            this.manifest.dateRanges[t].endDate = new Date(r)
                                        }
                                        if (v[e.id]) {
                                            for (let t in v[e.id])
                                                if (e[t] && JSON.stringify(v[e.id][t]) !== JSON.stringify(e[t])) {
                                                    this.trigger("warn", {
                                                        message: "EXT-X-DATERANGE tags with the same ID in a playlist must have the same attributes values"
                                                    });
                                                    break
                                                }
                                            let t = this.manifest.dateRanges.findIndex(t => t.id === e.id);
                                            this.manifest.dateRanges[t] = (0, i.Z)(this.manifest.dateRanges[t], e), v[e.id] = (0, i.Z)(v[e.id], e), this.manifest.dateRanges.pop()
                                        } else v[e.id] = e
                                    },
                                    "independent-segments" () {
                                        this.manifest.independentSegments = !0
                                    },
                                    "content-steering" () {
                                        this.manifest.contentSteering = p(u.attributes), this.warnOnMissingAttributes_("#EXT-X-CONTENT-STEERING", u.attributes, ["SERVER-URI"])
                                    }
                                })[u.tagType] || c).call(r)
                            },
                            uri() {
                                s.uri = u.uri, n.push(s), !this.manifest.targetDuration || "duration" in s || (this.trigger("warn", {
                                    message: "defaulting segment duration to the target duration"
                                }), s.duration = this.manifest.targetDuration), e && (s.key = e), s.timeline = m, t && (s.map = t), y = 0, null !== this.lastProgramDateTime && (s.programDateTime = this.lastProgramDateTime, this.lastProgramDateTime += 1e3 * s.duration), s = {}
                            },
                            comment() {},
                            custom() {
                                u.segment ? (s.custom = s.custom || {}, s.custom[u.customType] = u.data) : (this.manifest.custom = this.manifest.custom || {}, this.manifest.custom[u.customType] = u.data)
                            }
                        })[u.type].call(r)
                    })
                }
                warnOnMissingAttributes_(t, e, r) {
                    let n = [];
                    r.forEach(function(t) {
                        e.hasOwnProperty(t) || n.push(t)
                    }), n.length && this.trigger("warn", {
                        message: `${t} lacks required attribute(s): ${n.join(", ")}`
                    })
                }
                push(t) {
                    this.lineStream.push(t)
                }
                end() {
                    this.lineStream.push("\n"), this.manifest.dateRanges.length && null === this.lastProgramDateTime && this.trigger("warn", {
                        message: "A playlist with EXT-X-DATERANGE tag must contain atleast one EXT-X-PROGRAM-DATE-TIME tag"
                    }), this.lastProgramDateTime = null, this.trigger("end")
                }
                addParser(t) {
                    this.parseStream.addParser(t)
                }
                addTagMapper(t) {
                    this.parseStream.addTagMapper(t)
                }
            }
        },
        6165: function(t, e, r) {
            "use strict";
            r.d(e, {
                jp: function() {
                    return S
                },
                mm: function() {
                    return M
                },
                Qc: function() {
                    return tN
                },
                LG: function() {
                    return tP
                }
            });
            var n = r(150),
                i = r(6076),
                s = r.n(i),
                a = function(t, e, r) {
                    e.forEach(function(e) {
                        for (var n in t.mediaGroups[e])
                            for (var i in t.mediaGroups[e][n]) r(t.mediaGroups[e][n][i], e, n, i)
                    })
                },
                o = r(6300).Buffer,
                u = r(9432);
            let l = t => !!t && "object" == typeof t,
                c = (...t) => t.reduce((t, e) => ("object" != typeof e || Object.keys(e).forEach(r => {
                    Array.isArray(t[r]) && Array.isArray(e[r]) ? t[r] = t[r].concat(e[r]) : l(t[r]) && l(e[r]) ? t[r] = c(t[r], e[r]) : t[r] = e[r]
                }), t), {}),
                h = t => Object.keys(t).map(e => t[e]),
                f = (t, e) => {
                    let r = [];
                    for (let n = t; n < e; n++) r.push(n);
                    return r
                },
                p = t => t.reduce((t, e) => t.concat(e), []),
                d = t => {
                    if (!t.length) return [];
                    let e = [];
                    for (let r = 0; r < t.length; r++) e.push(t[r]);
                    return e
                },
                m = (t, e) => t.reduce((t, r, n) => (r[e] && t.push(n), t), []),
                g = (t, e) => h(t.reduce((t, r) => (r.forEach(r => {
                    t[e(r)] = r
                }), t), {}));
            var y = {
                INVALID_NUMBER_OF_PERIOD: "INVALID_NUMBER_OF_PERIOD",
                DASH_EMPTY_MANIFEST: "DASH_EMPTY_MANIFEST",
                DASH_INVALID_XML: "DASH_INVALID_XML",
                NO_BASE_URL: "NO_BASE_URL",
                SEGMENT_TIME_UNSPECIFIED: "SEGMENT_TIME_UNSPECIFIED",
                UNSUPPORTED_UTC_TIMING_SCHEME: "UNSUPPORTED_UTC_TIMING_SCHEME"
            };
            let v = ({
                    baseUrl: t = "",
                    source: e = "",
                    range: r = "",
                    indexRange: i = ""
                }) => {
                    let a = {
                        uri: e,
                        resolvedUri: (0, n.Z)(t || "", e)
                    };
                    if (r || i) {
                        let t;
                        let e = (r || i).split("-"),
                            n = s().BigInt ? s().BigInt(e[0]) : parseInt(e[0], 10),
                            o = s().BigInt ? s().BigInt(e[1]) : parseInt(e[1], 10);
                        n < Number.MAX_SAFE_INTEGER && "bigint" == typeof n && (n = Number(n)), o < Number.MAX_SAFE_INTEGER && "bigint" == typeof o && (o = Number(o)), "bigint" == typeof(t = "bigint" == typeof o || "bigint" == typeof n ? s().BigInt(o) - s().BigInt(n) + s().BigInt(1) : o - n + 1) && t < Number.MAX_SAFE_INTEGER && (t = Number(t)), a.byterange = {
                            length: t,
                            offset: n
                        }
                    }
                    return a
                },
                b = t => {
                    let e;
                    return e = "bigint" == typeof t.offset || "bigint" == typeof t.length ? s().BigInt(t.offset) + s().BigInt(t.length) - s().BigInt(1) : t.offset + t.length - 1, `${t.offset}-${e}`
                },
                E = t => (t && "number" != typeof t && (t = parseInt(t, 10)), isNaN(t)) ? null : t,
                w = {
                    static(t) {
                        let {
                            duration: e,
                            timescale: r = 1,
                            sourceDuration: n,
                            periodDuration: i
                        } = t, s = E(t.endNumber), a = e / r;
                        return "number" == typeof s ? {
                            start: 0,
                            end: s
                        } : "number" == typeof i ? {
                            start: 0,
                            end: i / a
                        } : {
                            start: 0,
                            end: n / a
                        }
                    },
                    dynamic(t) {
                        let {
                            NOW: e,
                            clientOffset: r,
                            availabilityStartTime: n,
                            timescale: i = 1,
                            duration: s,
                            periodStart: a = 0,
                            minimumUpdatePeriod: o = 0,
                            timeShiftBufferDepth: u = 1 / 0
                        } = t, l = E(t.endNumber), c = (e + r) / 1e3, h = n + a;
                        return {
                            start: Math.max(0, Math.floor((c - h - u) * i / s)),
                            end: "number" == typeof l ? l : Math.min(Math.ceil((c + o - h) * i / s), Math.floor((c - h) * i / s))
                        }
                    }
                },
                T = t => e => {
                    let {
                        duration: r,
                        timescale: n = 1,
                        periodStart: i,
                        startNumber: s = 1
                    } = t;
                    return {
                        number: s + e,
                        duration: r / n,
                        timeline: i,
                        time: e * r
                    }
                },
                D = t => {
                    let {
                        type: e,
                        duration: r,
                        timescale: n = 1,
                        periodDuration: i,
                        sourceDuration: s
                    } = t, {
                        start: a,
                        end: o
                    } = w[e](t), u = f(a, o).map(T(t));
                    if ("static" === e) {
                        let t = u.length - 1;
                        u[t].duration = ("number" == typeof i ? i : s) - r / n * t
                    }
                    return u
                },
                x = t => {
                    let {
                        baseUrl: e,
                        initialization: r = {},
                        sourceDuration: n,
                        indexRange: i = "",
                        periodStart: s,
                        presentationTime: a,
                        number: o = 0,
                        duration: u
                    } = t;
                    if (!e) throw Error(y.NO_BASE_URL);
                    let l = v({
                            baseUrl: e,
                            source: r.sourceURL,
                            range: r.range
                        }),
                        c = v({
                            baseUrl: e,
                            source: e,
                            indexRange: i
                        });
                    if (c.map = l, u) {
                        let e = D(t);
                        e.length && (c.duration = e[0].duration, c.timeline = e[0].timeline)
                    } else n && (c.duration = n, c.timeline = s);
                    return c.presentationTime = a || s, c.number = o, [c]
                },
                S = (t, e, r) => {
                    let n;
                    let i = t.sidx.map ? t.sidx.map : null,
                        a = t.sidx.duration,
                        o = t.timeline || 0,
                        u = t.sidx.byterange,
                        l = u.offset + u.length,
                        c = e.timescale,
                        h = e.references.filter(t => 1 !== t.referenceType),
                        f = [],
                        p = t.endList ? "static" : "dynamic",
                        d = t.sidx.timeline,
                        m = d,
                        g = t.mediaSequence || 0;
                    n = "bigint" == typeof e.firstOffset ? s().BigInt(l) + e.firstOffset : l + e.firstOffset;
                    for (let t = 0; t < h.length; t++) {
                        let u;
                        let l = e.references[t],
                            h = l.referencedSize,
                            y = l.subsegmentDuration;
                        u = "bigint" == typeof n ? n + s().BigInt(h) - s().BigInt(1) : n + h - 1;
                        let v = x({
                            baseUrl: r,
                            timescale: c,
                            timeline: o,
                            periodStart: d,
                            presentationTime: m,
                            number: g,
                            duration: y,
                            sourceDuration: a,
                            indexRange: `${n}-${u}`,
                            type: p
                        })[0];
                        i && (v.map = i), f.push(v), "bigint" == typeof n ? n += s().BigInt(h) : n += h, m += y / c, g++
                    }
                    return t.segments = f, t
                },
                A = ["AUDIO", "SUBTITLES"],
                R = 1 / 60,
                N = t => g(t, ({
                    timeline: t
                }) => t).sort((t, e) => t.timeline > e.timeline ? 1 : -1),
                P = (t, e) => {
                    for (let r = 0; r < t.length; r++)
                        if (t[r].attributes.NAME === e) return t[r];
                    return null
                },
                C = t => {
                    let e = [];
                    return a(t, A, (t, r, n, i) => {
                        e = e.concat(t.playlists || [])
                    }), e
                },
                O = ({
                    playlist: t,
                    mediaSequence: e
                }) => {
                    t.mediaSequence = e, t.segments.forEach((e, r) => {
                        e.number = t.mediaSequence + r
                    })
                },
                I = ({
                    oldPlaylists: t,
                    newPlaylists: e,
                    timelineStarts: r
                }) => {
                    e.forEach(e => {
                        e.discontinuitySequence = r.findIndex(function({
                            timeline: t
                        }) {
                            return t === e.timeline
                        });
                        let n = P(t, e.attributes.NAME);
                        if (!n || e.sidx) return;
                        let i = e.segments[0],
                            s = n.segments.findIndex(function(t) {
                                return Math.abs(t.presentationTime - i.presentationTime) < R
                            });
                        if (-1 === s) {
                            O({
                                playlist: e,
                                mediaSequence: n.mediaSequence + n.segments.length
                            }), e.segments[0].discontinuity = !0, e.discontinuityStarts.unshift(0), (!n.segments.length && e.timeline > n.timeline || n.segments.length && e.timeline > n.segments[n.segments.length - 1].timeline) && e.discontinuitySequence--;
                            return
                        }
                        n.segments[s].discontinuity && !i.discontinuity && (i.discontinuity = !0, e.discontinuityStarts.unshift(0), e.discontinuitySequence--), O({
                            playlist: e,
                            mediaSequence: n.segments[s].number
                        })
                    })
                },
                L = ({
                    oldManifest: t,
                    newManifest: e
                }) => {
                    let r = t.playlists.concat(C(t)),
                        n = e.playlists.concat(C(e));
                    return e.timelineStarts = N([t.timelineStarts, e.timelineStarts]), I({
                        oldPlaylists: r,
                        newPlaylists: n,
                        timelineStarts: e.timelineStarts
                    }), e
                },
                M = t => t && t.uri + "-" + b(t.byterange),
                k = t => {
                    let e = t.reduce(function(t, e) {
                            return t[e.attributes.baseUrl] || (t[e.attributes.baseUrl] = []), t[e.attributes.baseUrl].push(e), t
                        }, {}),
                        r = [];
                    return Object.values(e).forEach(t => {
                        let e = h(t.reduce((t, e) => {
                            let r = e.attributes.id + (e.attributes.lang || "");
                            return t[r] ? (e.segments && (e.segments[0] && (e.segments[0].discontinuity = !0), t[r].segments.push(...e.segments)), e.attributes.contentProtection && (t[r].attributes.contentProtection = e.attributes.contentProtection)) : (t[r] = e, t[r].attributes.timelineStarts = []), t[r].attributes.timelineStarts.push({
                                start: e.attributes.periodStart,
                                timeline: e.attributes.periodStart
                            }), t
                        }, {}));
                        r = r.concat(e)
                    }), r.map(t => (t.discontinuityStarts = m(t.segments || [], "discontinuity"), t))
                },
                U = (t, e) => {
                    let r = M(t.sidx),
                        n = r && e[r] && e[r].sidx;
                    return n && S(t, n, t.sidx.resolvedUri), t
                },
                B = (t, e = {}) => {
                    if (!Object.keys(e).length) return t;
                    for (let r in t) t[r] = U(t[r], e);
                    return t
                },
                V = ({
                    attributes: t,
                    segments: e,
                    sidx: r,
                    mediaSequence: n,
                    discontinuitySequence: i,
                    discontinuityStarts: s
                }, a) => {
                    let o = {
                        attributes: {
                            NAME: t.id,
                            BANDWIDTH: t.bandwidth,
                            CODECS: t.codecs,
                            "PROGRAM-ID": 1
                        },
                        uri: "",
                        endList: "static" === t.type,
                        timeline: t.periodStart,
                        resolvedUri: t.baseUrl || "",
                        targetDuration: t.duration,
                        discontinuitySequence: i,
                        discontinuityStarts: s,
                        timelineStarts: t.timelineStarts,
                        mediaSequence: n,
                        segments: e
                    };
                    return t.contentProtection && (o.contentProtection = t.contentProtection), t.serviceLocation && (o.attributes.serviceLocation = t.serviceLocation), r && (o.sidx = r), a && (o.attributes.AUDIO = "audio", o.attributes.SUBTITLES = "subs"), o
                },
                j = ({
                    attributes: t,
                    segments: e,
                    mediaSequence: r,
                    discontinuityStarts: n,
                    discontinuitySequence: i
                }) => {
                    void 0 === e && (e = [{
                        uri: t.baseUrl,
                        timeline: t.periodStart,
                        resolvedUri: t.baseUrl || "",
                        duration: t.sourceDuration,
                        number: 0
                    }], t.duration = t.sourceDuration);
                    let s = {
                        NAME: t.id,
                        BANDWIDTH: t.bandwidth,
                        "PROGRAM-ID": 1
                    };
                    t.codecs && (s.CODECS = t.codecs);
                    let a = {
                        attributes: s,
                        uri: "",
                        endList: "static" === t.type,
                        timeline: t.periodStart,
                        resolvedUri: t.baseUrl || "",
                        targetDuration: t.duration,
                        timelineStarts: t.timelineStarts,
                        discontinuityStarts: n,
                        discontinuitySequence: i,
                        mediaSequence: r,
                        segments: e
                    };
                    return t.serviceLocation && (a.attributes.serviceLocation = t.serviceLocation), a
                },
                _ = (t, e = {}, r = !1) => {
                    let n;
                    let i = t.reduce((t, i) => {
                        let s = i.attributes.role && i.attributes.role.value || "",
                            a = i.attributes.lang || "",
                            o = i.attributes.label || "main";
                        if (a && !i.attributes.label) {
                            let t = s ? ` (${s})` : "";
                            o = `${i.attributes.lang}${t}`
                        }
                        t[o] || (t[o] = {
                            language: a,
                            autoselect: !0,
                            default: "main" === s,
                            playlists: [],
                            uri: ""
                        });
                        let u = U(V(i, r), e);
                        return t[o].playlists.push(u), void 0 === n && "main" === s && ((n = i).default = !0), t
                    }, {});
                    if (!n) {
                        let t = Object.keys(i)[0];
                        i[t].default = !0
                    }
                    return i
                },
                q = (t, e = {}) => t.reduce((t, r) => {
                    let n = r.attributes.label || r.attributes.lang || "text";
                    return t[n] || (t[n] = {
                        language: n,
                        default: !1,
                        autoselect: !1,
                        playlists: [],
                        uri: ""
                    }), t[n].playlists.push(U(j(r), e)), t
                }, {}),
                F = t => t.reduce((t, e) => (e && e.forEach(e => {
                    let {
                        channel: r,
                        language: n
                    } = e;
                    t[n] = {
                        autoselect: !1,
                        default: !1,
                        instreamId: r,
                        language: n
                    }, e.hasOwnProperty("aspectRatio") && (t[n].aspectRatio = e.aspectRatio), e.hasOwnProperty("easyReader") && (t[n].easyReader = e.easyReader), e.hasOwnProperty("3D") && (t[n]["3D"] = e["3D"])
                }), t), {}),
                X = ({
                    attributes: t,
                    segments: e,
                    sidx: r,
                    discontinuityStarts: n
                }) => {
                    let i = {
                        attributes: {
                            NAME: t.id,
                            AUDIO: "audio",
                            SUBTITLES: "subs",
                            RESOLUTION: {
                                width: t.width,
                                height: t.height
                            },
                            CODECS: t.codecs,
                            BANDWIDTH: t.bandwidth,
                            "PROGRAM-ID": 1
                        },
                        uri: "",
                        endList: "static" === t.type,
                        timeline: t.periodStart,
                        resolvedUri: t.baseUrl || "",
                        targetDuration: t.duration,
                        discontinuityStarts: n,
                        timelineStarts: t.timelineStarts,
                        segments: e
                    };
                    return t.frameRate && (i.attributes["FRAME-RATE"] = t.frameRate), t.contentProtection && (i.contentProtection = t.contentProtection), t.serviceLocation && (i.attributes.serviceLocation = t.serviceLocation), r && (i.sidx = r), i
                },
                G = ({
                    attributes: t
                }) => "video/mp4" === t.mimeType || "video/webm" === t.mimeType || "video" === t.contentType,
                H = ({
                    attributes: t
                }) => "audio/mp4" === t.mimeType || "audio/webm" === t.mimeType || "audio" === t.contentType,
                $ = ({
                    attributes: t
                }) => "text/vtt" === t.mimeType || "text" === t.contentType,
                z = (t, e) => {
                    t.forEach(t => {
                        t.mediaSequence = 0, t.discontinuitySequence = e.findIndex(function({
                            timeline: e
                        }) {
                            return e === t.timeline
                        }), t.segments && t.segments.forEach((t, e) => {
                            t.number = e
                        })
                    })
                },
                W = t => t ? Object.keys(t).reduce((e, r) => {
                    let n = t[r];
                    return e.concat(n.playlists)
                }, []) : [],
                K = ({
                    dashPlaylists: t,
                    locations: e,
                    contentSteering: r,
                    sidxMapping: n = {},
                    previousManifest: i,
                    eventStream: s
                }) => {
                    if (!t.length) return {};
                    let {
                        sourceDuration: a,
                        type: o,
                        suggestedPresentationDelay: u,
                        minimumUpdatePeriod: l
                    } = t[0].attributes, c = k(t.filter(G)).map(X), h = k(t.filter(H)), f = k(t.filter($)), p = t.map(t => t.attributes.captionServices).filter(Boolean), d = {
                        allowCache: !0,
                        discontinuityStarts: [],
                        segments: [],
                        endList: !0,
                        mediaGroups: {
                            AUDIO: {},
                            VIDEO: {},
                            "CLOSED-CAPTIONS": {},
                            SUBTITLES: {}
                        },
                        uri: "",
                        duration: a,
                        playlists: B(c, n)
                    };
                    l >= 0 && (d.minimumUpdatePeriod = 1e3 * l), e && (d.locations = e), r && (d.contentSteering = r), "dynamic" === o && (d.suggestedPresentationDelay = u), s && s.length > 0 && (d.eventStream = s);
                    let m = 0 === d.playlists.length,
                        g = h.length ? _(h, n, m) : null,
                        y = f.length ? q(f, n) : null,
                        v = c.concat(W(g), W(y)),
                        b = v.map(({
                            timelineStarts: t
                        }) => t);
                    return (d.timelineStarts = N(b), z(v, d.timelineStarts), g && (d.mediaGroups.AUDIO.audio = g), y && (d.mediaGroups.SUBTITLES.subs = y), p.length && (d.mediaGroups["CLOSED-CAPTIONS"].cc = F(p)), i) ? L({
                        oldManifest: i,
                        newManifest: d
                    }) : d
                },
                Y = (t, e, r) => {
                    let {
                        NOW: n,
                        clientOffset: i,
                        availabilityStartTime: s,
                        timescale: a = 1,
                        periodStart: o = 0,
                        minimumUpdatePeriod: u = 0
                    } = t;
                    return Math.ceil((((n + i) / 1e3 + u - (s + o)) * a - e) / r)
                },
                Z = (t, e) => {
                    let {
                        type: r,
                        minimumUpdatePeriod: n = 0,
                        media: i = "",
                        sourceDuration: s,
                        timescale: a = 1,
                        startNumber: o = 1,
                        periodStart: u
                    } = t, l = [], c = -1;
                    for (let h = 0; h < e.length; h++) {
                        let f;
                        let p = e[h],
                            d = p.d,
                            m = p.r || 0,
                            g = p.t || 0;
                        if (c < 0 && (c = g), g && g > c && (c = g), m < 0) {
                            let o = h + 1;
                            f = o === e.length ? "dynamic" === r && n > 0 && i.indexOf("$Number$") > 0 ? Y(t, c, d) : (s * a - c) / d : (e[o].t - c) / d
                        } else f = m + 1;
                        let y = o + l.length + f,
                            v = o + l.length;
                        for (; v < y;) l.push({
                            number: v,
                            duration: d / a,
                            time: c,
                            timeline: u
                        }), c += d, v++
                    }
                    return l
                },
                J = /\$([A-z]*)(?:(%0)([0-9]+)d)?\$/g,
                Q = t => (e, r, n, i) => {
                    if ("$$" === e) return "$";
                    if (void 0 === t[r]) return e;
                    let s = "" + t[r];
                    return "RepresentationID" === r ? s : (i = n ? parseInt(i, 10) : 1, s.length >= i) ? s : `${Array(i-s.length+1).join("0")}${s}`
                },
                tt = (t, e) => t.replace(J, Q(e)),
                te = (t, e) => t.duration || e ? t.duration ? D(t) : Z(t, e) : [{
                    number: t.startNumber || 1,
                    duration: t.sourceDuration,
                    time: 0,
                    timeline: t.periodStart
                }],
                tr = (t, e) => {
                    let r = {
                            RepresentationID: t.id,
                            Bandwidth: t.bandwidth || 0
                        },
                        {
                            initialization: i = {
                                sourceURL: "",
                                range: ""
                            }
                        } = t,
                        s = v({
                            baseUrl: t.baseUrl,
                            source: tt(i.sourceURL, r),
                            range: i.range
                        });
                    return te(t, e).map(e => {
                        r.Number = e.number, r.Time = e.time;
                        let i = tt(t.media || "", r),
                            a = t.timescale || 1,
                            o = t.presentationTimeOffset || 0,
                            u = t.periodStart + (e.time - o) / a;
                        return {
                            uri: i,
                            timeline: e.timeline,
                            duration: e.duration,
                            resolvedUri: (0, n.Z)(t.baseUrl || "", i),
                            map: s,
                            number: e.number,
                            presentationTime: u
                        }
                    })
                },
                tn = (t, e) => {
                    let {
                        baseUrl: r,
                        initialization: n = {}
                    } = t, i = v({
                        baseUrl: r,
                        source: n.sourceURL,
                        range: n.range
                    }), s = v({
                        baseUrl: r,
                        source: e.media,
                        range: e.mediaRange
                    });
                    return s.map = i, s
                },
                ti = (t, e) => {
                    let r;
                    let {
                        duration: n,
                        segmentUrls: i = [],
                        periodStart: s
                    } = t;
                    if (!n && !e || n && e) throw Error(y.SEGMENT_TIME_UNSPECIFIED);
                    let a = i.map(e => tn(t, e));
                    return n && (r = D(t)), e && (r = Z(t, e)), r.map((e, r) => {
                        if (a[r]) {
                            let n = a[r],
                                i = t.timescale || 1,
                                o = t.presentationTimeOffset || 0;
                            return n.timeline = e.timeline, n.duration = e.duration, n.number = e.number, n.presentationTime = s + (e.time - o) / i, n
                        }
                    }).filter(t => t)
                },
                ts = ({
                    attributes: t,
                    segmentInfo: e
                }) => {
                    let r, n;
                    e.template ? (n = tr, r = c(t, e.template)) : e.base ? (n = x, r = c(t, e.base)) : e.list && (n = ti, r = c(t, e.list));
                    let i = {
                        attributes: t
                    };
                    if (!n) return i;
                    let s = n(r, e.segmentTimeline);
                    if (r.duration) {
                        let {
                            duration: t,
                            timescale: e = 1
                        } = r;
                        r.duration = t / e
                    } else s.length ? r.duration = s.reduce((t, e) => Math.max(t, Math.ceil(e.duration)), 0) : r.duration = 0;
                    return i.attributes = r, i.segments = s, e.base && r.indexRange && (i.sidx = s[0], i.segments = []), i
                },
                ta = t => t.map(ts),
                to = (t, e) => d(t.childNodes).filter(({
                    tagName: t
                }) => t === e),
                tu = t => t.textContent.trim(),
                tl = t => parseFloat(t.split("/").reduce((t, e) => t / e)),
                tc = t => {
                    let e = /P(?:(\d*)Y)?(?:(\d*)M)?(?:(\d*)D)?(?:T(?:(\d*)H)?(?:(\d*)M)?(?:([\d.]*)S)?)?/.exec(t);
                    if (!e) return 0;
                    let [r, n, i, s, a, o] = e.slice(1);
                    return 31536e3 * parseFloat(r || 0) + 2592e3 * parseFloat(n || 0) + 86400 * parseFloat(i || 0) + 3600 * parseFloat(s || 0) + 60 * parseFloat(a || 0) + parseFloat(o || 0)
                },
                th = t => (/^\d+-\d+-\d+T\d+:\d+:\d+(\.\d+)?$/.test(t) && (t += "Z"), Date.parse(t)),
                tf = {
                    mediaPresentationDuration: t => tc(t),
                    availabilityStartTime: t => th(t) / 1e3,
                    minimumUpdatePeriod: t => tc(t),
                    suggestedPresentationDelay: t => tc(t),
                    type: t => t,
                    timeShiftBufferDepth: t => tc(t),
                    start: t => tc(t),
                    width: t => parseInt(t, 10),
                    height: t => parseInt(t, 10),
                    bandwidth: t => parseInt(t, 10),
                    frameRate: t => tl(t),
                    startNumber: t => parseInt(t, 10),
                    timescale: t => parseInt(t, 10),
                    presentationTimeOffset: t => parseInt(t, 10),
                    duration(t) {
                        let e = parseInt(t, 10);
                        return isNaN(e) ? tc(t) : e
                    },
                    d: t => parseInt(t, 10),
                    t: t => parseInt(t, 10),
                    r: t => parseInt(t, 10),
                    presentationTime: t => parseInt(t, 10),
                    DEFAULT: t => t
                },
                tp = t => t && t.attributes ? d(t.attributes).reduce((t, e) => {
                    let r = tf[e.name] || tf.DEFAULT;
                    return t[e.name] = r(e.value), t
                }, {}) : {},
                td = {
                    "urn:uuid:1077efec-c0b2-4d02-ace3-3c1e52e2fb4b": "org.w3.clearkey",
                    "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed": "com.widevine.alpha",
                    "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95": "com.microsoft.playready",
                    "urn:uuid:f239e769-efa3-4850-9c16-a903c6932efb": "com.adobe.primetime",
                    "urn:mpeg:dash:mp4protection:2011": "mp4protection"
                },
                tm = (t, e) => e.length ? p(t.map(function(t) {
                    return e.map(function(e) {
                        let r = tu(e),
                            i = (0, n.Z)(t.baseUrl, r),
                            s = c(tp(e), {
                                baseUrl: i
                            });
                        return i !== r && !s.serviceLocation && t.serviceLocation && (s.serviceLocation = t.serviceLocation), s
                    })
                })) : t,
                tg = t => {
                    let e = to(t, "SegmentTemplate")[0],
                        r = to(t, "SegmentList")[0],
                        n = r && to(r, "SegmentURL").map(t => c({
                            tag: "SegmentURL"
                        }, tp(t))),
                        i = to(t, "SegmentBase")[0],
                        s = r || e,
                        a = s && to(s, "SegmentTimeline")[0],
                        o = r || i || e,
                        u = o && to(o, "Initialization")[0],
                        l = e && tp(e);
                    l && u ? l.initialization = u && tp(u) : l && l.initialization && (l.initialization = {
                        sourceURL: l.initialization
                    });
                    let h = {
                        template: l,
                        segmentTimeline: a && to(a, "S").map(t => tp(t)),
                        list: r && c(tp(r), {
                            segmentUrls: n,
                            initialization: tp(u)
                        }),
                        base: i && c(tp(i), {
                            initialization: tp(u)
                        })
                    };
                    return Object.keys(h).forEach(t => {
                        h[t] || delete h[t]
                    }), h
                },
                ty = (t, e, r) => n => {
                    let i = tm(e, to(n, "BaseURL")),
                        s = c(t, tp(n)),
                        a = tg(n);
                    return i.map(t => ({
                        segmentInfo: c(r, a),
                        attributes: c(s, t)
                    }))
                },
                tv = t => t.reduce((t, e) => {
                    let r = tp(e);
                    r.schemeIdUri && (r.schemeIdUri = r.schemeIdUri.toLowerCase());
                    let n = td[r.schemeIdUri];
                    if (n) {
                        t[n] = {
                            attributes: r
                        };
                        let i = to(e, "cenc:pssh")[0];
                        if (i) {
                            let e = tu(i);
                            t[n].pssh = e && function(t) {
                                for (var e = s().atob ? s().atob(t) : o.from(t, "base64").toString("binary"), r = new Uint8Array(e.length), n = 0; n < e.length; n++) r[n] = e.charCodeAt(n);
                                return r
                            }(e)
                        }
                    }
                    return t
                }, {}),
                tb = t => "urn:scte:dash:cc:cea-608:2015" === t.schemeIdUri ? ("string" != typeof t.value ? [] : t.value.split(";")).map(t => {
                    let e, r;
                    return r = t, /^CC\d=/.test(t) ? [e, r] = t.split("=") : /^CC\d$/.test(t) && (e = t), {
                        channel: e,
                        language: r
                    }
                }) : "urn:scte:dash:cc:cea-708:2015" === t.schemeIdUri ? ("string" != typeof t.value ? [] : t.value.split(";")).map(t => {
                    let e = {
                        channel: void 0,
                        language: void 0,
                        aspectRatio: 1,
                        easyReader: 0,
                        "3D": 0
                    };
                    if (/=/.test(t)) {
                        let [r, n = ""] = t.split("=");
                        e.channel = r, e.language = t, n.split(",").forEach(t => {
                            let [r, n] = t.split(":");
                            "lang" === r ? e.language = n : "er" === r ? e.easyReader = Number(n) : "war" === r ? e.aspectRatio = Number(n) : "3D" === r && (e["3D"] = Number(n))
                        })
                    } else e.language = t;
                    return e.channel && (e.channel = "SERVICE" + e.channel), e
                }) : void 0,
                tE = t => p(to(t.node, "EventStream").map(e => {
                    let r = tp(e),
                        n = r.schemeIdUri;
                    return to(e, "Event").map(e => {
                        let i = tp(e),
                            s = i.presentationTime || 0,
                            a = r.timescale || 1,
                            o = i.duration || 0,
                            u = s / a + t.attributes.start;
                        return {
                            schemeIdUri: n,
                            value: r.value,
                            id: i.id,
                            start: u,
                            end: u + o / a,
                            messageData: tu(e) || i.messageData,
                            contentEncoding: r.contentEncoding,
                            presentationTimeOffset: r.presentationTimeOffset || 0
                        }
                    })
                })),
                tw = (t, e, r) => n => {
                    let i = tp(n),
                        s = tm(e, to(n, "BaseURL")),
                        a = c(t, i, {
                            role: tp(to(n, "Role")[0])
                        }),
                        o = tb(tp(to(n, "Accessibility")[0]));
                    o && (a = c(a, {
                        captionServices: o
                    }));
                    let u = to(n, "Label")[0];
                    u && u.childNodes.length && (a = c(a, {
                        label: u.childNodes[0].nodeValue.trim()
                    }));
                    let l = tv(to(n, "ContentProtection"));
                    Object.keys(l).length && (a = c(a, {
                        contentProtection: l
                    }));
                    let h = tg(n),
                        f = to(n, "Representation"),
                        d = c(r, h);
                    return p(f.map(ty(a, s, d)))
                },
                tT = (t, e) => (r, n) => {
                    let i = tm(e, to(r.node, "BaseURL")),
                        s = c(t, {
                            periodStart: r.attributes.start
                        });
                    "number" == typeof r.attributes.duration && (s.periodDuration = r.attributes.duration);
                    let a = to(r.node, "AdaptationSet"),
                        o = tg(r.node);
                    return p(a.map(tw(s, i, o)))
                },
                tD = (t, e) => {
                    if (t.length > 1 && e({
                            type: "warn",
                            message: "The MPD manifest should contain no more than one ContentSteering tag"
                        }), !t.length) return null;
                    let r = c({
                        serverURL: tu(t[0])
                    }, tp(t[0]));
                    return r.queryBeforeStart = "true" === r.queryBeforeStart, r
                },
                tx = ({
                    attributes: t,
                    priorPeriodAttributes: e,
                    mpdType: r
                }) => "number" == typeof t.start ? t.start : e && "number" == typeof e.start && "number" == typeof e.duration ? e.start + e.duration : e || "static" !== r ? null : 0,
                tS = (t, e = {}) => {
                    let {
                        manifestUri: r = "",
                        NOW: n = Date.now(),
                        clientOffset: i = 0,
                        eventHandler: s = function() {}
                    } = e, a = to(t, "Period");
                    if (!a.length) throw Error(y.INVALID_NUMBER_OF_PERIOD);
                    let o = to(t, "Location"),
                        u = tp(t),
                        l = tm([{
                            baseUrl: r
                        }], to(t, "BaseURL")),
                        c = to(t, "ContentSteering");
                    u.type = u.type || "static", u.sourceDuration = u.mediaPresentationDuration || 0, u.NOW = n, u.clientOffset = i, o.length && (u.locations = o.map(tu));
                    let h = [];
                    return a.forEach((t, e) => {
                        let r = tp(t),
                            n = h[e - 1];
                        r.start = tx({
                            attributes: r,
                            priorPeriodAttributes: n ? n.attributes : null,
                            mpdType: u.type
                        }), h.push({
                            node: t,
                            attributes: r
                        })
                    }), {
                        locations: u.locations,
                        contentSteeringInfo: tD(c, s),
                        representationInfo: p(h.map(tT(u, l))),
                        eventStream: p(h.map(tE))
                    }
                },
                tA = t => {
                    let e, r;
                    if ("" === t) throw Error(y.DASH_EMPTY_MANIFEST);
                    let n = new u.DOMParser;
                    try {
                        r = (e = n.parseFromString(t, "application/xml")) && "MPD" === e.documentElement.tagName ? e.documentElement : null
                    } catch (t) {}
                    if (!r || r && r.getElementsByTagName("parsererror").length > 0) throw Error(y.DASH_INVALID_XML);
                    return r
                },
                tR = t => {
                    let e = to(t, "UTCTiming")[0];
                    if (!e) return null;
                    let r = tp(e);
                    switch (r.schemeIdUri) {
                        case "urn:mpeg:dash:utc:http-head:2014":
                        case "urn:mpeg:dash:utc:http-head:2012":
                            r.method = "HEAD";
                            break;
                        case "urn:mpeg:dash:utc:http-xsdate:2014":
                        case "urn:mpeg:dash:utc:http-iso:2014":
                        case "urn:mpeg:dash:utc:http-xsdate:2012":
                        case "urn:mpeg:dash:utc:http-iso:2012":
                            r.method = "GET";
                            break;
                        case "urn:mpeg:dash:utc:direct:2014":
                        case "urn:mpeg:dash:utc:direct:2012":
                            r.method = "DIRECT", r.value = Date.parse(r.value);
                            break;
                        default:
                            throw Error(y.UNSUPPORTED_UTC_TIMING_SCHEME)
                    }
                    return r
                },
                tN = (t, e = {}) => {
                    let r = tS(tA(t), e);
                    return K({
                        dashPlaylists: ta(r.representationInfo),
                        locations: r.locations,
                        contentSteering: r.contentSteeringInfo,
                        sidxMapping: e.sidxMapping,
                        previousManifest: e.previousManifest,
                        eventStream: r.eventStream
                    })
                },
                tP = t => tR(tA(t))
        },
        8729: function(t, e, r) {
            var n = r(1688).getUint64;
            t.exports = function(t) {
                var e = new DataView(t.buffer, t.byteOffset, t.byteLength),
                    r = {
                        version: t[0],
                        flags: new Uint8Array(t.subarray(1, 4)),
                        references: [],
                        referenceId: e.getUint32(4),
                        timescale: e.getUint32(8)
                    },
                    i = 12;
                0 === r.version ? (r.earliestPresentationTime = e.getUint32(i), r.firstOffset = e.getUint32(i + 4), i += 8) : (r.earliestPresentationTime = n(t.subarray(i)), r.firstOffset = n(t.subarray(i + 8)), i += 16), i += 2;
                var s = e.getUint16(i);
                for (i += 2; s > 0; i += 12, s--) r.references.push({
                    referenceType: (128 & t[i]) >>> 7,
                    referencedSize: 2147483647 & e.getUint32(i),
                    subsegmentDuration: e.getUint32(i + 4),
                    startsWithSap: !!(128 & t[i + 8]),
                    sapType: (112 & t[i + 8]) >>> 4,
                    sapDeltaTime: 268435455 & e.getUint32(i + 8)
                });
                return r
            }
        },
        231: function(t) {
            var e, r, n, i, s, a, o;
            e = function(t) {
                return 9e4 * t
            }, r = function(t, e) {
                return t * e
            }, n = function(t) {
                return t / 9e4
            }, i = function(t, e) {
                return t / e
            }, s = function(t, r) {
                return e(i(t, r))
            }, a = function(t, e) {
                return r(n(t), e)
            }, o = function(t, e, r) {
                return n(r ? t : t - e)
            }, t.exports = {
                ONE_SECOND_IN_TS: 9e4,
                secondsToVideoTs: e,
                secondsToAudioTs: r,
                videoTsToSeconds: n,
                audioTsToSeconds: i,
                audioTsToVideoTs: s,
                videoTsToAudioTs: a,
                metadataTsToSeconds: o
            }
        },
        1688: function(t) {
            t.exports = {
                getUint64: function(t) {
                    var e, r = new DataView(t.buffer, t.byteOffset, t.byteLength);
                    return r.getBigUint64 ? (e = r.getBigUint64(0)) < Number.MAX_SAFE_INTEGER ? Number(e) : e : 4294967296 * r.getUint32(0) + r.getUint32(4)
                },
                MAX_UINT32: 4294967296
            }
        },
        7138: function(t, e, r) {
            "use strict";
            r.d(e, {
                default: function() {
                    return i.a
                }
            });
            var n = r(7424),
                i = r.n(n)
        },
        1877: function(t, e, r) {
            "use strict";
            r.d(e, {
                default: function() {
                    return i.a
                }
            });
            var n = r(4080),
                i = r.n(n)
        },
        844: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "addLocale", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), r(8157);
            let n = function(t) {
                for (var e = arguments.length, r = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) r[n - 1] = arguments[n];
                return t
            };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        5944: function(t, e, r) {
            "use strict";

            function n(t, e, r, n) {
                return !1
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getDomainLocale", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), r(8157), ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        905: function(t, e) {
            "use strict";
            let r;
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    DOMAttributeNames: function() {
                        return n
                    },
                    default: function() {
                        return a
                    },
                    isEqualNode: function() {
                        return s
                    }
                });
            let n = {
                acceptCharset: "accept-charset",
                className: "class",
                htmlFor: "for",
                httpEquiv: "http-equiv",
                noModule: "noModule"
            };

            function i(t) {
                let {
                    type: e,
                    props: r
                } = t, i = document.createElement(e);
                for (let t in r) {
                    if (!r.hasOwnProperty(t) || "children" === t || "dangerouslySetInnerHTML" === t || void 0 === r[t]) continue;
                    let s = n[t] || t.toLowerCase();
                    "script" === e && ("async" === s || "defer" === s || "noModule" === s) ? i[s] = !!r[t] : i.setAttribute(s, r[t])
                }
                let {
                    children: s,
                    dangerouslySetInnerHTML: a
                } = r;
                return a ? i.innerHTML = a.__html || "" : s && (i.textContent = "string" == typeof s ? s : Array.isArray(s) ? s.join("") : ""), i
            }

            function s(t, e) {
                if (t instanceof HTMLElement && e instanceof HTMLElement) {
                    let r = e.getAttribute("nonce");
                    if (r && !t.getAttribute("nonce")) {
                        let n = e.cloneNode(!0);
                        return n.setAttribute("nonce", ""), n.nonce = r, r === t.nonce && t.isEqualNode(n)
                    }
                }
                return t.isEqualNode(e)
            }

            function a() {
                return {
                    mountedInstances: new Set,
                    updateHead: t => {
                        let e = {};
                        t.forEach(t => {
                            if ("link" === t.type && t.props["data-optimized-fonts"]) {
                                if (document.querySelector('style[data-href="' + t.props["data-href"] + '"]')) return;
                                t.props.href = t.props["data-href"], t.props["data-href"] = void 0
                            }
                            let r = e[t.type] || [];
                            r.push(t), e[t.type] = r
                        });
                        let n = e.title ? e.title[0] : null,
                            i = "";
                        if (n) {
                            let {
                                children: t
                            } = n.props;
                            i = "string" == typeof t ? t : Array.isArray(t) ? t.join("") : ""
                        }
                        i !== document.title && (document.title = i), ["meta", "base", "link", "style", "script"].forEach(t => {
                            r(t, e[t] || [])
                        })
                    }
                }
            }
            r = (t, e) => {
                let r = document.getElementsByTagName("head")[0],
                    n = r.querySelector("meta[name=next-head-count]"),
                    a = Number(n.content),
                    o = [];
                for (let e = 0, r = n.previousElementSibling; e < a; e++, r = (null == r ? void 0 : r.previousElementSibling) || null) {
                    var u;
                    (null == r ? void 0 : null == (u = r.tagName) ? void 0 : u.toLowerCase()) === t && o.push(r)
                }
                let l = e.map(i).filter(t => {
                    for (let e = 0, r = o.length; e < r; e++)
                        if (s(o[e], t)) return o.splice(e, 1), !1;
                    return !0
                });
                o.forEach(t => {
                    var e;
                    return null == (e = t.parentNode) ? void 0 : e.removeChild(t)
                }), l.forEach(t => r.insertBefore(t, n)), n.content = (a - o.length + l.length).toString()
            }, ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        7424: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return E
                }
            });
            let n = r(9920),
                i = r(7437),
                s = n._(r(2265)),
                a = r(8016),
                o = r(8029),
                u = r(1142),
                l = r(3461),
                c = r(844),
                h = r(291),
                f = r(4467),
                p = r(323),
                d = r(5944),
                m = r(4897),
                g = r(1507),
                y = new Set;

            function v(t, e, r, n, i, s) {
                if ("undefined" != typeof window && (s || (0, o.isLocalURL)(e))) {
                    if (!n.bypassPrefetchedCheck) {
                        let i = e + "%" + r + "%" + (void 0 !== n.locale ? n.locale : "locale" in t ? t.locale : void 0);
                        if (y.has(i)) return;
                        y.add(i)
                    }
                    Promise.resolve(s ? t.prefetch(e, i) : t.prefetch(e, r, n)).catch(t => {})
                }
            }

            function b(t) {
                return "string" == typeof t ? t : (0, u.formatUrl)(t)
            }
            let E = s.default.forwardRef(function(t, e) {
                let r, n;
                let {
                    href: u,
                    as: y,
                    children: E,
                    prefetch: w = null,
                    passHref: T,
                    replace: D,
                    shallow: x,
                    scroll: S,
                    locale: A,
                    onClick: R,
                    onMouseEnter: N,
                    onTouchStart: P,
                    legacyBehavior: C = !1,
                    ...O
                } = t;
                r = E, C && ("string" == typeof r || "number" == typeof r) && (r = (0, i.jsx)("a", {
                    children: r
                }));
                let I = s.default.useContext(h.RouterContext),
                    L = s.default.useContext(f.AppRouterContext),
                    M = null != I ? I : L,
                    k = !I,
                    U = !1 !== w,
                    B = null === w ? g.PrefetchKind.AUTO : g.PrefetchKind.FULL,
                    {
                        href: V,
                        as: j
                    } = s.default.useMemo(() => {
                        if (!I) {
                            let t = b(u);
                            return {
                                href: t,
                                as: y ? b(y) : t
                            }
                        }
                        let [t, e] = (0, a.resolveHref)(I, u, !0);
                        return {
                            href: t,
                            as: y ? (0, a.resolveHref)(I, y) : e || t
                        }
                    }, [I, u, y]),
                    _ = s.default.useRef(V),
                    q = s.default.useRef(j);
                C && (n = s.default.Children.only(r));
                let F = C ? n && "object" == typeof n && n.ref : e,
                    [X, G, H] = (0, p.useIntersection)({
                        rootMargin: "200px"
                    }),
                    $ = s.default.useCallback(t => {
                        (q.current !== j || _.current !== V) && (H(), q.current = j, _.current = V), X(t), F && ("function" == typeof F ? F(t) : "object" == typeof F && (F.current = t))
                    }, [j, F, V, H, X]);
                s.default.useEffect(() => {
                    M && G && U && v(M, V, j, {
                        locale: A
                    }, {
                        kind: B
                    }, k)
                }, [j, V, G, A, U, null == I ? void 0 : I.locale, M, k, B]);
                let z = {
                    ref: $,
                    onClick(t) {
                        C || "function" != typeof R || R(t), C && n.props && "function" == typeof n.props.onClick && n.props.onClick(t), M && !t.defaultPrevented && function(t, e, r, n, i, a, u, l, c) {
                            let {
                                nodeName: h
                            } = t.currentTarget;
                            if ("A" === h.toUpperCase() && (function(t) {
                                    let e = t.currentTarget.getAttribute("target");
                                    return e && "_self" !== e || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which
                                }(t) || !c && !(0, o.isLocalURL)(r))) return;
                            t.preventDefault();
                            let f = () => {
                                let t = null == u || u;
                                "beforePopState" in e ? e[i ? "replace" : "push"](r, n, {
                                    shallow: a,
                                    locale: l,
                                    scroll: t
                                }) : e[i ? "replace" : "push"](n || r, {
                                    scroll: t
                                })
                            };
                            c ? s.default.startTransition(f) : f()
                        }(t, M, V, j, D, x, S, A, k)
                    },
                    onMouseEnter(t) {
                        C || "function" != typeof N || N(t), C && n.props && "function" == typeof n.props.onMouseEnter && n.props.onMouseEnter(t), M && (U || !k) && v(M, V, j, {
                            locale: A,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: B
                        }, k)
                    },
                    onTouchStart: function(t) {
                        C || "function" != typeof P || P(t), C && n.props && "function" == typeof n.props.onTouchStart && n.props.onTouchStart(t), M && (U || !k) && v(M, V, j, {
                            locale: A,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: B
                        }, k)
                    }
                };
                if ((0, l.isAbsoluteUrl)(j)) z.href = j;
                else if (!C || T || "a" === n.type && !("href" in n.props)) {
                    let t = void 0 !== A ? A : null == I ? void 0 : I.locale,
                        e = (null == I ? void 0 : I.isLocaleDomain) && (0, d.getDomainLocale)(j, t, null == I ? void 0 : I.locales, null == I ? void 0 : I.domainLocales);
                    z.href = e || (0, m.addBasePath)((0, c.addLocale)(j, t, null == I ? void 0 : I.defaultLocale))
                }
                return C ? s.default.cloneElement(n, z) : (0, i.jsx)("a", { ...O,
                    ...z,
                    children: r
                })
            });
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        9189: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    cancelIdleCallback: function() {
                        return n
                    },
                    requestIdleCallback: function() {
                        return r
                    }
                });
            let r = "undefined" != typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(t) {
                    let e = Date.now();
                    return self.setTimeout(function() {
                        t({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - e))
                            }
                        })
                    }, 1)
                },
                n = "undefined" != typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(t) {
                    return clearTimeout(t)
                };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        8016: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "resolveHref", {
                enumerable: !0,
                get: function() {
                    return h
                }
            });
            let n = r(8323),
                i = r(1142),
                s = r(5519),
                a = r(3461),
                o = r(8157),
                u = r(8029),
                l = r(9195),
                c = r(20);

            function h(t, e, r) {
                let h;
                let f = "string" == typeof e ? e : (0, i.formatWithValidation)(e),
                    p = f.match(/^[a-zA-Z]{1,}:\/\//),
                    d = p ? f.slice(p[0].length) : f;
                if ((d.split("?", 1)[0] || "").match(/(\/\/|\\)/)) {
                    console.error("Invalid href '" + f + "' passed to next/router in page: '" + t.pathname + "'. Repeated forward-slashes (//) or backslashes \\ are not valid in the href.");
                    let e = (0, a.normalizeRepeatedSlashes)(d);
                    f = (p ? p[0] : "") + e
                }
                if (!(0, u.isLocalURL)(f)) return r ? [f] : f;
                try {
                    h = new URL(f.startsWith("#") ? t.asPath : t.pathname, "http://n")
                } catch (t) {
                    h = new URL("/", "http://n")
                }
                try {
                    let t = new URL(f, h);
                    t.pathname = (0, o.normalizePathTrailingSlash)(t.pathname);
                    let e = "";
                    if ((0, l.isDynamicRoute)(t.pathname) && t.searchParams && r) {
                        let r = (0, n.searchParamsToUrlQuery)(t.searchParams),
                            {
                                result: a,
                                params: o
                            } = (0, c.interpolateAs)(t.pathname, t.pathname, r);
                        a && (e = (0, i.formatWithValidation)({
                            pathname: a,
                            hash: t.hash,
                            query: (0, s.omit)(r, o)
                        }))
                    }
                    let a = t.origin === h.origin ? t.href.slice(t.origin.length) : t.href;
                    return r ? [a, e || a] : a
                } catch (t) {
                    return r ? [f] : f
                }
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        4080: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    default: function() {
                        return b
                    },
                    handleClientScriptLoad: function() {
                        return g
                    },
                    initScriptLoader: function() {
                        return y
                    }
                });
            let n = r(9920),
                i = r(1452),
                s = r(7437),
                a = n._(r(4887)),
                o = i._(r(2265)),
                u = r(6590),
                l = r(905),
                c = r(9189),
                h = new Map,
                f = new Set,
                p = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"],
                d = t => {
                    if (a.default.preinit) {
                        t.forEach(t => {
                            a.default.preinit(t, {
                                as: "style"
                            })
                        });
                        return
                    }
                    if ("undefined" != typeof window) {
                        let e = document.head;
                        t.forEach(t => {
                            let r = document.createElement("link");
                            r.type = "text/css", r.rel = "stylesheet", r.href = t, e.appendChild(r)
                        })
                    }
                },
                m = t => {
                    let {
                        src: e,
                        id: r,
                        onLoad: n = () => {},
                        onReady: i = null,
                        dangerouslySetInnerHTML: s,
                        children: a = "",
                        strategy: o = "afterInteractive",
                        onError: u,
                        stylesheets: c
                    } = t, m = r || e;
                    if (m && f.has(m)) return;
                    if (h.has(e)) {
                        f.add(m), h.get(e).then(n, u);
                        return
                    }
                    let g = () => {
                            i && i(), f.add(m)
                        },
                        y = document.createElement("script"),
                        v = new Promise((t, e) => {
                            y.addEventListener("load", function(e) {
                                t(), n && n.call(this, e), g()
                            }), y.addEventListener("error", function(t) {
                                e(t)
                            })
                        }).catch(function(t) {
                            u && u(t)
                        });
                    for (let [r, n] of (s ? (y.innerHTML = s.__html || "", g()) : a ? (y.textContent = "string" == typeof a ? a : Array.isArray(a) ? a.join("") : "", g()) : e && (y.src = e, h.set(e, v)), Object.entries(t))) {
                        if (void 0 === n || p.includes(r)) continue;
                        let t = l.DOMAttributeNames[r] || r.toLowerCase();
                        y.setAttribute(t, n)
                    }
                    "worker" === o && y.setAttribute("type", "text/partytown"), y.setAttribute("data-nscript", o), c && d(c), document.body.appendChild(y)
                };

            function g(t) {
                let {
                    strategy: e = "afterInteractive"
                } = t;
                "lazyOnload" === e ? window.addEventListener("load", () => {
                    (0, c.requestIdleCallback)(() => m(t))
                }) : m(t)
            }

            function y(t) {
                t.forEach(g), [...document.querySelectorAll('[data-nscript="beforeInteractive"]'), ...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(t => {
                    let e = t.id || t.getAttribute("src");
                    f.add(e)
                })
            }

            function v(t) {
                let {
                    id: e,
                    src: r = "",
                    onLoad: n = () => {},
                    onReady: i = null,
                    strategy: l = "afterInteractive",
                    onError: h,
                    stylesheets: p,
                    ...d
                } = t, {
                    updateScripts: g,
                    scripts: y,
                    getIsSsr: v,
                    appDir: b,
                    nonce: E
                } = (0, o.useContext)(u.HeadManagerContext), w = (0, o.useRef)(!1);
                (0, o.useEffect)(() => {
                    let t = e || r;
                    w.current || (i && t && f.has(t) && i(), w.current = !0)
                }, [i, e, r]);
                let T = (0, o.useRef)(!1);
                if ((0, o.useEffect)(() => {
                        !T.current && ("afterInteractive" === l ? m(t) : "lazyOnload" === l && ("complete" === document.readyState ? (0, c.requestIdleCallback)(() => m(t)) : window.addEventListener("load", () => {
                            (0, c.requestIdleCallback)(() => m(t))
                        })), T.current = !0)
                    }, [t, l]), ("beforeInteractive" === l || "worker" === l) && (g ? (y[l] = (y[l] || []).concat([{
                        id: e,
                        src: r,
                        onLoad: n,
                        onReady: i,
                        onError: h,
                        ...d
                    }]), g(y)) : v && v() ? f.add(e || r) : v && !v() && m(t)), b) {
                    if (p && p.forEach(t => {
                            a.default.preinit(t, {
                                as: "style"
                            })
                        }), "beforeInteractive" === l) return r ? (a.default.preload(r, d.integrity ? {
                        as: "script",
                        integrity: d.integrity,
                        nonce: E
                    } : {
                        as: "script",
                        nonce: E
                    }), (0, s.jsx)("script", {
                        nonce: E,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([r, { ...d,
                                id: e
                            }]) + ")"
                        }
                    })) : (d.dangerouslySetInnerHTML && (d.children = d.dangerouslySetInnerHTML.__html, delete d.dangerouslySetInnerHTML), (0, s.jsx)("script", {
                        nonce: E,
                        dangerouslySetInnerHTML: {
                            __html: "(self.__next_s=self.__next_s||[]).push(" + JSON.stringify([0, { ...d,
                                id: e
                            }]) + ")"
                        }
                    }));
                    "afterInteractive" === l && r && a.default.preload(r, d.integrity ? {
                        as: "script",
                        integrity: d.integrity,
                        nonce: E
                    } : {
                        as: "script",
                        nonce: E
                    })
                }
                return null
            }
            Object.defineProperty(v, "__nextScript", {
                value: !0
            });
            let b = v;
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        323: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "useIntersection", {
                enumerable: !0,
                get: function() {
                    return u
                }
            });
            let n = r(2265),
                i = r(9189),
                s = "function" == typeof IntersectionObserver,
                a = new Map,
                o = [];

            function u(t) {
                let {
                    rootRef: e,
                    rootMargin: r,
                    disabled: u
                } = t, l = u || !s, [c, h] = (0, n.useState)(!1), f = (0, n.useRef)(null), p = (0, n.useCallback)(t => {
                    f.current = t
                }, []);
                return (0, n.useEffect)(() => {
                    if (s) {
                        if (l || c) return;
                        let t = f.current;
                        if (t && t.tagName) return function(t, e, r) {
                            let {
                                id: n,
                                observer: i,
                                elements: s
                            } = function(t) {
                                let e;
                                let r = {
                                        root: t.root || null,
                                        margin: t.rootMargin || ""
                                    },
                                    n = o.find(t => t.root === r.root && t.margin === r.margin);
                                if (n && (e = a.get(n))) return e;
                                let i = new Map;
                                return e = {
                                    id: r,
                                    observer: new IntersectionObserver(t => {
                                        t.forEach(t => {
                                            let e = i.get(t.target),
                                                r = t.isIntersecting || t.intersectionRatio > 0;
                                            e && r && e(r)
                                        })
                                    }, t),
                                    elements: i
                                }, o.push(r), a.set(r, e), e
                            }(r);
                            return s.set(t, e), i.observe(t),
                                function() {
                                    if (s.delete(t), i.unobserve(t), 0 === s.size) {
                                        i.disconnect(), a.delete(n);
                                        let t = o.findIndex(t => t.root === n.root && t.margin === n.margin);
                                        t > -1 && o.splice(t, 1)
                                    }
                                }
                        }(t, t => t && h(t), {
                            root: null == e ? void 0 : e.current,
                            rootMargin: r
                        })
                    } else if (!c) {
                        let t = (0, i.requestIdleCallback)(() => h(!0));
                        return () => (0, i.cancelIdleCallback)(t)
                    }
                }, [l, r, e, c, f.current]), [p, c, (0, n.useCallback)(() => {
                    h(!1)
                }, [])]
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        6300: function(t) {
            ! function() {
                var e = {
                        675: function(t, e) {
                            "use strict";
                            e.byteLength = function(t) {
                                var e = u(t),
                                    r = e[0],
                                    n = e[1];
                                return (r + n) * 3 / 4 - n
                            }, e.toByteArray = function(t) {
                                var e, r, s = u(t),
                                    a = s[0],
                                    o = s[1],
                                    l = new i((a + o) * 3 / 4 - o),
                                    c = 0,
                                    h = o > 0 ? a - 4 : a;
                                for (r = 0; r < h; r += 4) e = n[t.charCodeAt(r)] << 18 | n[t.charCodeAt(r + 1)] << 12 | n[t.charCodeAt(r + 2)] << 6 | n[t.charCodeAt(r + 3)], l[c++] = e >> 16 & 255, l[c++] = e >> 8 & 255, l[c++] = 255 & e;
                                return 2 === o && (e = n[t.charCodeAt(r)] << 2 | n[t.charCodeAt(r + 1)] >> 4, l[c++] = 255 & e), 1 === o && (e = n[t.charCodeAt(r)] << 10 | n[t.charCodeAt(r + 1)] << 4 | n[t.charCodeAt(r + 2)] >> 2, l[c++] = e >> 8 & 255, l[c++] = 255 & e), l
                            }, e.fromByteArray = function(t) {
                                for (var e, n = t.length, i = n % 3, s = [], a = 0, o = n - i; a < o; a += 16383) s.push(function(t, e, n) {
                                    for (var i, s = [], a = e; a < n; a += 3) s.push(r[(i = (t[a] << 16 & 16711680) + (t[a + 1] << 8 & 65280) + (255 & t[a + 2])) >> 18 & 63] + r[i >> 12 & 63] + r[i >> 6 & 63] + r[63 & i]);
                                    return s.join("")
                                }(t, a, a + 16383 > o ? o : a + 16383));
                                return 1 === i ? s.push(r[(e = t[n - 1]) >> 2] + r[e << 4 & 63] + "==") : 2 === i && s.push(r[(e = (t[n - 2] << 8) + t[n - 1]) >> 10] + r[e >> 4 & 63] + r[e << 2 & 63] + "="), s.join("")
                            };
                            for (var r = [], n = [], i = "undefined" != typeof Uint8Array ? Uint8Array : Array, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, o = s.length; a < o; ++a) r[a] = s[a], n[s.charCodeAt(a)] = a;

                            function u(t) {
                                var e = t.length;
                                if (e % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
                                var r = t.indexOf("="); - 1 === r && (r = e);
                                var n = r === e ? 0 : 4 - r % 4;
                                return [r, n]
                            }
                            n["-".charCodeAt(0)] = 62, n["_".charCodeAt(0)] = 63
                        },
                        72: function(t, e, r) {
                            "use strict";
                            /*!
                             * The buffer module from node.js, for the browser.
                             *
                             * @author   Feross Aboukhadijeh <https://feross.org>
                             * @license  MIT
                             */
                            var n = r(675),
                                i = r(783),
                                s = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;

                            function a(t) {
                                if (t > 2147483647) throw RangeError('The value "' + t + '" is invalid for option "size"');
                                var e = new Uint8Array(t);
                                return Object.setPrototypeOf(e, o.prototype), e
                            }

                            function o(t, e, r) {
                                if ("number" == typeof t) {
                                    if ("string" == typeof e) throw TypeError('The "string" argument must be of type string. Received type number');
                                    return c(t)
                                }
                                return u(t, e, r)
                            }

                            function u(t, e, r) {
                                if ("string" == typeof t) return function(t, e) {
                                    if (("string" != typeof e || "" === e) && (e = "utf8"), !o.isEncoding(e)) throw TypeError("Unknown encoding: " + e);
                                    var r = 0 | p(t, e),
                                        n = a(r),
                                        i = n.write(t, e);
                                    return i !== r && (n = n.slice(0, i)), n
                                }(t, e);
                                if (ArrayBuffer.isView(t)) return h(t);
                                if (null == t) throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
                                if (P(t, ArrayBuffer) || t && P(t.buffer, ArrayBuffer) || "undefined" != typeof SharedArrayBuffer && (P(t, SharedArrayBuffer) || t && P(t.buffer, SharedArrayBuffer))) return function(t, e, r) {
                                    var n;
                                    if (e < 0 || t.byteLength < e) throw RangeError('"offset" is outside of buffer bounds');
                                    if (t.byteLength < e + (r || 0)) throw RangeError('"length" is outside of buffer bounds');
                                    return Object.setPrototypeOf(n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r), o.prototype), n
                                }(t, e, r);
                                if ("number" == typeof t) throw TypeError('The "value" argument must not be of type number. Received type number');
                                var n = t.valueOf && t.valueOf();
                                if (null != n && n !== t) return o.from(n, e, r);
                                var i = function(t) {
                                    if (o.isBuffer(t)) {
                                        var e, r = 0 | f(t.length),
                                            n = a(r);
                                        return 0 === n.length || t.copy(n, 0, 0, r), n
                                    }
                                    return void 0 !== t.length ? "number" != typeof t.length || (e = t.length) != e ? a(0) : h(t) : "Buffer" === t.type && Array.isArray(t.data) ? h(t.data) : void 0
                                }(t);
                                if (i) return i;
                                if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof t[Symbol.toPrimitive]) return o.from(t[Symbol.toPrimitive]("string"), e, r);
                                throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t)
                            }

                            function l(t) {
                                if ("number" != typeof t) throw TypeError('"size" argument must be of type number');
                                if (t < 0) throw RangeError('The value "' + t + '" is invalid for option "size"')
                            }

                            function c(t) {
                                return l(t), a(t < 0 ? 0 : 0 | f(t))
                            }

                            function h(t) {
                                for (var e = t.length < 0 ? 0 : 0 | f(t.length), r = a(e), n = 0; n < e; n += 1) r[n] = 255 & t[n];
                                return r
                            }

                            function f(t) {
                                if (t >= 2147483647) throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes");
                                return 0 | t
                            }

                            function p(t, e) {
                                if (o.isBuffer(t)) return t.length;
                                if (ArrayBuffer.isView(t) || P(t, ArrayBuffer)) return t.byteLength;
                                if ("string" != typeof t) throw TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof t);
                                var r = t.length,
                                    n = arguments.length > 2 && !0 === arguments[2];
                                if (!n && 0 === r) return 0;
                                for (var i = !1;;) switch (e) {
                                    case "ascii":
                                    case "latin1":
                                    case "binary":
                                        return r;
                                    case "utf8":
                                    case "utf-8":
                                        return S(t).length;
                                    case "ucs2":
                                    case "ucs-2":
                                    case "utf16le":
                                    case "utf-16le":
                                        return 2 * r;
                                    case "hex":
                                        return r >>> 1;
                                    case "base64":
                                        return R(t).length;
                                    default:
                                        if (i) return n ? -1 : S(t).length;
                                        e = ("" + e).toLowerCase(), i = !0
                                }
                            }

                            function d(t, e, r) {
                                var i, s, a = !1;
                                if ((void 0 === e || e < 0) && (e = 0), e > this.length || ((void 0 === r || r > this.length) && (r = this.length), r <= 0 || (r >>>= 0) <= (e >>>= 0))) return "";
                                for (t || (t = "utf8");;) switch (t) {
                                    case "hex":
                                        return function(t, e, r) {
                                            var n = t.length;
                                            (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
                                            for (var i = "", s = e; s < r; ++s) i += C[t[s]];
                                            return i
                                        }(this, e, r);
                                    case "utf8":
                                    case "utf-8":
                                        return v(this, e, r);
                                    case "ascii":
                                        return function(t, e, r) {
                                            var n = "";
                                            r = Math.min(t.length, r);
                                            for (var i = e; i < r; ++i) n += String.fromCharCode(127 & t[i]);
                                            return n
                                        }(this, e, r);
                                    case "latin1":
                                    case "binary":
                                        return function(t, e, r) {
                                            var n = "";
                                            r = Math.min(t.length, r);
                                            for (var i = e; i < r; ++i) n += String.fromCharCode(t[i]);
                                            return n
                                        }(this, e, r);
                                    case "base64":
                                        return i = e, s = r, 0 === i && s === this.length ? n.fromByteArray(this) : n.fromByteArray(this.slice(i, s));
                                    case "ucs2":
                                    case "ucs-2":
                                    case "utf16le":
                                    case "utf-16le":
                                        return function(t, e, r) {
                                            for (var n = t.slice(e, r), i = "", s = 0; s < n.length; s += 2) i += String.fromCharCode(n[s] + 256 * n[s + 1]);
                                            return i
                                        }(this, e, r);
                                    default:
                                        if (a) throw TypeError("Unknown encoding: " + t);
                                        t = (t + "").toLowerCase(), a = !0
                                }
                            }

                            function m(t, e, r) {
                                var n = t[e];
                                t[e] = t[r], t[r] = n
                            }

                            function g(t, e, r, n, i) {
                                var s;
                                if (0 === t.length) return -1;
                                if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), (s = r = +r) != s && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
                                    if (i) return -1;
                                    r = t.length - 1
                                } else if (r < 0) {
                                    if (!i) return -1;
                                    r = 0
                                }
                                if ("string" == typeof e && (e = o.from(e, n)), o.isBuffer(e)) return 0 === e.length ? -1 : y(t, e, r, n, i);
                                if ("number" == typeof e) return (e &= 255, "function" == typeof Uint8Array.prototype.indexOf) ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : y(t, [e], r, n, i);
                                throw TypeError("val must be string, number or Buffer")
                            }

                            function y(t, e, r, n, i) {
                                var s, a = 1,
                                    o = t.length,
                                    u = e.length;
                                if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
                                    if (t.length < 2 || e.length < 2) return -1;
                                    a = 2, o /= 2, u /= 2, r /= 2
                                }

                                function l(t, e) {
                                    return 1 === a ? t[e] : t.readUInt16BE(e * a)
                                }
                                if (i) {
                                    var c = -1;
                                    for (s = r; s < o; s++)
                                        if (l(t, s) === l(e, -1 === c ? 0 : s - c)) {
                                            if (-1 === c && (c = s), s - c + 1 === u) return c * a
                                        } else -1 !== c && (s -= s - c), c = -1
                                } else
                                    for (r + u > o && (r = o - u), s = r; s >= 0; s--) {
                                        for (var h = !0, f = 0; f < u; f++)
                                            if (l(t, s + f) !== l(e, f)) {
                                                h = !1;
                                                break
                                            }
                                        if (h) return s
                                    }
                                return -1
                            }

                            function v(t, e, r) {
                                r = Math.min(t.length, r);
                                for (var n = [], i = e; i < r;) {
                                    var s, a, o, u, l = t[i],
                                        c = null,
                                        h = l > 239 ? 4 : l > 223 ? 3 : l > 191 ? 2 : 1;
                                    if (i + h <= r) switch (h) {
                                        case 1:
                                            l < 128 && (c = l);
                                            break;
                                        case 2:
                                            (192 & (s = t[i + 1])) == 128 && (u = (31 & l) << 6 | 63 & s) > 127 && (c = u);
                                            break;
                                        case 3:
                                            s = t[i + 1], a = t[i + 2], (192 & s) == 128 && (192 & a) == 128 && (u = (15 & l) << 12 | (63 & s) << 6 | 63 & a) > 2047 && (u < 55296 || u > 57343) && (c = u);
                                            break;
                                        case 4:
                                            s = t[i + 1], a = t[i + 2], o = t[i + 3], (192 & s) == 128 && (192 & a) == 128 && (192 & o) == 128 && (u = (15 & l) << 18 | (63 & s) << 12 | (63 & a) << 6 | 63 & o) > 65535 && u < 1114112 && (c = u)
                                    }
                                    null === c ? (c = 65533, h = 1) : c > 65535 && (c -= 65536, n.push(c >>> 10 & 1023 | 55296), c = 56320 | 1023 & c), n.push(c), i += h
                                }
                                return function(t) {
                                    var e = t.length;
                                    if (e <= 4096) return String.fromCharCode.apply(String, t);
                                    for (var r = "", n = 0; n < e;) r += String.fromCharCode.apply(String, t.slice(n, n += 4096));
                                    return r
                                }(n)
                            }

                            function b(t, e, r) {
                                if (t % 1 != 0 || t < 0) throw RangeError("offset is not uint");
                                if (t + e > r) throw RangeError("Trying to access beyond buffer length")
                            }

                            function E(t, e, r, n, i, s) {
                                if (!o.isBuffer(t)) throw TypeError('"buffer" argument must be a Buffer instance');
                                if (e > i || e < s) throw RangeError('"value" argument is out of bounds');
                                if (r + n > t.length) throw RangeError("Index out of range")
                            }

                            function w(t, e, r, n, i, s) {
                                if (r + n > t.length || r < 0) throw RangeError("Index out of range")
                            }

                            function T(t, e, r, n, s) {
                                return e = +e, r >>>= 0, s || w(t, e, r, 4, 34028234663852886e22, -34028234663852886e22), i.write(t, e, r, n, 23, 4), r + 4
                            }

                            function D(t, e, r, n, s) {
                                return e = +e, r >>>= 0, s || w(t, e, r, 8, 17976931348623157e292, -17976931348623157e292), i.write(t, e, r, n, 52, 8), r + 8
                            }
                            e.Buffer = o, e.SlowBuffer = function(t) {
                                return +t != t && (t = 0), o.alloc(+t)
                            }, e.INSPECT_MAX_BYTES = 50, e.kMaxLength = 2147483647, o.TYPED_ARRAY_SUPPORT = function() {
                                try {
                                    var t = new Uint8Array(1),
                                        e = {
                                            foo: function() {
                                                return 42
                                            }
                                        };
                                    return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(t, e), 42 === t.foo()
                                } catch (t) {
                                    return !1
                                }
                            }(), o.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(o.prototype, "parent", {
                                enumerable: !0,
                                get: function() {
                                    if (o.isBuffer(this)) return this.buffer
                                }
                            }), Object.defineProperty(o.prototype, "offset", {
                                enumerable: !0,
                                get: function() {
                                    if (o.isBuffer(this)) return this.byteOffset
                                }
                            }), o.poolSize = 8192, o.from = function(t, e, r) {
                                return u(t, e, r)
                            }, Object.setPrototypeOf(o.prototype, Uint8Array.prototype), Object.setPrototypeOf(o, Uint8Array), o.alloc = function(t, e, r) {
                                return (l(t), t <= 0) ? a(t) : void 0 !== e ? "string" == typeof r ? a(t).fill(e, r) : a(t).fill(e) : a(t)
                            }, o.allocUnsafe = function(t) {
                                return c(t)
                            }, o.allocUnsafeSlow = function(t) {
                                return c(t)
                            }, o.isBuffer = function(t) {
                                return null != t && !0 === t._isBuffer && t !== o.prototype
                            }, o.compare = function(t, e) {
                                if (P(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), P(e, Uint8Array) && (e = o.from(e, e.offset, e.byteLength)), !o.isBuffer(t) || !o.isBuffer(e)) throw TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
                                if (t === e) return 0;
                                for (var r = t.length, n = e.length, i = 0, s = Math.min(r, n); i < s; ++i)
                                    if (t[i] !== e[i]) {
                                        r = t[i], n = e[i];
                                        break
                                    }
                                return r < n ? -1 : n < r ? 1 : 0
                            }, o.isEncoding = function(t) {
                                switch (String(t).toLowerCase()) {
                                    case "hex":
                                    case "utf8":
                                    case "utf-8":
                                    case "ascii":
                                    case "latin1":
                                    case "binary":
                                    case "base64":
                                    case "ucs2":
                                    case "ucs-2":
                                    case "utf16le":
                                    case "utf-16le":
                                        return !0;
                                    default:
                                        return !1
                                }
                            }, o.concat = function(t, e) {
                                if (!Array.isArray(t)) throw TypeError('"list" argument must be an Array of Buffers');
                                if (0 === t.length) return o.alloc(0);
                                if (void 0 === e)
                                    for (r = 0, e = 0; r < t.length; ++r) e += t[r].length;
                                var r, n = o.allocUnsafe(e),
                                    i = 0;
                                for (r = 0; r < t.length; ++r) {
                                    var s = t[r];
                                    if (P(s, Uint8Array) && (s = o.from(s)), !o.isBuffer(s)) throw TypeError('"list" argument must be an Array of Buffers');
                                    s.copy(n, i), i += s.length
                                }
                                return n
                            }, o.byteLength = p, o.prototype._isBuffer = !0, o.prototype.swap16 = function() {
                                var t = this.length;
                                if (t % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
                                for (var e = 0; e < t; e += 2) m(this, e, e + 1);
                                return this
                            }, o.prototype.swap32 = function() {
                                var t = this.length;
                                if (t % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
                                for (var e = 0; e < t; e += 4) m(this, e, e + 3), m(this, e + 1, e + 2);
                                return this
                            }, o.prototype.swap64 = function() {
                                var t = this.length;
                                if (t % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
                                for (var e = 0; e < t; e += 8) m(this, e, e + 7), m(this, e + 1, e + 6), m(this, e + 2, e + 5), m(this, e + 3, e + 4);
                                return this
                            }, o.prototype.toString = function() {
                                var t = this.length;
                                return 0 === t ? "" : 0 == arguments.length ? v(this, 0, t) : d.apply(this, arguments)
                            }, o.prototype.toLocaleString = o.prototype.toString, o.prototype.equals = function(t) {
                                if (!o.isBuffer(t)) throw TypeError("Argument must be a Buffer");
                                return this === t || 0 === o.compare(this, t)
                            }, o.prototype.inspect = function() {
                                var t = "",
                                    r = e.INSPECT_MAX_BYTES;
                                return t = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (t += " ... "), "<Buffer " + t + ">"
                            }, s && (o.prototype[s] = o.prototype.inspect), o.prototype.compare = function(t, e, r, n, i) {
                                if (P(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), !o.isBuffer(t)) throw TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t);
                                if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw RangeError("out of range index");
                                if (n >= i && e >= r) return 0;
                                if (n >= i) return -1;
                                if (e >= r) return 1;
                                if (e >>>= 0, r >>>= 0, n >>>= 0, i >>>= 0, this === t) return 0;
                                for (var s = i - n, a = r - e, u = Math.min(s, a), l = this.slice(n, i), c = t.slice(e, r), h = 0; h < u; ++h)
                                    if (l[h] !== c[h]) {
                                        s = l[h], a = c[h];
                                        break
                                    }
                                return s < a ? -1 : a < s ? 1 : 0
                            }, o.prototype.includes = function(t, e, r) {
                                return -1 !== this.indexOf(t, e, r)
                            }, o.prototype.indexOf = function(t, e, r) {
                                return g(this, t, e, r, !0)
                            }, o.prototype.lastIndexOf = function(t, e, r) {
                                return g(this, t, e, r, !1)
                            }, o.prototype.write = function(t, e, r, n) {
                                if (void 0 === e) n = "utf8", r = this.length, e = 0;
                                else if (void 0 === r && "string" == typeof e) n = e, r = this.length, e = 0;
                                else if (isFinite(e)) e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
                                else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                                var i, s, a, o, u, l, c, h, f, p, d, m, g = this.length - e;
                                if ((void 0 === r || r > g) && (r = g), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw RangeError("Attempt to write outside buffer bounds");
                                n || (n = "utf8");
                                for (var y = !1;;) switch (n) {
                                    case "hex":
                                        return function(t, e, r, n) {
                                            r = Number(r) || 0;
                                            var i = t.length - r;
                                            n ? (n = Number(n)) > i && (n = i) : n = i;
                                            var s = e.length;
                                            n > s / 2 && (n = s / 2);
                                            for (var a = 0; a < n; ++a) {
                                                var o = parseInt(e.substr(2 * a, 2), 16);
                                                if (o != o) break;
                                                t[r + a] = o
                                            }
                                            return a
                                        }(this, t, e, r);
                                    case "utf8":
                                    case "utf-8":
                                        return u = e, l = r, N(S(t, this.length - u), this, u, l);
                                    case "ascii":
                                        return c = e, h = r, N(A(t), this, c, h);
                                    case "latin1":
                                    case "binary":
                                        return i = this, s = t, a = e, o = r, N(A(s), i, a, o);
                                    case "base64":
                                        return f = e, p = r, N(R(t), this, f, p);
                                    case "ucs2":
                                    case "ucs-2":
                                    case "utf16le":
                                    case "utf-16le":
                                        return d = e, m = r, N(function(t, e) {
                                            for (var r, n, i = [], s = 0; s < t.length && !((e -= 2) < 0); ++s) n = (r = t.charCodeAt(s)) >> 8, i.push(r % 256), i.push(n);
                                            return i
                                        }(t, this.length - d), this, d, m);
                                    default:
                                        if (y) throw TypeError("Unknown encoding: " + n);
                                        n = ("" + n).toLowerCase(), y = !0
                                }
                            }, o.prototype.toJSON = function() {
                                return {
                                    type: "Buffer",
                                    data: Array.prototype.slice.call(this._arr || this, 0)
                                }
                            }, o.prototype.slice = function(t, e) {
                                var r = this.length;
                                t = ~~t, e = void 0 === e ? r : ~~e, t < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), e < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t);
                                var n = this.subarray(t, e);
                                return Object.setPrototypeOf(n, o.prototype), n
                            }, o.prototype.readUIntLE = function(t, e, r) {
                                t >>>= 0, e >>>= 0, r || b(t, e, this.length);
                                for (var n = this[t], i = 1, s = 0; ++s < e && (i *= 256);) n += this[t + s] * i;
                                return n
                            }, o.prototype.readUIntBE = function(t, e, r) {
                                t >>>= 0, e >>>= 0, r || b(t, e, this.length);
                                for (var n = this[t + --e], i = 1; e > 0 && (i *= 256);) n += this[t + --e] * i;
                                return n
                            }, o.prototype.readUInt8 = function(t, e) {
                                return t >>>= 0, e || b(t, 1, this.length), this[t]
                            }, o.prototype.readUInt16LE = function(t, e) {
                                return t >>>= 0, e || b(t, 2, this.length), this[t] | this[t + 1] << 8
                            }, o.prototype.readUInt16BE = function(t, e) {
                                return t >>>= 0, e || b(t, 2, this.length), this[t] << 8 | this[t + 1]
                            }, o.prototype.readUInt32LE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3]
                            }, o.prototype.readUInt32BE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3])
                            }, o.prototype.readIntLE = function(t, e, r) {
                                t >>>= 0, e >>>= 0, r || b(t, e, this.length);
                                for (var n = this[t], i = 1, s = 0; ++s < e && (i *= 256);) n += this[t + s] * i;
                                return n >= (i *= 128) && (n -= Math.pow(2, 8 * e)), n
                            }, o.prototype.readIntBE = function(t, e, r) {
                                t >>>= 0, e >>>= 0, r || b(t, e, this.length);
                                for (var n = e, i = 1, s = this[t + --n]; n > 0 && (i *= 256);) s += this[t + --n] * i;
                                return s >= (i *= 128) && (s -= Math.pow(2, 8 * e)), s
                            }, o.prototype.readInt8 = function(t, e) {
                                return (t >>>= 0, e || b(t, 1, this.length), 128 & this[t]) ? -((255 - this[t] + 1) * 1) : this[t]
                            }, o.prototype.readInt16LE = function(t, e) {
                                t >>>= 0, e || b(t, 2, this.length);
                                var r = this[t] | this[t + 1] << 8;
                                return 32768 & r ? 4294901760 | r : r
                            }, o.prototype.readInt16BE = function(t, e) {
                                t >>>= 0, e || b(t, 2, this.length);
                                var r = this[t + 1] | this[t] << 8;
                                return 32768 & r ? 4294901760 | r : r
                            }, o.prototype.readInt32LE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24
                            }, o.prototype.readInt32BE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]
                            }, o.prototype.readFloatLE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), i.read(this, t, !0, 23, 4)
                            }, o.prototype.readFloatBE = function(t, e) {
                                return t >>>= 0, e || b(t, 4, this.length), i.read(this, t, !1, 23, 4)
                            }, o.prototype.readDoubleLE = function(t, e) {
                                return t >>>= 0, e || b(t, 8, this.length), i.read(this, t, !0, 52, 8)
                            }, o.prototype.readDoubleBE = function(t, e) {
                                return t >>>= 0, e || b(t, 8, this.length), i.read(this, t, !1, 52, 8)
                            }, o.prototype.writeUIntLE = function(t, e, r, n) {
                                if (t = +t, e >>>= 0, r >>>= 0, !n) {
                                    var i = Math.pow(2, 8 * r) - 1;
                                    E(this, t, e, r, i, 0)
                                }
                                var s = 1,
                                    a = 0;
                                for (this[e] = 255 & t; ++a < r && (s *= 256);) this[e + a] = t / s & 255;
                                return e + r
                            }, o.prototype.writeUIntBE = function(t, e, r, n) {
                                if (t = +t, e >>>= 0, r >>>= 0, !n) {
                                    var i = Math.pow(2, 8 * r) - 1;
                                    E(this, t, e, r, i, 0)
                                }
                                var s = r - 1,
                                    a = 1;
                                for (this[e + s] = 255 & t; --s >= 0 && (a *= 256);) this[e + s] = t / a & 255;
                                return e + r
                            }, o.prototype.writeUInt8 = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1
                            }, o.prototype.writeUInt16LE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2
                            }, o.prototype.writeUInt16BE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2
                            }, o.prototype.writeUInt32LE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4
                            }, o.prototype.writeUInt32BE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4
                            }, o.prototype.writeIntLE = function(t, e, r, n) {
                                if (t = +t, e >>>= 0, !n) {
                                    var i = Math.pow(2, 8 * r - 1);
                                    E(this, t, e, r, i - 1, -i)
                                }
                                var s = 0,
                                    a = 1,
                                    o = 0;
                                for (this[e] = 255 & t; ++s < r && (a *= 256);) t < 0 && 0 === o && 0 !== this[e + s - 1] && (o = 1), this[e + s] = (t / a >> 0) - o & 255;
                                return e + r
                            }, o.prototype.writeIntBE = function(t, e, r, n) {
                                if (t = +t, e >>>= 0, !n) {
                                    var i = Math.pow(2, 8 * r - 1);
                                    E(this, t, e, r, i - 1, -i)
                                }
                                var s = r - 1,
                                    a = 1,
                                    o = 0;
                                for (this[e + s] = 255 & t; --s >= 0 && (a *= 256);) t < 0 && 0 === o && 0 !== this[e + s + 1] && (o = 1), this[e + s] = (t / a >> 0) - o & 255;
                                return e + r
                            }, o.prototype.writeInt8 = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1
                            }, o.prototype.writeInt16LE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 2, 32767, -32768), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2
                            }, o.prototype.writeInt16BE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2
                            }, o.prototype.writeInt32LE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4
                            }, o.prototype.writeInt32BE = function(t, e, r) {
                                return t = +t, e >>>= 0, r || E(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4
                            }, o.prototype.writeFloatLE = function(t, e, r) {
                                return T(this, t, e, !0, r)
                            }, o.prototype.writeFloatBE = function(t, e, r) {
                                return T(this, t, e, !1, r)
                            }, o.prototype.writeDoubleLE = function(t, e, r) {
                                return D(this, t, e, !0, r)
                            }, o.prototype.writeDoubleBE = function(t, e, r) {
                                return D(this, t, e, !1, r)
                            }, o.prototype.copy = function(t, e, r, n) {
                                if (!o.isBuffer(t)) throw TypeError("argument should be a Buffer");
                                if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), e || (e = 0), n > 0 && n < r && (n = r), n === r || 0 === t.length || 0 === this.length) return 0;
                                if (e < 0) throw RangeError("targetStart out of bounds");
                                if (r < 0 || r >= this.length) throw RangeError("Index out of range");
                                if (n < 0) throw RangeError("sourceEnd out of bounds");
                                n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
                                var i = n - r;
                                if (this === t && "function" == typeof Uint8Array.prototype.copyWithin) this.copyWithin(e, r, n);
                                else if (this === t && r < e && e < n)
                                    for (var s = i - 1; s >= 0; --s) t[s + e] = this[s + r];
                                else Uint8Array.prototype.set.call(t, this.subarray(r, n), e);
                                return i
                            }, o.prototype.fill = function(t, e, r, n) {
                                if ("string" == typeof t) {
                                    if ("string" == typeof e ? (n = e, e = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw TypeError("encoding must be a string");
                                    if ("string" == typeof n && !o.isEncoding(n)) throw TypeError("Unknown encoding: " + n);
                                    if (1 === t.length) {
                                        var i, s = t.charCodeAt(0);
                                        ("utf8" === n && s < 128 || "latin1" === n) && (t = s)
                                    }
                                } else "number" == typeof t ? t &= 255 : "boolean" == typeof t && (t = Number(t));
                                if (e < 0 || this.length < e || this.length < r) throw RangeError("Out of range index");
                                if (r <= e) return this;
                                if (e >>>= 0, r = void 0 === r ? this.length : r >>> 0, t || (t = 0), "number" == typeof t)
                                    for (i = e; i < r; ++i) this[i] = t;
                                else {
                                    var a = o.isBuffer(t) ? t : o.from(t, n),
                                        u = a.length;
                                    if (0 === u) throw TypeError('The value "' + t + '" is invalid for argument "value"');
                                    for (i = 0; i < r - e; ++i) this[i + e] = a[i % u]
                                }
                                return this
                            };
                            var x = /[^+/0-9A-Za-z-_]/g;

                            function S(t, e) {
                                e = e || 1 / 0;
                                for (var r, n = t.length, i = null, s = [], a = 0; a < n; ++a) {
                                    if ((r = t.charCodeAt(a)) > 55295 && r < 57344) {
                                        if (!i) {
                                            if (r > 56319 || a + 1 === n) {
                                                (e -= 3) > -1 && s.push(239, 191, 189);
                                                continue
                                            }
                                            i = r;
                                            continue
                                        }
                                        if (r < 56320) {
                                            (e -= 3) > -1 && s.push(239, 191, 189), i = r;
                                            continue
                                        }
                                        r = (i - 55296 << 10 | r - 56320) + 65536
                                    } else i && (e -= 3) > -1 && s.push(239, 191, 189);
                                    if (i = null, r < 128) {
                                        if ((e -= 1) < 0) break;
                                        s.push(r)
                                    } else if (r < 2048) {
                                        if ((e -= 2) < 0) break;
                                        s.push(r >> 6 | 192, 63 & r | 128)
                                    } else if (r < 65536) {
                                        if ((e -= 3) < 0) break;
                                        s.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128)
                                    } else if (r < 1114112) {
                                        if ((e -= 4) < 0) break;
                                        s.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128)
                                    } else throw Error("Invalid code point")
                                }
                                return s
                            }

                            function A(t) {
                                for (var e = [], r = 0; r < t.length; ++r) e.push(255 & t.charCodeAt(r));
                                return e
                            }

                            function R(t) {
                                return n.toByteArray(function(t) {
                                    if ((t = (t = t.split("=")[0]).trim().replace(x, "")).length < 2) return "";
                                    for (; t.length % 4 != 0;) t += "=";
                                    return t
                                }(t))
                            }

                            function N(t, e, r, n) {
                                for (var i = 0; i < n && !(i + r >= e.length) && !(i >= t.length); ++i) e[i + r] = t[i];
                                return i
                            }

                            function P(t, e) {
                                return t instanceof e || null != t && null != t.constructor && null != t.constructor.name && t.constructor.name === e.name
                            }
                            var C = function() {
                                for (var t = "0123456789abcdef", e = Array(256), r = 0; r < 16; ++r)
                                    for (var n = 16 * r, i = 0; i < 16; ++i) e[n + i] = t[r] + t[i];
                                return e
                            }()
                        },
                        783: function(t, e) { /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
                            e.read = function(t, e, r, n, i) {
                                var s, a, o = 8 * i - n - 1,
                                    u = (1 << o) - 1,
                                    l = u >> 1,
                                    c = -7,
                                    h = r ? i - 1 : 0,
                                    f = r ? -1 : 1,
                                    p = t[e + h];
                                for (h += f, s = p & (1 << -c) - 1, p >>= -c, c += o; c > 0; s = 256 * s + t[e + h], h += f, c -= 8);
                                for (a = s & (1 << -c) - 1, s >>= -c, c += n; c > 0; a = 256 * a + t[e + h], h += f, c -= 8);
                                if (0 === s) s = 1 - l;
                                else {
                                    if (s === u) return a ? NaN : 1 / 0 * (p ? -1 : 1);
                                    a += Math.pow(2, n), s -= l
                                }
                                return (p ? -1 : 1) * a * Math.pow(2, s - n)
                            }, e.write = function(t, e, r, n, i, s) {
                                var a, o, u, l = 8 * s - i - 1,
                                    c = (1 << l) - 1,
                                    h = c >> 1,
                                    f = 23 === i ? 5960464477539062e-23 : 0,
                                    p = n ? 0 : s - 1,
                                    d = n ? 1 : -1,
                                    m = e < 0 || 0 === e && 1 / e < 0 ? 1 : 0;
                                for (isNaN(e = Math.abs(e)) || e === 1 / 0 ? (o = isNaN(e) ? 1 : 0, a = c) : (a = Math.floor(Math.log(e) / Math.LN2), e * (u = Math.pow(2, -a)) < 1 && (a--, u *= 2), a + h >= 1 ? e += f / u : e += f * Math.pow(2, 1 - h), e * u >= 2 && (a++, u /= 2), a + h >= c ? (o = 0, a = c) : a + h >= 1 ? (o = (e * u - 1) * Math.pow(2, i), a += h) : (o = e * Math.pow(2, h - 1) * Math.pow(2, i), a = 0)); i >= 8; t[r + p] = 255 & o, p += d, o /= 256, i -= 8);
                                for (a = a << i | o, l += i; l > 0; t[r + p] = 255 & a, p += d, a /= 256, l -= 8);
                                t[r + p - d] |= 128 * m
                            }
                        }
                    },
                    r = {};

                function n(t) {
                    var i = r[t];
                    if (void 0 !== i) return i.exports;
                    var s = r[t] = {
                            exports: {}
                        },
                        a = !0;
                    try {
                        e[t](s, s.exports, n), a = !1
                    } finally {
                        a && delete r[t]
                    }
                    return s.exports
                }
                n.ab = "//";
                var i = n(72);
                t.exports = i
            }()
        },
        1943: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "escapeStringRegexp", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            let r = /[|\\{}()[\]^$+*?.-]/,
                n = /[|\\{}()[\]^$+*?.-]/g;

            function i(t) {
                return r.test(t) ? t.replace(n, "\\$&") : t
            }
        },
        291: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "RouterContext", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = r(9920)._(r(2265)).default.createContext(null)
        },
        1142: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    formatUrl: function() {
                        return s
                    },
                    formatWithValidation: function() {
                        return o
                    },
                    urlObjectKeys: function() {
                        return a
                    }
                });
            let n = r(1452)._(r(8323)),
                i = /https?|ftp|gopher|file/;

            function s(t) {
                let {
                    auth: e,
                    hostname: r
                } = t, s = t.protocol || "", a = t.pathname || "", o = t.hash || "", u = t.query || "", l = !1;
                e = e ? encodeURIComponent(e).replace(/%3A/i, ":") + "@" : "", t.host ? l = e + t.host : r && (l = e + (~r.indexOf(":") ? "[" + r + "]" : r), t.port && (l += ":" + t.port)), u && "object" == typeof u && (u = String(n.urlQueryToSearchParams(u)));
                let c = t.search || u && "?" + u || "";
                return s && !s.endsWith(":") && (s += ":"), t.slashes || (!s || i.test(s)) && !1 !== l ? (l = "//" + (l || ""), a && "/" !== a[0] && (a = "/" + a)) : l || (l = ""), o && "#" !== o[0] && (o = "#" + o), c && "?" !== c[0] && (c = "?" + c), "" + s + l + (a = a.replace(/[?#]/g, encodeURIComponent)) + (c = c.replace("#", "%23")) + o
            }
            let a = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

            function o(t) {
                return s(t)
            }
        },
        9195: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    getSortedRoutes: function() {
                        return n.getSortedRoutes
                    },
                    isDynamicRoute: function() {
                        return i.isDynamicRoute
                    }
                });
            let n = r(9089),
                i = r(8083)
        },
        20: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "interpolateAs", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = r(1533),
                i = r(3169);

            function s(t, e, r) {
                let s = "",
                    a = (0, i.getRouteRegex)(t),
                    o = a.groups,
                    u = (e !== t ? (0, n.getRouteMatcher)(a)(e) : "") || r;
                s = t;
                let l = Object.keys(o);
                return l.every(t => {
                    let e = u[t] || "",
                        {
                            repeat: r,
                            optional: n
                        } = o[t],
                        i = "[" + (r ? "..." : "") + t + "]";
                    return n && (i = (e ? "" : "/") + "[" + i + "]"), r && !Array.isArray(e) && (e = [e]), (n || t in u) && (s = s.replace(i, r ? e.map(t => encodeURIComponent(t)).join("/") : encodeURIComponent(e)) || "/")
                }) || (s = ""), {
                    params: l,
                    result: s
                }
            }
        },
        8083: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isDynamicRoute", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = r(2269),
                i = /\/\[[^/]+?\](?=\/|$)/;

            function s(t) {
                return (0, n.isInterceptionRouteAppPath)(t) && (t = (0, n.extractInterceptionRouteInformation)(t).interceptedRoute), i.test(t)
            }
        },
        8029: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isLocalURL", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = r(3461),
                i = r(9404);

            function s(t) {
                if (!(0, n.isAbsoluteUrl)(t)) return !0;
                try {
                    let e = (0, n.getLocationOrigin)(),
                        r = new URL(t, e);
                    return r.origin === e && (0, i.hasBasePath)(r.pathname)
                } catch (t) {
                    return !1
                }
            }
        },
        5519: function(t, e) {
            "use strict";

            function r(t, e) {
                let r = {};
                return Object.keys(t).forEach(n => {
                    e.includes(n) || (r[n] = t[n])
                }), r
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "omit", {
                enumerable: !0,
                get: function() {
                    return r
                }
            })
        },
        8323: function(t, e) {
            "use strict";

            function r(t) {
                let e = {};
                return t.forEach((t, r) => {
                    void 0 === e[r] ? e[r] = t : Array.isArray(e[r]) ? e[r].push(t) : e[r] = [e[r], t]
                }), e
            }

            function n(t) {
                return "string" != typeof t && ("number" != typeof t || isNaN(t)) && "boolean" != typeof t ? "" : String(t)
            }

            function i(t) {
                let e = new URLSearchParams;
                return Object.entries(t).forEach(t => {
                    let [r, i] = t;
                    Array.isArray(i) ? i.forEach(t => e.append(r, n(t))) : e.set(r, n(i))
                }), e
            }

            function s(t) {
                for (var e = arguments.length, r = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) r[n - 1] = arguments[n];
                return r.forEach(e => {
                    Array.from(e.keys()).forEach(e => t.delete(e)), e.forEach((e, r) => t.append(r, e))
                }), t
            }
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    assign: function() {
                        return s
                    },
                    searchParamsToUrlQuery: function() {
                        return r
                    },
                    urlQueryToSearchParams: function() {
                        return i
                    }
                })
        },
        1533: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getRouteMatcher", {
                enumerable: !0,
                get: function() {
                    return i
                }
            });
            let n = r(3461);

            function i(t) {
                let {
                    re: e,
                    groups: r
                } = t;
                return t => {
                    let i = e.exec(t);
                    if (!i) return !1;
                    let s = t => {
                            try {
                                return decodeURIComponent(t)
                            } catch (t) {
                                throw new n.DecodeError("failed to decode param")
                            }
                        },
                        a = {};
                    return Object.keys(r).forEach(t => {
                        let e = r[t],
                            n = i[e.pos];
                        void 0 !== n && (a[t] = ~n.indexOf("/") ? n.split("/").map(t => s(t)) : e.repeat ? [s(n)] : s(n))
                    }), a
                }
            }
        },
        3169: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    getNamedMiddlewareRegex: function() {
                        return f
                    },
                    getNamedRouteRegex: function() {
                        return h
                    },
                    getRouteRegex: function() {
                        return u
                    }
                });
            let n = r(2269),
                i = r(1943),
                s = r(7741);

            function a(t) {
                let e = t.startsWith("[") && t.endsWith("]");
                e && (t = t.slice(1, -1));
                let r = t.startsWith("...");
                return r && (t = t.slice(3)), {
                    key: t,
                    repeat: r,
                    optional: e
                }
            }

            function o(t) {
                let e = (0, s.removeTrailingSlash)(t).slice(1).split("/"),
                    r = {},
                    o = 1;
                return {
                    parameterizedRoute: e.map(t => {
                        let e = n.INTERCEPTION_ROUTE_MARKERS.find(e => t.startsWith(e)),
                            s = t.match(/\[((?:\[.*\])|.+)\]/);
                        if (e && s) {
                            let {
                                key: t,
                                optional: n,
                                repeat: u
                            } = a(s[1]);
                            return r[t] = {
                                pos: o++,
                                repeat: u,
                                optional: n
                            }, "/" + (0, i.escapeStringRegexp)(e) + "([^/]+?)"
                        }
                        if (!s) return "/" + (0, i.escapeStringRegexp)(t); {
                            let {
                                key: t,
                                repeat: e,
                                optional: n
                            } = a(s[1]);
                            return r[t] = {
                                pos: o++,
                                repeat: e,
                                optional: n
                            }, e ? n ? "(?:/(.+?))?" : "/(.+?)" : "/([^/]+?)"
                        }
                    }).join(""),
                    groups: r
                }
            }

            function u(t) {
                let {
                    parameterizedRoute: e,
                    groups: r
                } = o(t);
                return {
                    re: RegExp("^" + e + "(?:/)?$"),
                    groups: r
                }
            }

            function l(t) {
                let {
                    interceptionMarker: e,
                    getSafeRouteKey: r,
                    segment: n,
                    routeKeys: s,
                    keyPrefix: o
                } = t, {
                    key: u,
                    optional: l,
                    repeat: c
                } = a(n), h = u.replace(/\W/g, "");
                o && (h = "" + o + h);
                let f = !1;
                (0 === h.length || h.length > 30) && (f = !0), isNaN(parseInt(h.slice(0, 1))) || (f = !0), f && (h = r()), o ? s[h] = "" + o + u : s[h] = u;
                let p = e ? (0, i.escapeStringRegexp)(e) : "";
                return c ? l ? "(?:/" + p + "(?<" + h + ">.+?))?" : "/" + p + "(?<" + h + ">.+?)" : "/" + p + "(?<" + h + ">[^/]+?)"
            }

            function c(t, e) {
                let r;
                let a = (0, s.removeTrailingSlash)(t).slice(1).split("/"),
                    o = (r = 0, () => {
                        let t = "",
                            e = ++r;
                        for (; e > 0;) t += String.fromCharCode(97 + (e - 1) % 26), e = Math.floor((e - 1) / 26);
                        return t
                    }),
                    u = {};
                return {
                    namedParameterizedRoute: a.map(t => {
                        let r = n.INTERCEPTION_ROUTE_MARKERS.some(e => t.startsWith(e)),
                            s = t.match(/\[((?:\[.*\])|.+)\]/);
                        if (r && s) {
                            let [r] = t.split(s[0]);
                            return l({
                                getSafeRouteKey: o,
                                interceptionMarker: r,
                                segment: s[1],
                                routeKeys: u,
                                keyPrefix: e ? "nxtI" : void 0
                            })
                        }
                        return s ? l({
                            getSafeRouteKey: o,
                            segment: s[1],
                            routeKeys: u,
                            keyPrefix: e ? "nxtP" : void 0
                        }) : "/" + (0, i.escapeStringRegexp)(t)
                    }).join(""),
                    routeKeys: u
                }
            }

            function h(t, e) {
                let r = c(t, e);
                return { ...u(t),
                    namedRegex: "^" + r.namedParameterizedRoute + "(?:/)?$",
                    routeKeys: r.routeKeys
                }
            }

            function f(t, e) {
                let {
                    parameterizedRoute: r
                } = o(t), {
                    catchAll: n = !0
                } = e;
                if ("/" === r) return {
                    namedRegex: "^/" + (n ? ".*" : "") + "$"
                };
                let {
                    namedParameterizedRoute: i
                } = c(t, !1);
                return {
                    namedRegex: "^" + i + (n ? "(?:(/.*)?)" : "") + "$"
                }
            }
        },
        9089: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getSortedRoutes", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            class r {
                insert(t) {
                    this._insert(t.split("/").filter(Boolean), [], !1)
                }
                smoosh() {
                    return this._smoosh()
                }
                _smoosh(t) {
                    void 0 === t && (t = "/");
                    let e = [...this.children.keys()].sort();
                    null !== this.slugName && e.splice(e.indexOf("[]"), 1), null !== this.restSlugName && e.splice(e.indexOf("[...]"), 1), null !== this.optionalRestSlugName && e.splice(e.indexOf("[[...]]"), 1);
                    let r = e.map(e => this.children.get(e)._smoosh("" + t + e + "/")).reduce((t, e) => [...t, ...e], []);
                    if (null !== this.slugName && r.push(...this.children.get("[]")._smoosh(t + "[" + this.slugName + "]/")), !this.placeholder) {
                        let e = "/" === t ? "/" : t.slice(0, -1);
                        if (null != this.optionalRestSlugName) throw Error('You cannot define a route with the same specificity as a optional catch-all route ("' + e + '" and "' + e + "[[..." + this.optionalRestSlugName + ']]").');
                        r.unshift(e)
                    }
                    return null !== this.restSlugName && r.push(...this.children.get("[...]")._smoosh(t + "[..." + this.restSlugName + "]/")), null !== this.optionalRestSlugName && r.push(...this.children.get("[[...]]")._smoosh(t + "[[..." + this.optionalRestSlugName + "]]/")), r
                }
                _insert(t, e, n) {
                    if (0 === t.length) {
                        this.placeholder = !1;
                        return
                    }
                    if (n) throw Error("Catch-all must be the last part of the URL.");
                    let i = t[0];
                    if (i.startsWith("[") && i.endsWith("]")) {
                        let r = i.slice(1, -1),
                            a = !1;
                        if (r.startsWith("[") && r.endsWith("]") && (r = r.slice(1, -1), a = !0), r.startsWith("...") && (r = r.substring(3), n = !0), r.startsWith("[") || r.endsWith("]")) throw Error("Segment names may not start or end with extra brackets ('" + r + "').");
                        if (r.startsWith(".")) throw Error("Segment names may not start with erroneous periods ('" + r + "').");

                        function s(t, r) {
                            if (null !== t && t !== r) throw Error("You cannot use different slug names for the same dynamic path ('" + t + "' !== '" + r + "').");
                            e.forEach(t => {
                                if (t === r) throw Error('You cannot have the same slug name "' + r + '" repeat within a single dynamic path');
                                if (t.replace(/\W/g, "") === i.replace(/\W/g, "")) throw Error('You cannot have the slug names "' + t + '" and "' + r + '" differ only by non-word symbols within a single dynamic path')
                            }), e.push(r)
                        }
                        if (n) {
                            if (a) {
                                if (null != this.restSlugName) throw Error('You cannot use both an required and optional catch-all route at the same level ("[...' + this.restSlugName + ']" and "' + t[0] + '" ).');
                                s(this.optionalRestSlugName, r), this.optionalRestSlugName = r, i = "[[...]]"
                            } else {
                                if (null != this.optionalRestSlugName) throw Error('You cannot use both an optional and required catch-all route at the same level ("[[...' + this.optionalRestSlugName + ']]" and "' + t[0] + '").');
                                s(this.restSlugName, r), this.restSlugName = r, i = "[...]"
                            }
                        } else {
                            if (a) throw Error('Optional route parameters are not yet supported ("' + t[0] + '").');
                            s(this.slugName, r), this.slugName = r, i = "[]"
                        }
                    }
                    this.children.has(i) || this.children.set(i, new r), this.children.get(i)._insert(t.slice(1), e, n)
                }
                constructor() {
                    this.placeholder = !0, this.children = new Map, this.slugName = null, this.restSlugName = null, this.optionalRestSlugName = null
                }
            }

            function n(t) {
                let e = new r;
                return t.forEach(t => e.insert(t)), e.smoosh()
            }
        },
        3461: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var r in e) Object.defineProperty(t, r, {
                        enumerable: !0,
                        get: e[r]
                    })
                }(e, {
                    DecodeError: function() {
                        return d
                    },
                    MiddlewareNotFoundError: function() {
                        return v
                    },
                    MissingStaticPage: function() {
                        return y
                    },
                    NormalizeError: function() {
                        return m
                    },
                    PageNotFoundError: function() {
                        return g
                    },
                    SP: function() {
                        return f
                    },
                    ST: function() {
                        return p
                    },
                    WEB_VITALS: function() {
                        return r
                    },
                    execOnce: function() {
                        return n
                    },
                    getDisplayName: function() {
                        return u
                    },
                    getLocationOrigin: function() {
                        return a
                    },
                    getURL: function() {
                        return o
                    },
                    isAbsoluteUrl: function() {
                        return s
                    },
                    isResSent: function() {
                        return l
                    },
                    loadGetInitialProps: function() {
                        return h
                    },
                    normalizeRepeatedSlashes: function() {
                        return c
                    },
                    stringifyError: function() {
                        return b
                    }
                });
            let r = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

            function n(t) {
                let e, r = !1;
                return function() {
                    for (var n = arguments.length, i = Array(n), s = 0; s < n; s++) i[s] = arguments[s];
                    return r || (r = !0, e = t(...i)), e
                }
            }
            let i = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
                s = t => i.test(t);

            function a() {
                let {
                    protocol: t,
                    hostname: e,
                    port: r
                } = window.location;
                return t + "//" + e + (r ? ":" + r : "")
            }

            function o() {
                let {
                    href: t
                } = window.location, e = a();
                return t.substring(e.length)
            }

            function u(t) {
                return "string" == typeof t ? t : t.displayName || t.name || "Unknown"
            }

            function l(t) {
                return t.finished || t.headersSent
            }

            function c(t) {
                let e = t.split("?");
                return e[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (e[1] ? "?" + e.slice(1).join("?") : "")
            }
            async function h(t, e) {
                let r = e.res || e.ctx && e.ctx.res;
                if (!t.getInitialProps) return e.ctx && e.Component ? {
                    pageProps: await h(e.Component, e.ctx)
                } : {};
                let n = await t.getInitialProps(e);
                if (r && l(r)) return n;
                if (!n) throw Error('"' + u(t) + '.getInitialProps()" should resolve to an object. But found "' + n + '" instead.');
                return n
            }
            let f = "undefined" != typeof performance,
                p = f && ["mark", "measure", "getEntriesByName"].every(t => "function" == typeof performance[t]);
            class d extends Error {}
            class m extends Error {}
            class g extends Error {
                constructor(t) {
                    super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = "Cannot find module for page: " + t
                }
            }
            class y extends Error {
                constructor(t, e) {
                    super(), this.message = "Failed to load static file for page: " + t + " " + e
                }
            }
            class v extends Error {
                constructor() {
                    super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
                }
            }

            function b(t) {
                return JSON.stringify({
                    message: t.message,
                    stack: t.stack
                })
            }
        },
        939: function(t) {
            t.exports = function(t, e) {
                var r, n = null;
                try {
                    r = JSON.parse(t, e)
                } catch (t) {
                    n = t
                }
                return [n, r]
            }
        },
        3029: function(t) {
            var e, r, n, i, s;
            e = /^(?=((?:[a-zA-Z0-9+\-.]+:)?))\1(?=((?:\/\/[^\/?#]*)?))\2(?=((?:(?:[^?#\/]*\/)*[^;?#\/]*)?))\3((?:;[^?#]*)?)(\?[^#]*)?(#[^]*)?$/, r = /^(?=([^\/?#]*))\1([^]*)$/, n = /(?:\/|^)\.(?=\/)/g, i = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g, s = {
                buildAbsoluteURL: function(t, e, n) {
                    if (n = n || {}, t = t.trim(), !(e = e.trim())) {
                        if (!n.alwaysNormalize) return t;
                        var i = s.parseURL(t);
                        if (!i) throw Error("Error trying to parse base URL.");
                        return i.path = s.normalizePath(i.path), s.buildURLFromParts(i)
                    }
                    var a = s.parseURL(e);
                    if (!a) throw Error("Error trying to parse relative URL.");
                    if (a.scheme) return n.alwaysNormalize ? (a.path = s.normalizePath(a.path), s.buildURLFromParts(a)) : e;
                    var o = s.parseURL(t);
                    if (!o) throw Error("Error trying to parse base URL.");
                    if (!o.netLoc && o.path && "/" !== o.path[0]) {
                        var u = r.exec(o.path);
                        o.netLoc = u[1], o.path = u[2]
                    }
                    o.netLoc && !o.path && (o.path = "/");
                    var l = {
                        scheme: o.scheme,
                        netLoc: a.netLoc,
                        path: null,
                        params: a.params,
                        query: a.query,
                        fragment: a.fragment
                    };
                    if (!a.netLoc && (l.netLoc = o.netLoc, "/" !== a.path[0])) {
                        if (a.path) {
                            var c = o.path,
                                h = c.substring(0, c.lastIndexOf("/") + 1) + a.path;
                            l.path = s.normalizePath(h)
                        } else l.path = o.path, a.params || (l.params = o.params, a.query || (l.query = o.query))
                    }
                    return null === l.path && (l.path = n.alwaysNormalize ? s.normalizePath(a.path) : a.path), s.buildURLFromParts(l)
                },
                parseURL: function(t) {
                    var r = e.exec(t);
                    return r ? {
                        scheme: r[1] || "",
                        netLoc: r[2] || "",
                        path: r[3] || "",
                        params: r[4] || "",
                        query: r[5] || "",
                        fragment: r[6] || ""
                    } : null
                },
                normalizePath: function(t) {
                    for (t = t.split("").reverse().join("").replace(n, ""); t.length !== (t = t.replace(i, "")).length;);
                    return t.split("").reverse().join("")
                },
                buildURLFromParts: function(t) {
                    return t.scheme + t.netLoc + t.path + t.params + t.query + t.fragment
                }
            }, t.exports = s
        },
        9397: function(t, e, r) {
            var n = r(6076),
                i = t.exports = {
                    WebVTT: r(8410),
                    VTTCue: r(1929),
                    VTTRegion: r(6155)
                };
            n.vttjs = i, n.WebVTT = i.WebVTT;
            var s = i.VTTCue,
                a = i.VTTRegion,
                o = n.VTTCue,
                u = n.VTTRegion;
            i.shim = function() {
                n.VTTCue = s, n.VTTRegion = a
            }, i.restore = function() {
                n.VTTCue = o, n.VTTRegion = u
            }, n.VTTCue || i.shim()
        },
        8410: function(t, e, r) {
            var n = r(4856),
                i = Object.create || function() {
                    function t() {}
                    return function(e) {
                        if (1 != arguments.length) throw Error("Object.create shim only accepts one parameter.");
                        return t.prototype = e, new t
                    }
                }();

            function s(t, e) {
                this.name = "ParsingError", this.code = t.code, this.message = e || t.message
            }

            function a(t) {
                function e(t, e, r, n) {
                    return (0 | t) * 3600 + (0 | e) * 60 + (0 | r) + (0 | n) / 1e3
                }
                var r = t.match(/^(\d+):(\d{1,2})(:\d{1,2})?\.(\d{3})/);
                return r ? r[3] ? e(r[1], r[2], r[3].replace(":", ""), r[4]) : r[1] > 59 ? e(r[1], r[2], 0, r[4]) : e(0, r[1], r[2], r[4]) : null
            }

            function o() {
                this.values = i(null)
            }

            function u(t, e, r, n) {
                var i = n ? t.split(n) : [t];
                for (var s in i)
                    if ("string" == typeof i[s]) {
                        var a = i[s].split(r);
                        2 === a.length && e(a[0].trim(), a[1].trim())
                    }
            }
            s.prototype = i(Error.prototype), s.prototype.constructor = s, s.Errors = {
                BadSignature: {
                    code: 0,
                    message: "Malformed WebVTT signature."
                },
                BadTimeStamp: {
                    code: 1,
                    message: "Malformed time stamp."
                }
            }, o.prototype = {
                set: function(t, e) {
                    this.get(t) || "" === e || (this.values[t] = e)
                },
                get: function(t, e, r) {
                    return r ? this.has(t) ? this.values[t] : e[r] : this.has(t) ? this.values[t] : e
                },
                has: function(t) {
                    return t in this.values
                },
                alt: function(t, e, r) {
                    for (var n = 0; n < r.length; ++n)
                        if (e === r[n]) {
                            this.set(t, e);
                            break
                        }
                },
                integer: function(t, e) {
                    /^-?\d+$/.test(e) && this.set(t, parseInt(e, 10))
                },
                percent: function(t, e) {
                    return !!(e.match(/^([\d]{1,3})(\.[\d]*)?%$/) && (e = parseFloat(e)) >= 0 && e <= 100) && (this.set(t, e), !0)
                }
            };
            var l = n.createElement && n.createElement("textarea"),
                c = {
                    c: "span",
                    i: "i",
                    b: "b",
                    u: "u",
                    ruby: "ruby",
                    rt: "rt",
                    v: "span",
                    lang: "span"
                },
                h = {
                    white: "rgba(255,255,255,1)",
                    lime: "rgba(0,255,0,1)",
                    cyan: "rgba(0,255,255,1)",
                    red: "rgba(255,0,0,1)",
                    yellow: "rgba(255,255,0,1)",
                    magenta: "rgba(255,0,255,1)",
                    blue: "rgba(0,0,255,1)",
                    black: "rgba(0,0,0,1)"
                },
                f = {
                    v: "title",
                    lang: "lang"
                },
                p = {
                    rt: "ruby"
                };

            function d(t, e) {
                for (var r, n = t.document.createElement("div"), i = n, s = []; null !== (r = function() {
                        if (!e) return null;
                        var t, r = e.match(/^([^<]*)(<[^>]*>?)?/);
                        return t = r[1] ? r[1] : r[2], e = e.substr(t.length), t
                    }());) {
                    if ("<" === r[0]) {
                        if ("/" === r[1]) {
                            s.length && s[s.length - 1] === r.substr(2).replace(">", "") && (s.pop(), i = i.parentNode);
                            continue
                        }
                        var o, u, d, m, g = a(r.substr(1, r.length - 2));
                        if (g) {
                            m = t.document.createProcessingInstruction("timestamp", g), i.appendChild(m);
                            continue
                        }
                        var y = r.match(/^<([^.\s/0-9>]+)(\.[^\s\\>]+)?([^>\\]+)?(\\?)>?$/);
                        if (!y || !(m = function(e, r) {
                                var n = c[e];
                                if (!n) return null;
                                var i = t.document.createElement(n),
                                    s = f[e];
                                return s && r && (i[s] = r.trim()), i
                            }(y[1], y[3])) || (u = i, p[(d = m).localName] && p[d.localName] !== u.localName)) continue;
                        if (y[2]) {
                            var v = y[2].split(".");
                            v.forEach(function(t) {
                                var e = /^bg_/.test(t),
                                    r = e ? t.slice(3) : t;
                                if (h.hasOwnProperty(r)) {
                                    var n = e ? "background-color" : "color",
                                        i = h[r];
                                    m.style[n] = i
                                }
                            }), m.className = v.join(" ")
                        }
                        s.push(y[1]), i.appendChild(m), i = m;
                        continue
                    }
                    i.appendChild(t.document.createTextNode((o = r, l.innerHTML = o, o = l.textContent, l.textContent = "", o)))
                }
                return n
            }
            var m = [
                [1470, 1470],
                [1472, 1472],
                [1475, 1475],
                [1478, 1478],
                [1488, 1514],
                [1520, 1524],
                [1544, 1544],
                [1547, 1547],
                [1549, 1549],
                [1563, 1563],
                [1566, 1610],
                [1645, 1647],
                [1649, 1749],
                [1765, 1766],
                [1774, 1775],
                [1786, 1805],
                [1807, 1808],
                [1810, 1839],
                [1869, 1957],
                [1969, 1969],
                [1984, 2026],
                [2036, 2037],
                [2042, 2042],
                [2048, 2069],
                [2074, 2074],
                [2084, 2084],
                [2088, 2088],
                [2096, 2110],
                [2112, 2136],
                [2142, 2142],
                [2208, 2208],
                [2210, 2220],
                [8207, 8207],
                [64285, 64285],
                [64287, 64296],
                [64298, 64310],
                [64312, 64316],
                [64318, 64318],
                [64320, 64321],
                [64323, 64324],
                [64326, 64449],
                [64467, 64829],
                [64848, 64911],
                [64914, 64967],
                [65008, 65020],
                [65136, 65140],
                [65142, 65276],
                [67584, 67589],
                [67592, 67592],
                [67594, 67637],
                [67639, 67640],
                [67644, 67644],
                [67647, 67669],
                [67671, 67679],
                [67840, 67867],
                [67872, 67897],
                [67903, 67903],
                [67968, 68023],
                [68030, 68031],
                [68096, 68096],
                [68112, 68115],
                [68117, 68119],
                [68121, 68147],
                [68160, 68167],
                [68176, 68184],
                [68192, 68223],
                [68352, 68405],
                [68416, 68437],
                [68440, 68466],
                [68472, 68479],
                [68608, 68680],
                [126464, 126467],
                [126469, 126495],
                [126497, 126498],
                [126500, 126500],
                [126503, 126503],
                [126505, 126514],
                [126516, 126519],
                [126521, 126521],
                [126523, 126523],
                [126530, 126530],
                [126535, 126535],
                [126537, 126537],
                [126539, 126539],
                [126541, 126543],
                [126545, 126546],
                [126548, 126548],
                [126551, 126551],
                [126553, 126553],
                [126555, 126555],
                [126557, 126557],
                [126559, 126559],
                [126561, 126562],
                [126564, 126564],
                [126567, 126570],
                [126572, 126578],
                [126580, 126583],
                [126585, 126588],
                [126590, 126590],
                [126592, 126601],
                [126603, 126619],
                [126625, 126627],
                [126629, 126633],
                [126635, 126651],
                [1114109, 1114109]
            ];

            function g() {}

            function y(t, e, r) {
                g.call(this), this.cue = e, this.cueDiv = d(t, e.text);
                var n = {
                    color: "rgba(255, 255, 255, 1)",
                    backgroundColor: "rgba(0, 0, 0, 0.8)",
                    position: "relative",
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    display: "inline",
                    writingMode: "" === e.vertical ? "horizontal-tb" : "lr" === e.vertical ? "vertical-lr" : "vertical-rl",
                    unicodeBidi: "plaintext"
                };
                this.applyStyles(n, this.cueDiv), this.div = t.document.createElement("div"), n = {
                    direction: function(t) {
                        var e = [],
                            r = "";
                        if (!t || !t.childNodes) return "ltr";

                        function n(t, e) {
                            for (var r = e.childNodes.length - 1; r >= 0; r--) t.push(e.childNodes[r])
                        }
                        for (n(e, t); r = function t(e) {
                                if (!e || !e.length) return null;
                                var r = e.pop(),
                                    i = r.textContent || r.innerText;
                                if (i) {
                                    var s = i.match(/^.*(\n|\r)/);
                                    return s ? (e.length = 0, s[0]) : i
                                }
                                return "ruby" === r.tagName ? t(e) : r.childNodes ? (n(e, r), t(e)) : void 0
                            }(e);)
                            for (var i = 0; i < r.length; i++)
                                if (function(t) {
                                        for (var e = 0; e < m.length; e++) {
                                            var r = m[e];
                                            if (t >= r[0] && t <= r[1]) return !0
                                        }
                                        return !1
                                    }(r.charCodeAt(i))) return "rtl";
                        return "ltr"
                    }(this.cueDiv),
                    writingMode: "" === e.vertical ? "horizontal-tb" : "lr" === e.vertical ? "vertical-lr" : "vertical-rl",
                    unicodeBidi: "plaintext",
                    textAlign: "middle" === e.align ? "center" : e.align,
                    font: r.font,
                    whiteSpace: "pre-line",
                    position: "absolute"
                }, this.applyStyles(n), this.div.appendChild(this.cueDiv);
                var i = 0;
                switch (e.positionAlign) {
                    case "start":
                    case "line-left":
                        i = e.position;
                        break;
                    case "center":
                        i = e.position - e.size / 2;
                        break;
                    case "end":
                    case "line-right":
                        i = e.position - e.size
                }
                "" === e.vertical ? this.applyStyles({
                    left: this.formatStyle(i, "%"),
                    width: this.formatStyle(e.size, "%")
                }) : this.applyStyles({
                    top: this.formatStyle(i, "%"),
                    height: this.formatStyle(e.size, "%")
                }), this.move = function(t) {
                    this.applyStyles({
                        top: this.formatStyle(t.top, "px"),
                        bottom: this.formatStyle(t.bottom, "px"),
                        left: this.formatStyle(t.left, "px"),
                        right: this.formatStyle(t.right, "px"),
                        height: this.formatStyle(t.height, "px"),
                        width: this.formatStyle(t.width, "px")
                    })
                }
            }

            function v(t) {
                var e, r, n, i;
                if (t.div) {
                    r = t.div.offsetHeight, n = t.div.offsetWidth, i = t.div.offsetTop;
                    var s = (s = t.div.childNodes) && (s = s[0]) && s.getClientRects && s.getClientRects();
                    t = t.div.getBoundingClientRect(), e = s ? Math.max(s[0] && s[0].height || 0, t.height / s.length) : 0
                }
                this.left = t.left, this.right = t.right, this.top = t.top || i, this.height = t.height || r, this.bottom = t.bottom || i + (t.height || r), this.width = t.width || n, this.lineHeight = void 0 !== e ? e : t.lineHeight
            }

            function b() {}
            g.prototype.applyStyles = function(t, e) {
                for (var r in e = e || this.div, t) t.hasOwnProperty(r) && (e.style[r] = t[r])
            }, g.prototype.formatStyle = function(t, e) {
                return 0 === t ? 0 : t + e
            }, y.prototype = i(g.prototype), y.prototype.constructor = y, v.prototype.move = function(t, e) {
                switch (e = void 0 !== e ? e : this.lineHeight, t) {
                    case "+x":
                        this.left += e, this.right += e;
                        break;
                    case "-x":
                        this.left -= e, this.right -= e;
                        break;
                    case "+y":
                        this.top += e, this.bottom += e;
                        break;
                    case "-y":
                        this.top -= e, this.bottom -= e
                }
            }, v.prototype.overlaps = function(t) {
                return this.left < t.right && this.right > t.left && this.top < t.bottom && this.bottom > t.top
            }, v.prototype.overlapsAny = function(t) {
                for (var e = 0; e < t.length; e++)
                    if (this.overlaps(t[e])) return !0;
                return !1
            }, v.prototype.within = function(t) {
                return this.top >= t.top && this.bottom <= t.bottom && this.left >= t.left && this.right <= t.right
            }, v.prototype.overlapsOppositeAxis = function(t, e) {
                switch (e) {
                    case "+x":
                        return this.left < t.left;
                    case "-x":
                        return this.right > t.right;
                    case "+y":
                        return this.top < t.top;
                    case "-y":
                        return this.bottom > t.bottom
                }
            }, v.prototype.intersectPercentage = function(t) {
                return Math.max(0, Math.min(this.right, t.right) - Math.max(this.left, t.left)) * Math.max(0, Math.min(this.bottom, t.bottom) - Math.max(this.top, t.top)) / (this.height * this.width)
            }, v.prototype.toCSSCompatValues = function(t) {
                return {
                    top: this.top - t.top,
                    bottom: t.bottom - this.bottom,
                    left: this.left - t.left,
                    right: t.right - this.right,
                    height: this.height,
                    width: this.width
                }
            }, v.getSimpleBoxPosition = function(t) {
                var e = t.div ? t.div.offsetHeight : t.tagName ? t.offsetHeight : 0,
                    r = t.div ? t.div.offsetWidth : t.tagName ? t.offsetWidth : 0,
                    n = t.div ? t.div.offsetTop : t.tagName ? t.offsetTop : 0;
                return {
                    left: (t = t.div ? t.div.getBoundingClientRect() : t.tagName ? t.getBoundingClientRect() : t).left,
                    right: t.right,
                    top: t.top || n,
                    height: t.height || e,
                    bottom: t.bottom || n + (t.height || e),
                    width: t.width || r
                }
            }, b.StringDecoder = function() {
                return {
                    decode: function(t) {
                        if (!t) return "";
                        if ("string" != typeof t) throw Error("Error - expected string data.");
                        return decodeURIComponent(encodeURIComponent(t))
                    }
                }
            }, b.convertCueToDOMTree = function(t, e) {
                return t && e ? d(t, e) : null
            }, b.processCues = function(t, e, r) {
                if (!t || !e || !r) return null;
                for (; r.firstChild;) r.removeChild(r.firstChild);
                var n = t.document.createElement("div");
                if (n.style.position = "absolute", n.style.left = "0", n.style.right = "0", n.style.top = "0", n.style.bottom = "0", n.style.margin = "1.5%", r.appendChild(n), ! function(t) {
                        for (var e = 0; e < t.length; e++)
                            if (t[e].hasBeenReset || !t[e].displayState) return !0;
                        return !1
                    }(e)) {
                    for (var i = 0; i < e.length; i++) n.appendChild(e[i].displayState);
                    return
                }
                var s = [],
                    a = v.getSimpleBoxPosition(n),
                    o = {
                        font: Math.round(5 * a.height) / 100 + "px sans-serif"
                    };
                ! function() {
                    for (var r, i, u = 0; u < e.length; u++) r = new y(t, i = e[u], o), n.appendChild(r.div),
                        function(t, e, r, n) {
                            var i = new v(e),
                                s = e.cue,
                                a = function(t) {
                                    if ("number" == typeof t.line && (t.snapToLines || t.line >= 0 && t.line <= 100)) return t.line;
                                    if (!t.track || !t.track.textTrackList || !t.track.textTrackList.mediaElement) return -1;
                                    for (var e = t.track, r = e.textTrackList, n = 0, i = 0; i < r.length && r[i] !== e; i++) "showing" === r[i].mode && n++;
                                    return -1 * ++n
                                }(s),
                                o = [];
                            if (s.snapToLines) {
                                switch (s.vertical) {
                                    case "":
                                        o = ["+y", "-y"], u = "height";
                                        break;
                                    case "rl":
                                        o = ["+x", "-x"], u = "width";
                                        break;
                                    case "lr":
                                        o = ["-x", "+x"], u = "width"
                                }
                                var u, l = i.lineHeight,
                                    c = l * Math.round(a),
                                    h = r[u] + l,
                                    f = o[0];
                                Math.abs(c) > h && (c = Math.ceil(h / l) * l * (c < 0 ? -1 : 1)), a < 0 && (c += "" === s.vertical ? r.height : r.width, o = o.reverse()), i.move(f, c)
                            } else {
                                var p = i.lineHeight / r.height * 100;
                                switch (s.lineAlign) {
                                    case "center":
                                        a -= p / 2;
                                        break;
                                    case "end":
                                        a -= p
                                }
                                switch (s.vertical) {
                                    case "":
                                        e.applyStyles({
                                            top: e.formatStyle(a, "%")
                                        });
                                        break;
                                    case "rl":
                                        e.applyStyles({
                                            left: e.formatStyle(a, "%")
                                        });
                                        break;
                                    case "lr":
                                        e.applyStyles({
                                            right: e.formatStyle(a, "%")
                                        })
                                }
                                o = ["+y", "-x", "+x", "-y"], i = new v(e)
                            }
                            var d = function(t, e) {
                                for (var i, s = new v(t), a = 1, o = 0; o < e.length; o++) {
                                    for (; t.overlapsOppositeAxis(r, e[o]) || t.within(r) && t.overlapsAny(n);) t.move(e[o]);
                                    if (t.within(r)) return t;
                                    var u = t.intersectPercentage(r);
                                    a > u && (i = new v(t), a = u), t = new v(s)
                                }
                                return i || s
                            }(i, o);
                            e.move(d.toCSSCompatValues(r))
                        }(0, r, a, s), i.displayState = r.div, s.push(v.getSimpleBoxPosition(r))
                }()
            }, b.Parser = function(t, e, r) {
                r || (r = e, e = {}), e || (e = {}), this.window = t, this.vttjs = e, this.state = "INITIAL", this.buffer = "", this.decoder = r || new TextDecoder("utf8"), this.regionList = []
            }, b.Parser.prototype = {
                reportOrThrowError: function(t) {
                    if (t instanceof s) this.onparsingerror && this.onparsingerror(t);
                    else throw t
                },
                parse: function(t) {
                    var e = this;

                    function r() {
                        for (var t = e.buffer, r = 0; r < t.length && "\r" !== t[r] && "\n" !== t[r];) ++r;
                        var n = t.substr(0, r);
                        return "\r" === t[r] && ++r, "\n" === t[r] && ++r, e.buffer = t.substr(r), n
                    }
                    t && (e.buffer += e.decoder.decode(t, {
                        stream: !0
                    }));
                    try {
                        if ("INITIAL" === e.state) {
                            if (!/\r\n|\n/.test(e.buffer)) return this;
                            var n, i, l = (i = r()).match(/^WEBVTT([ \t].*)?$/);
                            if (!l || !l[0]) throw new s(s.Errors.BadSignature);
                            e.state = "HEADER"
                        }
                        for (var c = !1; e.buffer && /\r\n|\n/.test(e.buffer);) switch (c ? c = !1 : i = r(), e.state) {
                            case "HEADER":
                                /:/.test(i) ? (n = i).match(/X-TIMESTAMP-MAP/) ? u(n, function(t, r) {
                                    if ("X-TIMESTAMP-MAP" === t) {
                                        var n;
                                        n = new o, u(r, function(t, e) {
                                            switch (t) {
                                                case "MPEGT":
                                                    n.integer(t + "S", e);
                                                    break;
                                                case "LOCA":
                                                    n.set(t + "L", a(e))
                                            }
                                        }, /[^\d]:/, /,/), e.ontimestampmap && e.ontimestampmap({
                                            MPEGTS: n.get("MPEGTS"),
                                            LOCAL: n.get("LOCAL")
                                        })
                                    }
                                }, /=/) : u(n, function(t, r) {
                                    "Region" === t && function(t) {
                                        var r = new o;
                                        if (u(t, function(t, e) {
                                                switch (t) {
                                                    case "id":
                                                        r.set(t, e);
                                                        break;
                                                    case "width":
                                                        r.percent(t, e);
                                                        break;
                                                    case "lines":
                                                        r.integer(t, e);
                                                        break;
                                                    case "regionanchor":
                                                    case "viewportanchor":
                                                        var n = e.split(",");
                                                        if (2 !== n.length) break;
                                                        var i = new o;
                                                        if (i.percent("x", n[0]), i.percent("y", n[1]), !i.has("x") || !i.has("y")) break;
                                                        r.set(t + "X", i.get("x")), r.set(t + "Y", i.get("y"));
                                                        break;
                                                    case "scroll":
                                                        r.alt(t, e, ["up"])
                                                }
                                            }, /=/, /\s/), r.has("id")) {
                                            var n = new(e.vttjs.VTTRegion || e.window.VTTRegion);
                                            n.width = r.get("width", 100), n.lines = r.get("lines", 3), n.regionAnchorX = r.get("regionanchorX", 0), n.regionAnchorY = r.get("regionanchorY", 100), n.viewportAnchorX = r.get("viewportanchorX", 0), n.viewportAnchorY = r.get("viewportanchorY", 100), n.scroll = r.get("scroll", ""), e.onregion && e.onregion(n), e.regionList.push({
                                                id: r.get("id"),
                                                region: n
                                            })
                                        }
                                    }(r)
                                }, /:/) : i || (e.state = "ID");
                                continue;
                            case "NOTE":
                                i || (e.state = "ID");
                                continue;
                            case "ID":
                                if (/^NOTE($|[ \t])/.test(i)) {
                                    e.state = "NOTE";
                                    break
                                }
                                if (!i) continue;
                                e.cue = new(e.vttjs.VTTCue || e.window.VTTCue)(0, 0, "");
                                try {
                                    e.cue.align = "center"
                                } catch (t) {
                                    e.cue.align = "middle"
                                }
                                if (e.state = "CUE", -1 === i.indexOf("-->")) {
                                    e.cue.id = i;
                                    continue
                                }
                            case "CUE":
                                try {
                                    ! function(t, e, r) {
                                        var n = t;

                                        function i() {
                                            var e = a(t);
                                            if (null === e) throw new s(s.Errors.BadTimeStamp, "Malformed timestamp: " + n);
                                            return t = t.replace(/^[^\sa-zA-Z-]+/, ""), e
                                        }

                                        function l() {
                                            t = t.replace(/^\s+/, "")
                                        }
                                        if (l(), e.startTime = i(), l(), "-->" !== t.substr(0, 3)) throw new s(s.Errors.BadTimeStamp, "Malformed time stamp (time stamps must be separated by '-->'): " + n);
                                        t = t.substr(3), l(), e.endTime = i(), l(),
                                            function(t, e) {
                                                var n = new o;
                                                u(t, function(t, e) {
                                                    switch (t) {
                                                        case "region":
                                                            for (var i = r.length - 1; i >= 0; i--)
                                                                if (r[i].id === e) {
                                                                    n.set(t, r[i].region);
                                                                    break
                                                                }
                                                            break;
                                                        case "vertical":
                                                            n.alt(t, e, ["rl", "lr"]);
                                                            break;
                                                        case "line":
                                                            var s = e.split(","),
                                                                a = s[0];
                                                            n.integer(t, a), n.percent(t, a) && n.set("snapToLines", !1), n.alt(t, a, ["auto"]), 2 === s.length && n.alt("lineAlign", s[1], ["start", "center", "end"]);
                                                            break;
                                                        case "position":
                                                            s = e.split(","), n.percent(t, s[0]), 2 === s.length && n.alt("positionAlign", s[1], ["start", "center", "end"]);
                                                            break;
                                                        case "size":
                                                            n.percent(t, e);
                                                            break;
                                                        case "align":
                                                            n.alt(t, e, ["start", "center", "end", "left", "right"])
                                                    }
                                                }, /:/, /\s/), e.region = n.get("region", null), e.vertical = n.get("vertical", "");
                                                try {
                                                    e.line = n.get("line", "auto")
                                                } catch (t) {}
                                                e.lineAlign = n.get("lineAlign", "start"), e.snapToLines = n.get("snapToLines", !0), e.size = n.get("size", 100);
                                                try {
                                                    e.align = n.get("align", "center")
                                                } catch (t) {
                                                    e.align = n.get("align", "middle")
                                                }
                                                try {
                                                    e.position = n.get("position", "auto")
                                                } catch (t) {
                                                    e.position = n.get("position", {
                                                        start: 0,
                                                        left: 0,
                                                        center: 50,
                                                        middle: 50,
                                                        end: 100,
                                                        right: 100
                                                    }, e.align)
                                                }
                                                e.positionAlign = n.get("positionAlign", {
                                                    start: "start",
                                                    left: "start",
                                                    center: "center",
                                                    middle: "center",
                                                    end: "end",
                                                    right: "end"
                                                }, e.align)
                                            }(t, e)
                                    }(i, e.cue, e.regionList)
                                } catch (t) {
                                    e.reportOrThrowError(t), e.cue = null, e.state = "BADCUE";
                                    continue
                                }
                                e.state = "CUETEXT";
                                continue;
                            case "CUETEXT":
                                var h = -1 !== i.indexOf("-->");
                                if (!i || h && (c = !0)) {
                                    e.oncue && e.oncue(e.cue), e.cue = null, e.state = "ID";
                                    continue
                                }
                                e.cue.text && (e.cue.text += "\n"), e.cue.text += i.replace(/\u2028/g, "\n").replace(/u2029/g, "\n");
                                continue;
                            case "BADCUE":
                                i || (e.state = "ID");
                                continue
                        }
                    } catch (t) {
                        e.reportOrThrowError(t), "CUETEXT" === e.state && e.cue && e.oncue && e.oncue(e.cue), e.cue = null, e.state = "INITIAL" === e.state ? "BADWEBVTT" : "BADCUE"
                    }
                    return this
                },
                flush: function() {
                    try {
                        if (this.buffer += this.decoder.decode(), (this.cue || "HEADER" === this.state) && (this.buffer += "\n\n", this.parse()), "INITIAL" === this.state) throw new s(s.Errors.BadSignature)
                    } catch (t) {
                        this.reportOrThrowError(t)
                    }
                    return this.onflush && this.onflush(), this
                }
            }, t.exports = b
        },
        1929: function(t) {
            var e = {
                    "": 1,
                    lr: 1,
                    rl: 1
                },
                r = {
                    start: 1,
                    center: 1,
                    end: 1,
                    left: 1,
                    right: 1,
                    auto: 1,
                    "line-left": 1,
                    "line-right": 1
                };

            function n(t) {
                return "string" == typeof t && !!r[t.toLowerCase()] && t.toLowerCase()
            }

            function i(t, r, i) {
                this.hasBeenReset = !1;
                var s = "",
                    a = !1,
                    o = t,
                    u = r,
                    l = i,
                    c = null,
                    h = "",
                    f = !0,
                    p = "auto",
                    d = "start",
                    m = "auto",
                    g = "auto",
                    y = 100,
                    v = "center";
                Object.defineProperties(this, {
                    id: {
                        enumerable: !0,
                        get: function() {
                            return s
                        },
                        set: function(t) {
                            s = "" + t
                        }
                    },
                    pauseOnExit: {
                        enumerable: !0,
                        get: function() {
                            return a
                        },
                        set: function(t) {
                            a = !!t
                        }
                    },
                    startTime: {
                        enumerable: !0,
                        get: function() {
                            return o
                        },
                        set: function(t) {
                            if ("number" != typeof t) throw TypeError("Start time must be set to a number.");
                            o = t, this.hasBeenReset = !0
                        }
                    },
                    endTime: {
                        enumerable: !0,
                        get: function() {
                            return u
                        },
                        set: function(t) {
                            if ("number" != typeof t) throw TypeError("End time must be set to a number.");
                            u = t, this.hasBeenReset = !0
                        }
                    },
                    text: {
                        enumerable: !0,
                        get: function() {
                            return l
                        },
                        set: function(t) {
                            l = "" + t, this.hasBeenReset = !0
                        }
                    },
                    region: {
                        enumerable: !0,
                        get: function() {
                            return c
                        },
                        set: function(t) {
                            c = t, this.hasBeenReset = !0
                        }
                    },
                    vertical: {
                        enumerable: !0,
                        get: function() {
                            return h
                        },
                        set: function(t) {
                            var r = "string" == typeof t && !!e[t.toLowerCase()] && t.toLowerCase();
                            if (!1 === r) throw SyntaxError("Vertical: an invalid or illegal direction string was specified.");
                            h = r, this.hasBeenReset = !0
                        }
                    },
                    snapToLines: {
                        enumerable: !0,
                        get: function() {
                            return f
                        },
                        set: function(t) {
                            f = !!t, this.hasBeenReset = !0
                        }
                    },
                    line: {
                        enumerable: !0,
                        get: function() {
                            return p
                        },
                        set: function(t) {
                            if ("number" != typeof t && "auto" !== t) throw SyntaxError("Line: an invalid number or illegal string was specified.");
                            p = t, this.hasBeenReset = !0
                        }
                    },
                    lineAlign: {
                        enumerable: !0,
                        get: function() {
                            return d
                        },
                        set: function(t) {
                            var e = n(t);
                            e ? (d = e, this.hasBeenReset = !0) : console.warn("lineAlign: an invalid or illegal string was specified.")
                        }
                    },
                    position: {
                        enumerable: !0,
                        get: function() {
                            return m
                        },
                        set: function(t) {
                            if (t < 0 || t > 100) throw Error("Position must be between 0 and 100.");
                            m = t, this.hasBeenReset = !0
                        }
                    },
                    positionAlign: {
                        enumerable: !0,
                        get: function() {
                            return g
                        },
                        set: function(t) {
                            var e = n(t);
                            e ? (g = e, this.hasBeenReset = !0) : console.warn("positionAlign: an invalid or illegal string was specified.")
                        }
                    },
                    size: {
                        enumerable: !0,
                        get: function() {
                            return y
                        },
                        set: function(t) {
                            if (t < 0 || t > 100) throw Error("Size must be between 0 and 100.");
                            y = t, this.hasBeenReset = !0
                        }
                    },
                    align: {
                        enumerable: !0,
                        get: function() {
                            return v
                        },
                        set: function(t) {
                            var e = n(t);
                            if (!e) throw SyntaxError("align: an invalid or illegal alignment string was specified.");
                            v = e, this.hasBeenReset = !0
                        }
                    }
                }), this.displayState = void 0
            }
            i.prototype.getCueAsHTML = function() {
                return WebVTT.convertCueToDOMTree(window, this.text)
            }, t.exports = i
        },
        6155: function(t) {
            var e = {
                "": !0,
                up: !0
            };

            function r(t) {
                return "number" == typeof t && t >= 0 && t <= 100
            }
            t.exports = function() {
                var t = 100,
                    n = 3,
                    i = 0,
                    s = 100,
                    a = 0,
                    o = 100,
                    u = "";
                Object.defineProperties(this, {
                    width: {
                        enumerable: !0,
                        get: function() {
                            return t
                        },
                        set: function(e) {
                            if (!r(e)) throw Error("Width must be between 0 and 100.");
                            t = e
                        }
                    },
                    lines: {
                        enumerable: !0,
                        get: function() {
                            return n
                        },
                        set: function(t) {
                            if ("number" != typeof t) throw TypeError("Lines must be set to a number.");
                            n = t
                        }
                    },
                    regionAnchorY: {
                        enumerable: !0,
                        get: function() {
                            return s
                        },
                        set: function(t) {
                            if (!r(t)) throw Error("RegionAnchorX must be between 0 and 100.");
                            s = t
                        }
                    },
                    regionAnchorX: {
                        enumerable: !0,
                        get: function() {
                            return i
                        },
                        set: function(t) {
                            if (!r(t)) throw Error("RegionAnchorY must be between 0 and 100.");
                            i = t
                        }
                    },
                    viewportAnchorY: {
                        enumerable: !0,
                        get: function() {
                            return o
                        },
                        set: function(t) {
                            if (!r(t)) throw Error("ViewportAnchorY must be between 0 and 100.");
                            o = t
                        }
                    },
                    viewportAnchorX: {
                        enumerable: !0,
                        get: function() {
                            return a
                        },
                        set: function(t) {
                            if (!r(t)) throw Error("ViewportAnchorX must be between 0 and 100.");
                            a = t
                        }
                    },
                    scroll: {
                        enumerable: !0,
                        get: function() {
                            return u
                        },
                        set: function(t) {
                            var r = "string" == typeof t && !!e[t.toLowerCase()] && t.toLowerCase();
                            !1 === r ? console.warn("Scroll: an invalid or illegal string was specified.") : u = r
                        }
                    }
                })
            }
        },
        1592: function() {},
        5380: function(t) {
            function e() {
                return t.exports = e = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }, t.exports.__esModule = !0, t.exports.default = t.exports, e.apply(this, arguments)
            }
            t.exports = e, t.exports.__esModule = !0, t.exports.default = t.exports
        },
        2988: function(t, e, r) {
            "use strict";

            function n() {
                return (n = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                }).apply(this, arguments)
            }
            r.d(e, {
                Z: function() {
                    return n
                }
            })
        },
        5127: function(t, e, r) {
            "use strict";
            r.d(e, {
                M: function() {
                    return v
                }
            });
            var n = r(7437),
                i = r(2265),
                s = r(9033);

            function a() {
                let t = (0, i.useRef)(!1);
                return (0, s.L)(() => (t.current = !0, () => {
                    t.current = !1
                }), []), t
            }
            var o = r(6219),
                u = r(7797),
                l = r(458),
                c = r(9791);
            class h extends i.Component {
                getSnapshotBeforeUpdate(t) {
                    let e = this.props.childRef.current;
                    if (e && t.isPresent && !this.props.isPresent) {
                        let t = this.props.sizeRef.current;
                        t.height = e.offsetHeight || 0, t.width = e.offsetWidth || 0, t.top = e.offsetTop, t.left = e.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function f({
                children: t,
                isPresent: e
            }) {
                let r = (0, i.useId)(),
                    s = (0, i.useRef)(null),
                    a = (0, i.useRef)({
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0
                    }),
                    {
                        nonce: o
                    } = (0, i.useContext)(c._);
                return (0, i.useInsertionEffect)(() => {
                    let {
                        width: t,
                        height: n,
                        top: i,
                        left: u
                    } = a.current;
                    if (e || !s.current || !t || !n) return;
                    s.current.dataset.motionPopId = r;
                    let l = document.createElement("style");
                    return o && (l.nonce = o), document.head.appendChild(l), l.sheet && l.sheet.insertRule(`
          [data-motion-pop-id="${r}"] {
            position: absolute !important;
            width: ${t}px !important;
            height: ${n}px !important;
            top: ${i}px !important;
            left: ${u}px !important;
          }
        `), () => {
                        document.head.removeChild(l)
                    }
                }, [e]), (0, n.jsx)(h, {
                    isPresent: e,
                    childRef: s,
                    sizeRef: a,
                    children: i.cloneElement(t, {
                        ref: s
                    })
                })
            }
            let p = ({
                children: t,
                initial: e,
                isPresent: r,
                onExitComplete: s,
                custom: a,
                presenceAffectsLayout: o,
                mode: c
            }) => {
                let h = (0, l.h)(d),
                    p = (0, i.useId)(),
                    m = (0, i.useMemo)(() => ({
                        id: p,
                        initial: e,
                        isPresent: r,
                        custom: a,
                        onExitComplete: t => {
                            for (let e of (h.set(t, !0), h.values()))
                                if (!e) return;
                            s && s()
                        },
                        register: t => (h.set(t, !1), () => h.delete(t))
                    }), o ? [Math.random()] : [r]);
                return (0, i.useMemo)(() => {
                    h.forEach((t, e) => h.set(e, !1))
                }, [r]), i.useEffect(() => {
                    r || h.size || !s || s()
                }, [r]), "popLayout" === c && (t = (0, n.jsx)(f, {
                    isPresent: r,
                    children: t
                })), (0, n.jsx)(u.O.Provider, {
                    value: m,
                    children: t
                })
            };

            function d() {
                return new Map
            }
            var m = r(5050),
                g = r(9047);
            let y = t => t.key || "",
                v = ({
                    children: t,
                    custom: e,
                    initial: r = !0,
                    onExitComplete: u,
                    exitBeforeEnter: l,
                    presenceAffectsLayout: c = !0,
                    mode: h = "sync"
                }) => {
                    var f;
                    (0, g.k)(!l, "Replace exitBeforeEnter with mode='wait'");
                    let d = (0, i.useContext)(m.p).forceRender || function() {
                            let t = a(),
                                [e, r] = (0, i.useState)(0),
                                n = (0, i.useCallback)(() => {
                                    t.current && r(e + 1)
                                }, [e]);
                            return [(0, i.useCallback)(() => o.Wi.postRender(n), [n]), e]
                        }()[0],
                        v = a(),
                        b = function(t) {
                            let e = [];
                            return i.Children.forEach(t, t => {
                                (0, i.isValidElement)(t) && e.push(t)
                            }), e
                        }(t),
                        E = b,
                        w = (0, i.useRef)(new Map).current,
                        T = (0, i.useRef)(E),
                        D = (0, i.useRef)(new Map).current,
                        x = (0, i.useRef)(!0);
                    if ((0, s.L)(() => {
                            x.current = !1,
                                function(t, e) {
                                    t.forEach(t => {
                                        let r = y(t);
                                        e.set(r, t)
                                    })
                                }(b, D), T.current = E
                        }), f = () => {
                            x.current = !0, D.clear(), w.clear()
                        }, (0, i.useEffect)(() => () => f(), []), x.current) return (0, n.jsx)(n.Fragment, {
                        children: E.map(t => (0, n.jsx)(p, {
                            isPresent: !0,
                            initial: !!r && void 0,
                            presenceAffectsLayout: c,
                            mode: h,
                            children: t
                        }, y(t)))
                    });
                    E = [...E];
                    let S = T.current.map(y),
                        A = b.map(y),
                        R = S.length;
                    for (let t = 0; t < R; t++) {
                        let e = S[t]; - 1 !== A.indexOf(e) || w.has(e) || w.set(e, void 0)
                    }
                    return "wait" === h && w.size && (E = []), w.forEach((t, r) => {
                        if (-1 !== A.indexOf(r)) return;
                        let i = D.get(r);
                        if (!i) return;
                        let s = S.indexOf(r),
                            a = t;
                        a || (a = (0, n.jsx)(p, {
                            isPresent: !1,
                            onExitComplete: () => {
                                w.delete(r);
                                let t = Array.from(D.keys()).filter(t => !A.includes(t));
                                if (t.forEach(t => D.delete(t)), T.current = b.filter(e => {
                                        let n = y(e);
                                        return n === r || t.includes(n)
                                    }), !w.size) {
                                    if (!1 === v.current) return;
                                    d(), u && u()
                                }
                            },
                            custom: e,
                            presenceAffectsLayout: c,
                            mode: h,
                            children: i
                        }, y(i)), w.set(r, a)), E.splice(s, 0, a)
                    }), E = E.map(t => {
                        let e = t.key;
                        return w.has(e) ? t : (0, n.jsx)(p, {
                            isPresent: !0,
                            presenceAffectsLayout: c,
                            mode: h,
                            children: t
                        }, y(t))
                    }), (0, n.jsx)(n.Fragment, {
                        children: w.size ? E : E.map(t => (0, i.cloneElement)(t))
                    })
                }
        },
        5050: function(t, e, r) {
            "use strict";
            r.d(e, {
                p: function() {
                    return n
                }
            });
            let n = (0, r(2265).createContext)({})
        },
        9791: function(t, e, r) {
            "use strict";
            r.d(e, {
                _: function() {
                    return n
                }
            });
            let n = (0, r(2265).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        7797: function(t, e, r) {
            "use strict";
            r.d(e, {
                O: function() {
                    return n
                }
            });
            let n = (0, r(2265).createContext)(null)
        },
        2981: function(t, e, r) {
            "use strict";
            r.d(e, {
                Z: function() {
                    return a
                }
            });
            var n = r(565);
            class i {
                constructor() {
                    this.order = [], this.scheduled = new Set
                }
                add(t) {
                    if (!this.scheduled.has(t)) return this.scheduled.add(t), this.order.push(t), !0
                }
                remove(t) {
                    let e = this.order.indexOf(t); - 1 !== e && (this.order.splice(e, 1), this.scheduled.delete(t))
                }
                clear() {
                    this.order.length = 0, this.scheduled.clear()
                }
            }
            let s = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function a(t, e) {
                let r = !1,
                    a = !0,
                    o = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    u = s.reduce((t, e) => (t[e] = function(t) {
                        let e = new i,
                            r = new i,
                            n = 0,
                            s = !1,
                            a = !1,
                            o = new WeakSet,
                            u = {
                                schedule: (t, i = !1, a = !1) => {
                                    let u = a && s,
                                        l = u ? e : r;
                                    return i && o.add(t), l.add(t) && u && s && (n = e.order.length), t
                                },
                                cancel: t => {
                                    r.remove(t), o.delete(t)
                                },
                                process: i => {
                                    if (s) {
                                        a = !0;
                                        return
                                    }
                                    if (s = !0, [e, r] = [r, e], r.clear(), n = e.order.length)
                                        for (let r = 0; r < n; r++) {
                                            let n = e.order[r];
                                            o.has(n) && (u.schedule(n), t()), n(i)
                                        }
                                    s = !1, a && (a = !1, u.process(i))
                                }
                            };
                        return u
                    }(() => r = !0), t), {}),
                    l = t => {
                        u[t].process(o)
                    },
                    c = () => {
                        let i = n.c.useManualTiming ? o.timestamp : performance.now();
                        r = !1, o.delta = a ? 1e3 / 60 : Math.max(Math.min(i - o.timestamp, 40), 1), o.timestamp = i, o.isProcessing = !0, s.forEach(l), o.isProcessing = !1, r && e && (a = !1, t(c))
                    },
                    h = () => {
                        r = !0, a = !0, o.isProcessing || t(c)
                    };
                return {
                    schedule: s.reduce((t, e) => {
                        let n = u[e];
                        return t[e] = (t, e = !1, i = !1) => (r || h(), n.schedule(t, e, i)), t
                    }, {}),
                    cancel: t => s.forEach(e => u[e].cancel(t)),
                    state: o,
                    steps: u
                }
            }
        },
        6219: function(t, e, r) {
            "use strict";
            r.d(e, {
                Pn: function() {
                    return s
                },
                S6: function() {
                    return o
                },
                Wi: function() {
                    return i
                },
                frameData: function() {
                    return a
                }
            });
            var n = r(9276);
            let {
                schedule: i,
                cancel: s,
                state: a,
                steps: o
            } = (0, r(2981).Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.Z, !0)
        },
        4599: function(t, e, r) {
            "use strict";
            let n;
            r.d(e, {
                E: function() {
                    return st
                }
            });
            var i, s = r(7437),
                a = r(2265),
                o = r(9791);
            let u = (0, a.createContext)({});
            var l = r(7797),
                c = r(9033);
            let h = (0, a.createContext)({
                    strict: !1
                }),
                f = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
                p = "data-" + f("framerAppearId"),
                {
                    schedule: d,
                    cancel: m
                } = (0, r(2981).Z)(queueMicrotask, !1);

            function g(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }

            function y(t) {
                return "string" == typeof t || Array.isArray(t)
            }

            function v(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
            let b = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                E = ["initial", ...b];

            function w(t) {
                return v(t.animate) || E.some(e => y(t[e]))
            }

            function T(t) {
                return !!(w(t) || t.variants)
            }

            function D(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            let x = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                S = {};
            for (let t in x) S[t] = {
                isEnabled: e => x[t].some(t => !!e[t])
            };
            var A = r(7282),
                R = r(5050);
            let N = (0, a.createContext)({}),
                P = Symbol.for("motionComponentSymbol"),
                C = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function O(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (C.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }
            let I = {},
                L = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                M = new Set(L);

            function k(t, {
                layout: e,
                layoutId: r
            }) {
                return M.has(t) || t.startsWith("origin") || (e || void 0 !== r) && (!!I[t] || "opacity" === t)
            }
            let U = t => !!(t && t.getVelocity),
                B = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                V = L.length,
                j = t => e => "string" == typeof e && e.startsWith(t),
                _ = j("--"),
                q = j("var(--"),
                F = t => !!q(t) && X.test(t.split("/*")[0].trim()),
                X = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
                G = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
                H = (t, e, r) => r > e ? e : r < t ? t : r,
                $ = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                z = { ...$,
                    transform: t => H(0, 1, t)
                },
                W = { ...$,
                    default: 1
                },
                K = t => Math.round(1e5 * t) / 1e5,
                Y = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
                Z = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
                J = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;

            function Q(t) {
                return "string" == typeof t
            }
            let tt = t => ({
                    test: e => Q(e) && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                te = tt("deg"),
                tr = tt("%"),
                tn = tt("px"),
                ti = tt("vh"),
                ts = tt("vw"),
                ta = { ...tr,
                    parse: t => tr.parse(t) / 100,
                    transform: t => tr.transform(100 * t)
                },
                to = { ...$,
                    transform: Math.round
                },
                tu = {
                    borderWidth: tn,
                    borderTopWidth: tn,
                    borderRightWidth: tn,
                    borderBottomWidth: tn,
                    borderLeftWidth: tn,
                    borderRadius: tn,
                    radius: tn,
                    borderTopLeftRadius: tn,
                    borderTopRightRadius: tn,
                    borderBottomRightRadius: tn,
                    borderBottomLeftRadius: tn,
                    width: tn,
                    maxWidth: tn,
                    height: tn,
                    maxHeight: tn,
                    size: tn,
                    top: tn,
                    right: tn,
                    bottom: tn,
                    left: tn,
                    padding: tn,
                    paddingTop: tn,
                    paddingRight: tn,
                    paddingBottom: tn,
                    paddingLeft: tn,
                    margin: tn,
                    marginTop: tn,
                    marginRight: tn,
                    marginBottom: tn,
                    marginLeft: tn,
                    rotate: te,
                    rotateX: te,
                    rotateY: te,
                    rotateZ: te,
                    scale: W,
                    scaleX: W,
                    scaleY: W,
                    scaleZ: W,
                    skew: te,
                    skewX: te,
                    skewY: te,
                    distance: tn,
                    translateX: tn,
                    translateY: tn,
                    translateZ: tn,
                    x: tn,
                    y: tn,
                    z: tn,
                    perspective: tn,
                    transformPerspective: tn,
                    opacity: z,
                    originX: ta,
                    originY: ta,
                    originZ: tn,
                    zIndex: to,
                    backgroundPositionX: tn,
                    backgroundPositionY: tn,
                    fillOpacity: z,
                    strokeOpacity: z,
                    numOctaves: to
                };

            function tl(t, e, r, n) {
                let {
                    style: i,
                    vars: s,
                    transform: a,
                    transformOrigin: o
                } = t, u = !1, l = !1, c = !0;
                for (let t in e) {
                    let r = e[t];
                    if (_(t)) {
                        s[t] = r;
                        continue
                    }
                    let n = tu[t],
                        h = G(r, n);
                    if (M.has(t)) {
                        if (u = !0, a[t] = h, !c) continue;
                        r !== (n.default || 0) && (c = !1)
                    } else t.startsWith("origin") ? (l = !0, o[t] = h) : i[t] = h
                }
                if (!e.transform && (u || n ? i.transform = function(t, {
                        enableHardwareAcceleration: e = !0,
                        allowTransformNone: r = !0
                    }, n, i) {
                        let s = "";
                        for (let e = 0; e < V; e++) {
                            let r = L[e];
                            if (void 0 !== t[r]) {
                                let e = B[r] || r;
                                s += `${e}(${t[r]}) `
                            }
                        }
                        return e && !t.z && (s += "translateZ(0)"), s = s.trim(), i ? s = i(t, n ? "" : s) : r && n && (s = "none"), s
                    }(t.transform, r, c, n) : i.transform && (i.transform = "none")), l) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: r = 0
                    } = o;
                    i.transformOrigin = `${t} ${e} ${r}`
                }
            }
            let tc = () => ({
                style: {},
                transform: {},
                transformOrigin: {},
                vars: {}
            });

            function th(t, e, r) {
                for (let n in e) U(e[n]) || k(n, r) || (t[n] = e[n])
            }
            let tf = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function tp(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || tf.has(t)
            }
            let td = t => !tp(t);
            try {
                (i = require("@emotion/is-prop-valid").default) && (td = t => t.startsWith("on") ? !tp(t) : i(t))
            } catch (t) {}

            function tm(t, e, r) {
                return "string" == typeof t ? t : tn.transform(e + r * t)
            }
            let tg = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                ty = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function tv(t, {
                attrX: e,
                attrY: r,
                attrScale: n,
                originX: i,
                originY: s,
                pathLength: a,
                pathSpacing: o = 1,
                pathOffset: u = 0,
                ...l
            }, c, h, f) {
                if (tl(t, l, c, f), h) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: p,
                    style: d,
                    dimensions: m
                } = t;
                p.transform && (m && (d.transform = p.transform), delete p.transform), m && (void 0 !== i || void 0 !== s || d.transform) && (d.transformOrigin = function(t, e, r) {
                    let n = tm(e, t.x, t.width),
                        i = tm(r, t.y, t.height);
                    return `${n} ${i}`
                }(m, void 0 !== i ? i : .5, void 0 !== s ? s : .5)), void 0 !== e && (p.x = e), void 0 !== r && (p.y = r), void 0 !== n && (p.scale = n), void 0 !== a && function(t, e, r = 1, n = 0, i = !0) {
                    t.pathLength = 1;
                    let s = i ? tg : ty;
                    t[s.offset] = tn.transform(-n);
                    let a = tn.transform(e),
                        o = tn.transform(r);
                    t[s.array] = `${a} ${o}`
                }(p, a, o, u, !1)
            }
            let tb = () => ({ ...tc(),
                    attrs: {}
                }),
                tE = t => "string" == typeof t && "svg" === t.toLowerCase();

            function tw(t, {
                style: e,
                vars: r
            }, n, i) {
                for (let s in Object.assign(t.style, e, i && i.getProjectionStyles(n)), r) t.style.setProperty(s, r[s])
            }
            let tT = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

            function tD(t, e, r, n) {
                for (let r in tw(t, e, void 0, n), e.attrs) t.setAttribute(tT.has(r) ? r : f(r), e.attrs[r])
            }

            function tx(t, e, r) {
                var n;
                let {
                    style: i
                } = t, s = {};
                for (let a in i)(U(i[a]) || e.style && U(e.style[a]) || k(a, t) || (null === (n = null == r ? void 0 : r.getValue(a)) || void 0 === n ? void 0 : n.liveStyle) !== void 0) && (s[a] = i[a]);
                return s
            }

            function tS(t, e, r) {
                let n = tx(t, e, r);
                for (let r in t)(U(t[r]) || U(e[r])) && (n[-1 !== L.indexOf(r) ? "attr" + r.charAt(0).toUpperCase() + r.substring(1) : r] = t[r]);
                return n
            }

            function tA(t) {
                let e = [{}, {}];
                return null == t || t.values.forEach((t, r) => {
                    e[0][r] = t.get(), e[1][r] = t.getVelocity()
                }), e
            }

            function tR(t, e, r, n) {
                if ("function" == typeof e) {
                    let [i, s] = tA(n);
                    e = e(void 0 !== r ? r : t.custom, i, s)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    let [i, s] = tA(n);
                    e = e(void 0 !== r ? r : t.custom, i, s)
                }
                return e
            }
            var tN = r(458);
            let tP = t => Array.isArray(t),
                tC = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                tO = t => tP(t) ? t[t.length - 1] || 0 : t;

            function tI(t) {
                let e = U(t) ? t.get() : t;
                return tC(e) ? e.toValue() : e
            }
            let tL = t => (e, r) => {
                let n = (0, a.useContext)(u),
                    i = (0, a.useContext)(l.O),
                    s = () => (function({
                        scrapeMotionValuesFromProps: t,
                        createRenderState: e,
                        onMount: r
                    }, n, i, s) {
                        let a = {
                            latestValues: function(t, e, r, n) {
                                let i = {},
                                    s = n(t, {});
                                for (let t in s) i[t] = tI(s[t]);
                                let {
                                    initial: a,
                                    animate: o
                                } = t, u = w(t), l = T(t);
                                e && l && !u && !1 !== t.inherit && (void 0 === a && (a = e.initial), void 0 === o && (o = e.animate));
                                let c = !!r && !1 === r.initial,
                                    h = (c = c || !1 === a) ? o : a;
                                return h && "boolean" != typeof h && !v(h) && (Array.isArray(h) ? h : [h]).forEach(e => {
                                    let r = tR(t, e);
                                    if (!r) return;
                                    let {
                                        transitionEnd: n,
                                        transition: s,
                                        ...a
                                    } = r;
                                    for (let t in a) {
                                        let e = a[t];
                                        if (Array.isArray(e)) {
                                            let t = c ? e.length - 1 : 0;
                                            e = e[t]
                                        }
                                        null !== e && (i[t] = e)
                                    }
                                    for (let t in n) i[t] = n[t]
                                }), i
                            }(n, i, s, t),
                            renderState: e()
                        };
                        return r && (a.mount = t => r(n, t, a)), a
                    })(t, e, n, i);
                return r ? s() : (0, tN.h)(s)
            };
            var tM = r(6219);
            let tk = {
                    useVisualState: tL({
                        scrapeMotionValuesFromProps: tS,
                        createRenderState: tb,
                        onMount: (t, e, {
                            renderState: r,
                            latestValues: n
                        }) => {
                            tM.Wi.read(() => {
                                try {
                                    r.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    r.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), tM.Wi.render(() => {
                                tv(r, n, {
                                    enableHardwareAcceleration: !1
                                }, tE(e.tagName), t.transformTemplate), tD(e, r)
                            })
                        }
                    })
                },
                tU = {
                    useVisualState: tL({
                        scrapeMotionValuesFromProps: tx,
                        createRenderState: tc
                    })
                };

            function tB(t, e, r, n = {
                passive: !0
            }) {
                return t.addEventListener(e, r, n), () => t.removeEventListener(e, r)
            }
            let tV = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

            function tj(t, e = "page") {
                return {
                    point: {
                        x: t[`${e}X`],
                        y: t[`${e}Y`]
                    }
                }
            }
            let t_ = t => e => tV(e) && t(e, tj(e));

            function tq(t, e, r, n) {
                return tB(t, e, t_(r), n)
            }
            let tF = (t, e) => r => e(t(r)),
                tX = (...t) => t.reduce(tF);

            function tG(t) {
                let e = null;
                return () => null === e && (e = t, () => {
                    e = null
                })
            }
            let tH = tG("dragHorizontal"),
                t$ = tG("dragVertical");

            function tz(t) {
                let e = !1;
                if ("y" === t) e = t$();
                else if ("x" === t) e = tH();
                else {
                    let t = tH(),
                        r = t$();
                    t && r ? e = () => {
                        t(), r()
                    } : (t && t(), r && r())
                }
                return e
            }

            function tW() {
                let t = tz(!0);
                return !t || (t(), !1)
            }
            class tK {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }

            function tY(t, e) {
                let r = e ? "onHoverStart" : "onHoverEnd";
                return tq(t.current, e ? "pointerenter" : "pointerleave", (n, i) => {
                    if ("touch" === n.pointerType || tW()) return;
                    let s = t.getProps();
                    t.animationState && s.whileHover && t.animationState.setActive("whileHover", e);
                    let a = s[r];
                    a && tM.Wi.postRender(() => a(n, i))
                }, {
                    passive: !t.getProps()[r]
                })
            }
            class tZ extends tK {
                mount() {
                    this.unmount = tX(tY(this.node, !0), tY(this.node, !1))
                }
                unmount() {}
            }
            class tJ extends tK {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = tX(tB(this.node.current, "focus", () => this.onFocus()), tB(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            let tQ = (t, e) => !!e && (t === e || tQ(t, e.parentElement));
            var t0 = r(9276);

            function t1(t, e) {
                if (!e) return;
                let r = new PointerEvent("pointer" + t);
                e(r, tj(r))
            }
            class t2 extends tK {
                constructor() {
                    super(...arguments), this.removeStartListeners = t0.Z, this.removeEndListeners = t0.Z, this.removeAccessibleListeners = t0.Z, this.startPointerPress = (t, e) => {
                        if (this.isPressing) return;
                        this.removeEndListeners();
                        let r = this.node.getProps(),
                            n = tq(window, "pointerup", (t, e) => {
                                if (!this.checkPressEnd()) return;
                                let {
                                    onTap: r,
                                    onTapCancel: n,
                                    globalTapTarget: i
                                } = this.node.getProps(), s = i || tQ(this.node.current, t.target) ? r : n;
                                s && tM.Wi.update(() => s(t, e))
                            }, {
                                passive: !(r.onTap || r.onPointerUp)
                            }),
                            i = tq(window, "pointercancel", (t, e) => this.cancelPress(t, e), {
                                passive: !(r.onTapCancel || r.onPointerCancel)
                            });
                        this.removeEndListeners = tX(n, i), this.startPress(t, e)
                    }, this.startAccessiblePress = () => {
                        let t = tB(this.node.current, "keydown", t => {
                                "Enter" !== t.key || this.isPressing || (this.removeEndListeners(), this.removeEndListeners = tB(this.node.current, "keyup", t => {
                                    "Enter" === t.key && this.checkPressEnd() && t1("up", (t, e) => {
                                        let {
                                            onTap: r
                                        } = this.node.getProps();
                                        r && tM.Wi.postRender(() => r(t, e))
                                    })
                                }), t1("down", (t, e) => {
                                    this.startPress(t, e)
                                }))
                            }),
                            e = tB(this.node.current, "blur", () => {
                                this.isPressing && t1("cancel", (t, e) => this.cancelPress(t, e))
                            });
                        this.removeAccessibleListeners = tX(t, e)
                    }
                }
                startPress(t, e) {
                    this.isPressing = !0;
                    let {
                        onTapStart: r,
                        whileTap: n
                    } = this.node.getProps();
                    n && this.node.animationState && this.node.animationState.setActive("whileTap", !0), r && tM.Wi.postRender(() => r(t, e))
                }
                checkPressEnd() {
                    return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !tW()
                }
                cancelPress(t, e) {
                    if (!this.checkPressEnd()) return;
                    let {
                        onTapCancel: r
                    } = this.node.getProps();
                    r && tM.Wi.postRender(() => r(t, e))
                }
                mount() {
                    let t = this.node.getProps(),
                        e = tq(t.globalTapTarget ? window : this.node.current, "pointerdown", this.startPointerPress, {
                            passive: !(t.onTapStart || t.onPointerStart)
                        }),
                        r = tB(this.node.current, "focus", this.startAccessiblePress);
                    this.removeStartListeners = tX(e, r)
                }
                unmount() {
                    this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners()
                }
            }
            let t5 = new WeakMap,
                t3 = new WeakMap,
                t6 = t => {
                    let e = t5.get(t.target);
                    e && e(t)
                },
                t8 = t => {
                    t.forEach(t6)
                },
                t4 = {
                    some: 0,
                    all: 1
                };
            class t9 extends tK {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: r,
                        amount: n = "some",
                        once: i
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: r,
                        threshold: "number" == typeof n ? n : t4[n]
                    };
                    return function(t, e, r) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let r = t || document;
                            t3.has(r) || t3.set(r, {});
                            let n = t3.get(r),
                                i = JSON.stringify(e);
                            return n[i] || (n[i] = new IntersectionObserver(t8, {
                                root: t,
                                ...e
                            })), n[i]
                        }(e);
                        return t5.set(t, r), n.observe(t), () => {
                            t5.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, i && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: r,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? r : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return r => t[r] !== e[r]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }

            function t7(t, e) {
                if (!Array.isArray(e)) return !1;
                let r = e.length;
                if (r !== t.length) return !1;
                for (let n = 0; n < r; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }

            function et(t, e, r) {
                let n = t.getProps();
                return tR(n, e, void 0 !== r ? r : n.custom, t)
            }
            let ee = t => 1e3 * t,
                er = t => t / 1e3,
                en = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                ei = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                es = {
                    type: "keyframes",
                    duration: .8
                },
                ea = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                eo = (t, {
                    keyframes: e
                }) => e.length > 2 ? es : M.has(t) ? t.startsWith("scale") ? ei(e[1]) : en : ea;

            function eu(t, e) {
                return t[e] || t.default || t
            }
            var el = r(565);
            let ec = {
                    current: !1
                },
                eh = t => null !== t;

            function ef(t, {
                repeat: e,
                repeatType: r = "loop"
            }, n) {
                let i = t.filter(eh),
                    s = e && "loop" !== r && e % 2 == 1 ? 0 : i.length - 1;
                return s && void 0 !== n ? n : i[s]
            }

            function ep() {
                n = void 0
            }
            let ed = {
                    now: () => (void 0 === n && ed.set(tM.frameData.isProcessing || el.c.useManualTiming ? tM.frameData.timestamp : performance.now()), n),
                    set: t => {
                        n = t, queueMicrotask(ep)
                    }
                },
                em = t => /^0[^.\s]+$/u.test(t);
            var eg = r(9047);
            let ey = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t),
                ev = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u,
                eb = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                eE = t => t === $ || t === tn,
                ew = (t, e) => parseFloat(t.split(", ")[e]),
                eT = (t, e) => (r, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let i = n.match(/^matrix3d\((.+)\)$/u);
                    if (i) return ew(i[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? ew(e[1], t) : 0
                    }
                },
                eD = new Set(["x", "y", "z"]),
                ex = L.filter(t => !eD.has(t)),
                eS = {
                    width: ({
                        x: t
                    }, {
                        paddingLeft: e = "0",
                        paddingRight: r = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(r),
                    height: ({
                        y: t
                    }, {
                        paddingTop: e = "0",
                        paddingBottom: r = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(r),
                    top: (t, {
                        top: e
                    }) => parseFloat(e),
                    left: (t, {
                        left: e
                    }) => parseFloat(e),
                    bottom: ({
                        y: t
                    }, {
                        top: e
                    }) => parseFloat(e) + (t.max - t.min),
                    right: ({
                        x: t
                    }, {
                        left: e
                    }) => parseFloat(e) + (t.max - t.min),
                    x: eT(4, 13),
                    y: eT(5, 14)
                };
            eS.translateX = eS.x, eS.translateY = eS.y;
            let eA = t => e => e.test(t),
                eR = [$, tn, tr, te, ts, ti, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                eN = t => eR.find(eA(t)),
                eP = new Set,
                eC = !1,
                eO = !1;

            function eI() {
                if (eO) {
                    let t = Array.from(eP).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        r = new Map;
                    e.forEach(t => {
                        let e = function(t) {
                            let e = [];
                            return ex.forEach(r => {
                                let n = t.getValue(r);
                                void 0 !== n && (e.push([r, n.get()]), n.set(r.startsWith("scale") ? 1 : 0))
                            }), e
                        }(t);
                        e.length && (r.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = r.get(t);
                        e && e.forEach(([e, r]) => {
                            var n;
                            null === (n = t.getValue(e)) || void 0 === n || n.set(r)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                eO = !1, eC = !1, eP.forEach(t => t.complete()), eP.clear()
            }

            function eL() {
                eP.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (eO = !0)
                })
            }
            class eM {
                constructor(t, e, r, n, i, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = r, this.motionValue = n, this.element = i, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (eP.add(this), eC || (eC = !0, tM.Wi.read(eL), tM.Wi.resolveKeyframes(eI))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: r,
                        motionValue: n
                    } = this;
                    for (let i = 0; i < t.length; i++)
                        if (null === t[i]) {
                            if (0 === i) {
                                let i = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== i) t[0] = i;
                                else if (r && e) {
                                    let n = r.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === i && n.set(t[0])
                            } else t[i] = t[i - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), eP.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, eP.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
            let ek = (t, e) => r => !!(Q(r) && J.test(r) && r.startsWith(t) || e && Object.prototype.hasOwnProperty.call(r, e)),
                eU = (t, e, r) => n => {
                    if (!Q(n)) return n;
                    let [i, s, a, o] = n.match(Y);
                    return {
                        [t]: parseFloat(i),
                        [e]: parseFloat(s),
                        [r]: parseFloat(a),
                        alpha: void 0 !== o ? parseFloat(o) : 1
                    }
                },
                eB = t => H(0, 255, t),
                eV = { ...$,
                    transform: t => Math.round(eB(t))
                },
                ej = {
                    test: ek("rgb", "red"),
                    parse: eU("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: r,
                        alpha: n = 1
                    }) => "rgba(" + eV.transform(t) + ", " + eV.transform(e) + ", " + eV.transform(r) + ", " + K(z.transform(n)) + ")"
                },
                e_ = {
                    test: ek("#"),
                    parse: function(t) {
                        let e = "",
                            r = "",
                            n = "",
                            i = "";
                        return t.length > 5 ? (e = t.substring(1, 3), r = t.substring(3, 5), n = t.substring(5, 7), i = t.substring(7, 9)) : (e = t.substring(1, 2), r = t.substring(2, 3), n = t.substring(3, 4), i = t.substring(4, 5), e += e, r += r, n += n, i += i), {
                            red: parseInt(e, 16),
                            green: parseInt(r, 16),
                            blue: parseInt(n, 16),
                            alpha: i ? parseInt(i, 16) / 255 : 1
                        }
                    },
                    transform: ej.transform
                },
                eq = {
                    test: ek("hsl", "hue"),
                    parse: eU("hue", "saturation", "lightness"),
                    transform: ({
                        hue: t,
                        saturation: e,
                        lightness: r,
                        alpha: n = 1
                    }) => "hsla(" + Math.round(t) + ", " + tr.transform(K(e)) + ", " + tr.transform(K(r)) + ", " + K(z.transform(n)) + ")"
                },
                eF = {
                    test: t => ej.test(t) || e_.test(t) || eq.test(t),
                    parse: t => ej.test(t) ? ej.parse(t) : eq.test(t) ? eq.parse(t) : e_.parse(t),
                    transform: t => Q(t) ? t : t.hasOwnProperty("red") ? ej.transform(t) : eq.transform(t)
                },
                eX = "number",
                eG = "color",
                eH = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function e$(t) {
                let e = t.toString(),
                    r = [],
                    n = {
                        color: [],
                        number: [],
                        var: []
                    },
                    i = [],
                    s = 0,
                    a = e.replace(eH, t => (eF.test(t) ? (n.color.push(s), i.push(eG), r.push(eF.parse(t))) : t.startsWith("var(") ? (n.var.push(s), i.push("var"), r.push(t)) : (n.number.push(s), i.push(eX), r.push(parseFloat(t))), ++s, "${}")).split("${}");
                return {
                    values: r,
                    split: a,
                    indexes: n,
                    types: i
                }
            }

            function ez(t) {
                return e$(t).values
            }

            function eW(t) {
                let {
                    split: e,
                    types: r
                } = e$(t), n = e.length;
                return t => {
                    let i = "";
                    for (let s = 0; s < n; s++)
                        if (i += e[s], void 0 !== t[s]) {
                            let e = r[s];
                            e === eX ? i += K(t[s]) : e === eG ? i += eF.transform(t[s]) : i += t[s]
                        }
                    return i
                }
            }
            let eK = t => "number" == typeof t ? 0 : t,
                eY = {
                    test: function(t) {
                        var e, r;
                        return isNaN(t) && Q(t) && ((null === (e = t.match(Y)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (r = t.match(Z)) || void 0 === r ? void 0 : r.length) || 0) > 0
                    },
                    parse: ez,
                    createTransformer: eW,
                    getAnimatableNone: function(t) {
                        let e = ez(t);
                        return eW(t)(e.map(eK))
                    }
                },
                eZ = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function eJ(t) {
                let [e, r] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = r.match(Y) || [];
                if (!n) return t;
                let i = r.replace(n, ""),
                    s = eZ.has(e) ? 1 : 0;
                return n !== r && (s *= 100), e + "(" + s + i + ")"
            }
            let eQ = /\b([a-z-]*)\(.*?\)/gu,
                e0 = { ...eY,
                    getAnimatableNone: t => {
                        let e = t.match(eQ);
                        return e ? e.map(eJ).join(" ") : t
                    }
                },
                e1 = { ...tu,
                    color: eF,
                    backgroundColor: eF,
                    outlineColor: eF,
                    fill: eF,
                    stroke: eF,
                    borderColor: eF,
                    borderTopColor: eF,
                    borderRightColor: eF,
                    borderBottomColor: eF,
                    borderLeftColor: eF,
                    filter: e0,
                    WebkitFilter: e0
                },
                e2 = t => e1[t];

            function e5(t, e) {
                let r = e2(t);
                return r !== e0 && (r = eY), r.getAnimatableNone ? r.getAnimatableNone(e) : void 0
            }
            let e3 = new Set(["auto", "none", "0"]);
            class e6 extends eM {
                constructor(t, e, r, n) {
                    super(t, e, r, n, null == n ? void 0 : n.owner, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: r
                    } = this;
                    if (!e.current) return;
                    super.readKeyframes();
                    for (let r = 0; r < t.length; r++) {
                        let n = t[r];
                        if ("string" == typeof n && F(n = n.trim())) {
                            let i = function t(e, r, n = 1) {
                                (0, eg.k)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [i, s] = function(t) {
                                    let e = ev.exec(t);
                                    if (!e) return [, ];
                                    let [, r, n, i] = e;
                                    return [`--${null!=r?r:n}`, i]
                                }(e);
                                if (!i) return;
                                let a = window.getComputedStyle(r).getPropertyValue(i);
                                if (a) {
                                    let t = a.trim();
                                    return ey(t) ? parseFloat(t) : t
                                }
                                return F(s) ? t(s, r, n + 1) : s
                            }(n, e.current);
                            void 0 !== i && (t[r] = i), r === t.length - 1 && (this.finalKeyframe = n)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !eb.has(r) || 2 !== t.length) return;
                    let [n, i] = t, s = eN(n), a = eN(i);
                    if (s !== a) {
                        if (eE(s) && eE(a))
                            for (let e = 0; e < t.length; e++) {
                                let r = t[e];
                                "string" == typeof r && (t[e] = parseFloat(r))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, r = [];
                    for (let e = 0; e < t.length; e++) {
                        var n;
                        ("number" == typeof(n = t[e]) ? 0 === n : null === n || "none" === n || "0" === n || em(n)) && r.push(e)
                    }
                    r.length && function(t, e, r) {
                        let n, i = 0;
                        for (; i < t.length && !n;) {
                            let e = t[i];
                            "string" == typeof e && !e3.has(e) && e$(e).values.length && (n = t[i]), i++
                        }
                        if (n && r)
                            for (let i of e) t[i] = e5(r, n)
                    }(t, r, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: r
                    } = this;
                    if (!t.current) return;
                    "height" === r && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = eS[r](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(r, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: r,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e.current) return;
                    let i = e.getValue(r);
                    i && i.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        a = n[s];
                    n[s] = eS[r](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== a && void 0 === this.finalKeyframe && (this.finalKeyframe = a), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, r]) => {
                        e.getValue(t).set(r)
                    }), this.resolveNoneKeyframes()
                }
            }

            function e8(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
            let e4 = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (eY.test(t) || "0" === t) && !t.startsWith("url("));
            class e9 {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: r = "keyframes",
                    repeat: n = 0,
                    repeatDelay: i = 0,
                    repeatType: s = "loop",
                    ...a
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.options = {
                        autoplay: t,
                        delay: e,
                        type: r,
                        repeat: n,
                        repeatDelay: i,
                        repeatType: s,
                        ...a
                    }, this.updateFinishedPromise()
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (eL(), eI()), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.hasAttemptedResolve = !0;
                    let {
                        name: r,
                        type: n,
                        velocity: i,
                        delay: s,
                        onComplete: a,
                        onUpdate: o,
                        isGenerator: u
                    } = this.options;
                    if (!u && ! function(t, e, r, n) {
                            let i = t[0];
                            if (null === i) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            let s = t[t.length - 1],
                                a = e4(i, e),
                                o = e4(s, e);
                            return (0, eg.K)(a === o, `You are trying to animate ${e} from "${i}" to "${s}". ${i} is not an animatable value - to enable this animation set ${i} to a value animatable to ${s} via the \`style\` property.`), !!a && !!o && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let r = 0; r < t.length; r++)
                                    if (t[r] !== e) return !0
                            }(t) || "spring" === r && n)
                        }(t, r, n, i)) {
                        if (ec.current || !s) {
                            null == o || o(ef(t, this.options, e)), null == a || a(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let l = this.initPlayback(t, e);
                    !1 !== l && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...l
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }

            function e7(t, e, r) {
                var n, i;
                let s = Math.max(e - 5, 0);
                return n = r - t(s), (i = e - s) ? 1e3 / i * n : 0
            }

            function rt(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            let re = ["duration", "bounce"],
                rr = ["stiffness", "damping", "mass"];

            function rn(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function ri({
                keyframes: t,
                restDelta: e,
                restSpeed: r,
                ...n
            }) {
                let i;
                let s = t[0],
                    a = t[t.length - 1],
                    o = {
                        done: !1,
                        value: s
                    },
                    {
                        stiffness: u,
                        damping: l,
                        mass: c,
                        duration: h,
                        velocity: f,
                        isResolvedFromDuration: p
                    } = function(t) {
                        let e = {
                            velocity: 0,
                            stiffness: 100,
                            damping: 10,
                            mass: 1,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!rn(t, rr) && rn(t, re)) {
                            let r = function({
                                duration: t = 800,
                                bounce: e = .25,
                                velocity: r = 0,
                                mass: n = 1
                            }) {
                                let i, s;
                                (0, eg.K)(t <= ee(10), "Spring duration must be 10 seconds or less");
                                let a = 1 - e;
                                a = H(.05, 1, a), t = H(.01, 10, er(t)), a < 1 ? (i = e => {
                                    let n = e * a,
                                        i = n * t;
                                    return .001 - (n - r) / rt(e, a) * Math.exp(-i)
                                }, s = e => {
                                    let n = e * a * t,
                                        s = Math.pow(a, 2) * Math.pow(e, 2) * t,
                                        o = rt(Math.pow(e, 2), a);
                                    return (n * r + r - s) * Math.exp(-n) * (-i(e) + .001 > 0 ? -1 : 1) / o
                                }) : (i = e => -.001 + Math.exp(-e * t) * ((e - r) * t + 1), s = e => t * t * (r - e) * Math.exp(-e * t));
                                let o = function(t, e, r) {
                                    let n = r;
                                    for (let r = 1; r < 12; r++) n -= t(n) / e(n);
                                    return n
                                }(i, s, 5 / t);
                                if (t = ee(t), isNaN(o)) return {
                                    stiffness: 100,
                                    damping: 10,
                                    duration: t
                                }; {
                                    let e = Math.pow(o, 2) * n;
                                    return {
                                        stiffness: e,
                                        damping: 2 * a * Math.sqrt(n * e),
                                        duration: t
                                    }
                                }
                            }(t);
                            (e = { ...e,
                                ...r,
                                mass: 1
                            }).isResolvedFromDuration = !0
                        }
                        return e
                    }({ ...n,
                        velocity: -er(n.velocity || 0)
                    }),
                    d = f || 0,
                    m = l / (2 * Math.sqrt(u * c)),
                    g = a - s,
                    y = er(Math.sqrt(u / c)),
                    v = 5 > Math.abs(g);
                if (r || (r = v ? .01 : 2), e || (e = v ? .005 : .5), m < 1) {
                    let t = rt(y, m);
                    i = e => a - Math.exp(-m * y * e) * ((d + m * y * g) / t * Math.sin(t * e) + g * Math.cos(t * e))
                } else if (1 === m) i = t => a - Math.exp(-y * t) * (g + (d + y * g) * t);
                else {
                    let t = y * Math.sqrt(m * m - 1);
                    i = e => {
                        let r = Math.exp(-m * y * e),
                            n = Math.min(t * e, 300);
                        return a - r * ((d + m * y * g) * Math.sinh(n) + t * g * Math.cosh(n)) / t
                    }
                }
                return {
                    calculatedDuration: p && h || null,
                    next: t => {
                        let n = i(t);
                        if (p) o.done = t >= h;
                        else {
                            let s = d;
                            0 !== t && (s = m < 1 ? e7(i, t, n) : 0);
                            let u = Math.abs(s) <= r,
                                l = Math.abs(a - n) <= e;
                            o.done = u && l
                        }
                        return o.value = o.done ? a : n, o
                    }
                }
            }

            function rs({
                keyframes: t,
                velocity: e = 0,
                power: r = .8,
                timeConstant: n = 325,
                bounceDamping: i = 10,
                bounceStiffness: s = 500,
                modifyTarget: a,
                min: o,
                max: u,
                restDelta: l = .5,
                restSpeed: c
            }) {
                let h, f;
                let p = t[0],
                    d = {
                        done: !1,
                        value: p
                    },
                    m = t => void 0 !== o && t < o || void 0 !== u && t > u,
                    g = t => void 0 === o ? u : void 0 === u ? o : Math.abs(o - t) < Math.abs(u - t) ? o : u,
                    y = r * e,
                    v = p + y,
                    b = void 0 === a ? v : a(v);
                b !== v && (y = b - p);
                let E = t => -y * Math.exp(-t / n),
                    w = t => b + E(t),
                    T = t => {
                        let e = E(t),
                            r = w(t);
                        d.done = Math.abs(e) <= l, d.value = d.done ? b : r
                    },
                    D = t => {
                        m(d.value) && (h = t, f = ri({
                            keyframes: [d.value, g(d.value)],
                            velocity: e7(w, t, d.value),
                            damping: i,
                            stiffness: s,
                            restDelta: l,
                            restSpeed: c
                        }))
                    };
                return D(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (f || void 0 !== h || (e = !0, T(t), D(t)), void 0 !== h && t >= h) ? f.next(t - h) : (e || T(t), d)
                    }
                }
            }
            let ra = (t, e, r) => (((1 - 3 * r + 3 * e) * t + (3 * r - 6 * e)) * t + 3 * e) * t;

            function ro(t, e, r, n) {
                if (t === e && r === n) return t0.Z;
                let i = e => (function(t, e, r, n, i) {
                    let s, a;
                    let o = 0;
                    do(s = ra(a = e + (r - e) / 2, n, i) - t) > 0 ? r = a : e = a; while (Math.abs(s) > 1e-7 && ++o < 12);
                    return a
                })(e, 0, 1, t, r);
                return t => 0 === t || 1 === t ? t : ra(i(t), e, n)
            }
            let ru = ro(.42, 0, 1, 1),
                rl = ro(0, 0, .58, 1),
                rc = ro(.42, 0, .58, 1),
                rh = t => Array.isArray(t) && "number" != typeof t[0],
                rf = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
                rp = t => e => 1 - t(1 - e),
                rd = t => 1 - Math.sin(Math.acos(t)),
                rm = rp(rd),
                rg = rf(rd),
                ry = ro(.33, 1.53, .69, .99),
                rv = rp(ry),
                rb = rf(rv),
                rE = {
                    linear: t0.Z,
                    easeIn: ru,
                    easeInOut: rc,
                    easeOut: rl,
                    circIn: rd,
                    circInOut: rg,
                    circOut: rm,
                    backIn: rv,
                    backInOut: rb,
                    backOut: ry,
                    anticipate: t => (t *= 2) < 1 ? .5 * rv(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
                },
                rw = t => {
                    if (Array.isArray(t)) {
                        (0, eg.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, r, n, i] = t;
                        return ro(e, r, n, i)
                    }
                    return "string" == typeof t ? ((0, eg.k)(void 0 !== rE[t], `Invalid easing type '${t}'`), rE[t]) : t
                },
                rT = (t, e, r) => {
                    let n = e - t;
                    return 0 === n ? 1 : (r - t) / n
                },
                rD = (t, e, r) => t + (e - t) * r;

            function rx(t, e, r) {
                return (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6) ? t + (e - t) * 6 * r : r < .5 ? e : r < 2 / 3 ? t + (e - t) * (2 / 3 - r) * 6 : t
            }

            function rS(t, e) {
                return r => r > 0 ? e : t
            }
            let rA = (t, e, r) => {
                    let n = t * t,
                        i = r * (e * e - n) + n;
                    return i < 0 ? 0 : Math.sqrt(i)
                },
                rR = [e_, ej, eq],
                rN = t => rR.find(e => e.test(t));

            function rP(t) {
                let e = rN(t);
                if ((0, eg.K)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
                let r = e.parse(t);
                return e === eq && (r = function({
                    hue: t,
                    saturation: e,
                    lightness: r,
                    alpha: n
                }) {
                    t /= 360, r /= 100;
                    let i = 0,
                        s = 0,
                        a = 0;
                    if (e /= 100) {
                        let n = r < .5 ? r * (1 + e) : r + e - r * e,
                            o = 2 * r - n;
                        i = rx(o, n, t + 1 / 3), s = rx(o, n, t), a = rx(o, n, t - 1 / 3)
                    } else i = s = a = r;
                    return {
                        red: Math.round(255 * i),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * a),
                        alpha: n
                    }
                }(r)), r
            }
            let rC = (t, e) => {
                    let r = rP(t),
                        n = rP(e);
                    if (!r || !n) return rS(t, e);
                    let i = { ...r
                    };
                    return t => (i.red = rA(r.red, n.red, t), i.green = rA(r.green, n.green, t), i.blue = rA(r.blue, n.blue, t), i.alpha = rD(r.alpha, n.alpha, t), ej.transform(i))
                },
                rO = new Set(["none", "hidden"]);

            function rI(t, e) {
                return r => rD(t, e, r)
            }

            function rL(t) {
                return "number" == typeof t ? rI : "string" == typeof t ? F(t) ? rS : eF.test(t) ? rC : rU : Array.isArray(t) ? rM : "object" == typeof t ? eF.test(t) ? rC : rk : rS
            }

            function rM(t, e) {
                let r = [...t],
                    n = r.length,
                    i = t.map((t, r) => rL(t)(t, e[r]));
                return t => {
                    for (let e = 0; e < n; e++) r[e] = i[e](t);
                    return r
                }
            }

            function rk(t, e) {
                let r = { ...t,
                        ...e
                    },
                    n = {};
                for (let i in r) void 0 !== t[i] && void 0 !== e[i] && (n[i] = rL(t[i])(t[i], e[i]));
                return t => {
                    for (let e in n) r[e] = n[e](t);
                    return r
                }
            }
            let rU = (t, e) => {
                let r = eY.createTransformer(e),
                    n = e$(t),
                    i = e$(e);
                return n.indexes.var.length === i.indexes.var.length && n.indexes.color.length === i.indexes.color.length && n.indexes.number.length >= i.indexes.number.length ? rO.has(t) && !i.values.length || rO.has(e) && !n.values.length ? rO.has(t) ? r => r <= 0 ? t : e : r => r >= 1 ? e : t : tX(rM(function(t, e) {
                    var r;
                    let n = [],
                        i = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let a = e.types[s],
                            o = t.indexes[a][i[a]],
                            u = null !== (r = t.values[o]) && void 0 !== r ? r : 0;
                        n[s] = u, i[a]++
                    }
                    return n
                }(n, i), i.values), r) : ((0, eg.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), rS(t, e))
            };

            function rB(t, e, r) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof r ? rD(t, e, r) : rL(t)(t, e)
            }

            function rV({
                duration: t = 300,
                keyframes: e,
                times: r,
                ease: n = "easeInOut"
            }) {
                let i = rh(n) ? n.map(rw) : rw(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    a = function(t, e, {
                        clamp: r = !0,
                        ease: n,
                        mixer: i
                    } = {}) {
                        let s = t.length;
                        if ((0, eg.k)(s === e.length, "Both input and output ranges must be the same length"), 1 === s) return () => e[0];
                        if (2 === s && t[0] === t[1]) return () => e[1];
                        t[0] > t[s - 1] && (t = [...t].reverse(), e = [...e].reverse());
                        let a = function(t, e, r) {
                                let n = [],
                                    i = r || rB,
                                    s = t.length - 1;
                                for (let r = 0; r < s; r++) {
                                    let s = i(t[r], t[r + 1]);
                                    e && (s = tX(Array.isArray(e) ? e[r] || t0.Z : e, s)), n.push(s)
                                }
                                return n
                            }(e, n, i),
                            o = a.length,
                            u = e => {
                                let r = 0;
                                if (o > 1)
                                    for (; r < t.length - 2 && !(e < t[r + 1]); r++);
                                let n = rT(t[r], t[r + 1], e);
                                return a[r](n)
                            };
                        return r ? e => u(H(t[0], t[s - 1], e)) : u
                    }((r && r.length === e.length ? r : function(t) {
                        let e = [0];
                        return function(t, e) {
                            let r = t[t.length - 1];
                            for (let n = 1; n <= e; n++) {
                                let i = rT(0, e, n);
                                t.push(rD(r, 1, i))
                            }
                        }(e, t.length - 1), e
                    }(e)).map(e => e * t), e, {
                        ease: Array.isArray(i) ? i : e.map(() => i || rc).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = a(e), s.done = e >= t, s)
                }
            }
            let rj = t => {
                    let e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => tM.Wi.update(e, !0),
                        stop: () => (0, tM.Pn)(e),
                        now: () => tM.frameData.isProcessing ? tM.frameData.timestamp : ed.now()
                    }
                },
                r_ = {
                    decay: rs,
                    inertia: rs,
                    tween: rV,
                    keyframes: rV,
                    spring: ri
                },
                rq = t => t / 100;
            class rF extends e9 {
                constructor({
                    KeyframeResolver: t = eM,
                    ...e
                }) {
                    super(e), this.holdTime = null, this.startTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    let {
                        name: r,
                        motionValue: n,
                        keyframes: i
                    } = this.options, s = (t, e) => this.onKeyframesResolved(t, e);
                    r && n && n.owner ? this.resolver = n.owner.resolveKeyframes(i, s, r, n) : this.resolver = new t(i, s, r, n), this.resolver.scheduleResolve()
                }
                initPlayback(t) {
                    let e, r;
                    let {
                        type: n = "keyframes",
                        repeat: i = 0,
                        repeatDelay: s = 0,
                        repeatType: a,
                        velocity: o = 0
                    } = this.options, u = r_[n] || rV;
                    u !== rV && "number" != typeof t[0] && (e = tX(rq, rB(t[0], t[1])), t = [0, 100]);
                    let l = u({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === a && (r = u({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -o
                    })), null === l.calculatedDuration && (l.calculatedDuration = function(t) {
                        let e = 0,
                            r = t.next(e);
                        for (; !r.done && e < 2e4;) e += 50, r = t.next(e);
                        return e >= 2e4 ? 1 / 0 : e
                    }(l));
                    let {
                        calculatedDuration: c
                    } = l, h = c + s;
                    return {
                        generator: l,
                        mirroredGenerator: r,
                        mapPercentToKeyframes: e,
                        calculatedDuration: c,
                        resolvedDuration: h,
                        totalDuration: h * (i + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: r
                    } = this;
                    if (!r) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: i,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: a,
                        keyframes: o,
                        calculatedDuration: u,
                        totalDuration: l,
                        resolvedDuration: c
                    } = r;
                    if (null === this.startTime) return i.next(0);
                    let {
                        delay: h,
                        repeat: f,
                        repeatType: p,
                        repeatDelay: d,
                        onUpdate: m
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - l / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let g = this.currentTime - h * (this.speed >= 0 ? 1 : -1),
                        y = this.speed >= 0 ? g < 0 : g > l;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = l);
                    let v = this.currentTime,
                        b = i;
                    if (f) {
                        let t = Math.min(this.currentTime, l) / c,
                            e = Math.floor(t),
                            r = t % 1;
                        !r && t >= 1 && (r = 1), 1 === r && e--, (e = Math.min(e, f + 1)) % 2 && ("reverse" === p ? (r = 1 - r, d && (r -= d / c)) : "mirror" === p && (b = s)), v = H(0, 1, r) * c
                    }
                    let E = y ? {
                        done: !1,
                        value: o[0]
                    } : b.next(v);
                    a && (E.value = a(E.value));
                    let {
                        done: w
                    } = E;
                    y || null === u || (w = this.speed >= 0 ? this.currentTime >= l : this.currentTime <= 0);
                    let T = null === this.holdTime && ("finished" === this.state || "running" === this.state && w);
                    return T && void 0 !== n && (E.value = ef(o, this.options, n)), m && m(E.value), T && this.finish(), E
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? er(t.calculatedDuration) : 0
                }
                get time() {
                    return er(this.currentTime)
                }
                set time(t) {
                    t = ee(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = er(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = rj,
                        onPlay: e
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let r = this.driver.now();
                    null !== this.holdTime ? this.startTime = r - this.holdTime : this.startTime && "finished" !== this.state || (this.startTime = r), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            let rX = t => Array.isArray(t) && "number" == typeof t[0],
                rG = ([t, e, r, n]) => `cubic-bezier(${t}, ${e}, ${r}, ${n})`,
                rH = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: rG([0, .65, .55, 1]),
                    circOut: rG([.55, 0, 1, .45]),
                    backIn: rG([.31, .01, .66, -.59]),
                    backOut: rG([.33, 1.53, .69, .99])
                };

            function r$(t) {
                return rz(t) || rH.easeOut
            }

            function rz(t) {
                if (t) return rX(t) ? rG(t) : Array.isArray(t) ? t.map(r$) : rH[t]
            }
            let rW = e8(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                rK = new Set(["opacity", "clipPath", "filter", "transform"]);
            class rY extends e9 {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: r,
                        keyframes: n
                    } = this.options;
                    this.resolver = new e6(n, (t, e) => this.onKeyframesResolved(t, e), e, r), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var r, n;
                    let {
                        duration: i = 300,
                        times: s,
                        ease: a,
                        type: o,
                        motionValue: u,
                        name: l
                    } = this.options;
                    if (!(null === (r = u.owner) || void 0 === r ? void 0 : r.current)) return !1;
                    if ("spring" === (n = this.options).type || "backgroundColor" === n.name || ! function t(e) {
                            return !!(!e || "string" == typeof e && e in rH || rX(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: r,
                            motionValue: n,
                            ...u
                        } = this.options, l = function(t, e) {
                            let r = new rF({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                i = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) i.push((n = r.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: i,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, u);
                        1 === (t = l.keyframes).length && (t[1] = t[0]), i = l.duration, s = l.times, a = l.ease, o = "keyframes"
                    }
                    let c = function(t, e, r, {
                        delay: n = 0,
                        duration: i = 300,
                        repeat: s = 0,
                        repeatType: a = "loop",
                        ease: o,
                        times: u
                    } = {}) {
                        let l = {
                            [e]: r
                        };
                        u && (l.offset = u);
                        let c = rz(o);
                        return Array.isArray(c) && (l.easing = c), t.animate(l, {
                            delay: n,
                            duration: i,
                            easing: Array.isArray(c) ? "linear" : c,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === a ? "alternate" : "normal"
                        })
                    }(u.owner.current, l, t, { ...this.options,
                        duration: i,
                        times: s,
                        ease: a
                    });
                    return c.startTime = ed.now(), this.pendingTimeline ? (c.timeline = this.pendingTimeline, this.pendingTimeline = void 0) : c.onfinish = () => {
                        let {
                            onComplete: r
                        } = this.options;
                        u.set(ef(t, this.options, e)), r && r(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: c,
                        duration: i,
                        times: s,
                        type: o,
                        ease: a,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return er(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return er(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: r
                    } = e;
                    r.currentTime = ee(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: r
                    } = e;
                    r.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return t0.Z;
                        let {
                            animation: r
                        } = e;
                        r.timeline = t, r.onfinish = null
                    } else this.pendingTimeline = t;
                    return t0.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: r,
                        duration: n,
                        type: i,
                        ease: s,
                        times: a
                    } = t;
                    if ("idle" !== e.playState && "finished" !== e.playState) {
                        if (this.time) {
                            let {
                                motionValue: t,
                                onUpdate: e,
                                onComplete: o,
                                ...u
                            } = this.options, l = new rF({ ...u,
                                keyframes: r,
                                duration: n,
                                type: i,
                                ease: s,
                                times: a,
                                isGenerator: !0
                            }), c = ee(this.time);
                            t.setWithVelocity(l.sample(c - 10).value, l.sample(c).value, 10)
                        }
                        this.cancel()
                    }
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: r,
                        repeatDelay: n,
                        repeatType: i,
                        damping: s,
                        type: a
                    } = t;
                    return rW() && r && rK.has(r) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== i && 0 !== s && "inertia" !== a
                }
            }
            let rZ = e8(() => void 0 !== window.ScrollTimeline);
            class rJ {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let r = 0; r < this.animations.length; r++) this.animations[r][t] = e
                }
                attachTimeline(t) {
                    let e = this.animations.map(e => {
                        if (!rZ() || !e.attachTimeline) return e.pause(),
                            function(t, e) {
                                let r;
                                let n = () => {
                                    let {
                                        currentTime: n
                                    } = e, i = (null === n ? 0 : n.value) / 100;
                                    r !== i && t(i), r = i
                                };
                                return tM.Wi.update(n, !0), () => (0, tM.Pn)(n)
                            }(t => {
                                e.time = e.duration * t
                            }, t);
                        e.attachTimeline(t)
                    });
                    return () => {
                        e.forEach((t, e) => {
                            t && t(), this.animations[e].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach(e => e[t]())
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            let rQ = (t, e, r, n = {}, i, s) => a => {
                let o = eu(n, t) || {},
                    u = o.delay || n.delay || 0,
                    {
                        elapsed: l = 0
                    } = n;
                l -= ee(u);
                let c = {
                    keyframes: Array.isArray(r) ? r : [null, r],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...o,
                    delay: -l,
                    onUpdate: t => {
                        e.set(t), o.onUpdate && o.onUpdate(t)
                    },
                    onComplete: () => {
                        a(), o.onComplete && o.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: s ? void 0 : i
                };
                ! function({
                    when: t,
                    delay: e,
                    delayChildren: r,
                    staggerChildren: n,
                    staggerDirection: i,
                    repeat: s,
                    repeatType: a,
                    repeatDelay: o,
                    from: u,
                    elapsed: l,
                    ...c
                }) {
                    return !!Object.keys(c).length
                }(o) && (c = { ...c,
                    ...eo(t, c)
                }), c.duration && (c.duration = ee(c.duration)), c.repeatDelay && (c.repeatDelay = ee(c.repeatDelay)), void 0 !== c.from && (c.keyframes[0] = c.from);
                let h = !1;
                if (!1 !== c.type && (0 !== c.duration || c.repeatDelay) || (c.duration = 0, 0 !== c.delay || (h = !0)), (ec.current || el.c.skipAnimations) && (h = !0, c.duration = 0, c.delay = 0), h && !s && void 0 !== e.get()) {
                    let t = ef(c.keyframes, o);
                    if (void 0 !== t) return tM.Wi.update(() => {
                        c.onUpdate(t), c.onComplete()
                    }), new rJ([])
                }
                return !s && rY.supports(c) ? new rY(c) : new rF(c)
            };

            function r0(t) {
                return !!(U(t) && t.add)
            }

            function r1(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function r2(t, e) {
                let r = t.indexOf(e);
                r > -1 && t.splice(r, 1)
            }
            class r5 {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return r1(this.subscriptions, t), () => r2(this.subscriptions, t)
                }
                notify(t, e, r) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, r);
                        else
                            for (let i = 0; i < n; i++) {
                                let n = this.subscriptions[i];
                                n && n(t, e, r)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
            let r3 = t => !isNaN(parseFloat(t)),
                r6 = {
                    current: void 0
                };
            class r8 {
                constructor(t, e = {}) {
                    this.version = "11.2.10", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let r = ed.now();
                        this.updatedAt !== r && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = ed.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = r3(this.current))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new r5);
                    let r = this.events[t].add(e);
                    return "change" === t ? () => {
                        r(), tM.Wi.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : r
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, r) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - r
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return r6.current && r6.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    var t;
                    let e = ed.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
                    let r = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return t = parseFloat(this.current) - parseFloat(this.prevFrameValue), r ? 1e3 / r * t : 0
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function r4(t, e) {
                return new r8(t, e)
            }

            function r9(t) {
                return t.getProps()[p]
            }

            function r7(t, e, {
                delay: r = 0,
                transitionOverride: n,
                type: i
            } = {}) {
                var s;
                let {
                    transition: a = t.getDefaultTransition(),
                    transitionEnd: o,
                    ...u
                } = e, l = t.getValue("willChange");
                n && (a = n);
                let c = [],
                    h = i && t.animationState && t.animationState.getState()[i];
                for (let e in u) {
                    let n = t.getValue(e, null !== (s = t.latestValues[e]) && void 0 !== s ? s : null),
                        i = u[e];
                    if (void 0 === i || h && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, r) {
                            let n = t.hasOwnProperty(r) && !0 !== e[r];
                            return e[r] = !1, n
                        }(h, e)) continue;
                    let o = {
                            delay: r,
                            elapsed: 0,
                            ...eu(a || {}, e)
                        },
                        f = !1;
                    if (window.HandoffAppearAnimations) {
                        let r = r9(t);
                        if (r) {
                            let t = window.HandoffAppearAnimations(r, e, n, tM.Wi);
                            null !== t && (o.elapsed = t, f = !0)
                        }
                    }
                    n.start(rQ(e, n, i, t.shouldReduceMotion && M.has(e) ? {
                        type: !1
                    } : o, t, f));
                    let p = n.animation;
                    p && (r0(l) && (l.add(e), p.then(() => l.remove(e))), c.push(p))
                }
                return o && Promise.all(c).then(() => {
                    tM.Wi.update(() => {
                        o && function(t, e) {
                            let {
                                transitionEnd: r = {},
                                transition: n = {},
                                ...i
                            } = et(t, e) || {};
                            for (let e in i = { ...i,
                                    ...r
                                }) {
                                let r = tO(i[e]);
                                t.hasValue(e) ? t.getValue(e).set(r) : t.addValue(e, r4(r))
                            }
                        }(t, o)
                    })
                }), c
            }

            function nt(t, e, r = {}) {
                var n;
                let i = et(t, e, "exit" === r.type ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0),
                    {
                        transition: s = t.getDefaultTransition() || {}
                    } = i || {};
                r.transitionOverride && (s = r.transitionOverride);
                let a = i ? () => Promise.all(r7(t, i, r)) : () => Promise.resolve(),
                    o = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: i = 0,
                            staggerChildren: a,
                            staggerDirection: o
                        } = s;
                        return function(t, e, r = 0, n = 0, i = 1, s) {
                            let a = [],
                                o = (t.variantChildren.size - 1) * n,
                                u = 1 === i ? (t = 0) => t * n : (t = 0) => o - t * n;
                            return Array.from(t.variantChildren).sort(ne).forEach((t, n) => {
                                t.notify("AnimationStart", e), a.push(nt(t, e, { ...s,
                                    delay: r + u(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(a)
                        }(t, e, i + n, a, o, r)
                    } : () => Promise.resolve(),
                    {
                        when: u
                    } = s;
                if (!u) return Promise.all([a(), o(r.delay)]); {
                    let [t, e] = "beforeChildren" === u ? [a, o] : [o, a];
                    return t().then(() => e())
                }
            }

            function ne(t, e) {
                return t.sortNodePosition(e)
            }
            let nr = [...b].reverse(),
                nn = b.length;

            function ni(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }
            class ns extends tK {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: r
                            }) => (function(t, e, r = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => nt(t, e, r)));
                                else if ("string" == typeof e) n = nt(t, e, r);
                                else {
                                    let i = "function" == typeof e ? et(t, e, r.custom) : e;
                                    n = Promise.all(r7(t, i, r))
                                }
                                return n.then(() => {
                                    tM.Wi.postRender(() => {
                                        t.notify("AnimationComplete", e)
                                    })
                                })
                            })(t, e, r))),
                            r = {
                                animate: ni(!0),
                                whileInView: ni(),
                                whileHover: ni(),
                                whileTap: ni(),
                                whileDrag: ni(),
                                whileFocus: ni(),
                                exit: ni()
                            },
                            n = !0,
                            i = e => (r, n) => {
                                var i;
                                let s = et(t, n, "exit" === e ? null === (i = t.presenceContext) || void 0 === i ? void 0 : i.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    r = { ...r,
                                        ...n,
                                        ...e
                                    }
                                }
                                return r
                            };

                        function s(s) {
                            let a = t.getProps(),
                                o = t.getVariantContext(!0) || {},
                                u = [],
                                l = new Set,
                                c = {},
                                h = 1 / 0;
                            for (let e = 0; e < nn; e++) {
                                var f;
                                let p = nr[e],
                                    d = r[p],
                                    m = void 0 !== a[p] ? a[p] : o[p],
                                    g = y(m),
                                    b = p === s ? d.isActive : null;
                                !1 === b && (h = e);
                                let E = m === o[p] && m !== a[p] && g;
                                if (E && n && t.manuallyAnimateOnMount && (E = !1), d.protectedKeys = { ...c
                                    }, !d.isActive && null === b || !m && !d.prevProp || v(m) || "boolean" == typeof m) continue;
                                let w = (f = d.prevProp, ("string" == typeof m ? m !== f : !!Array.isArray(m) && !t7(m, f)) || p === s && d.isActive && !E && g || e > h && g),
                                    T = !1,
                                    D = Array.isArray(m) ? m : [m],
                                    x = D.reduce(i(p), {});
                                !1 === b && (x = {});
                                let {
                                    prevResolvedValues: S = {}
                                } = d, A = { ...S,
                                    ...x
                                }, R = e => {
                                    w = !0, l.has(e) && (T = !0, l.delete(e)), d.needsAnimating[e] = !0;
                                    let r = t.getValue(e);
                                    r && (r.liveStyle = !1)
                                };
                                for (let t in A) {
                                    let e = x[t],
                                        r = S[t];
                                    if (!c.hasOwnProperty(t))(tP(e) && tP(r) ? t7(e, r) : e === r) ? void 0 !== e && l.has(t) ? R(t) : d.protectedKeys[t] = !0 : null != e ? R(t) : l.add(t)
                                }
                                d.prevProp = m, d.prevResolvedValues = x, d.isActive && (c = { ...c,
                                    ...x
                                }), n && t.blockInitialAnimation && (w = !1), w && (!E || T) && u.push(...D.map(t => ({
                                    animation: t,
                                    options: {
                                        type: p
                                    }
                                })))
                            }
                            if (l.size) {
                                let e = {};
                                l.forEach(r => {
                                    let n = t.getBaseTarget(r),
                                        i = t.getValue(r);
                                    i && (i.liveStyle = !0), e[r] = null != n ? n : null
                                }), u.push({
                                    animation: e
                                })
                            }
                            let p = !!u.length;
                            return n && (!1 === a.initial || a.initial === a.animate) && !t.manuallyAnimateOnMount && (p = !1), n = !1, p ? e(u) : Promise.resolve()
                        }
                        return {
                            animateChanges: s,
                            setActive: function(e, n) {
                                var i;
                                if (r[e].isActive === n) return Promise.resolve();
                                null === (i = t.variantChildren) || void 0 === i || i.forEach(t => {
                                    var r;
                                    return null === (r = t.animationState) || void 0 === r ? void 0 : r.setActive(e, n)
                                }), r[e].isActive = n;
                                let a = s(e);
                                for (let t in r) r[t].protectedKeys = {};
                                return a
                            },
                            setAnimateFunction: function(r) {
                                e = r(t)
                            },
                            getState: () => r
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    this.unmount(), v(t) && (this.unmount = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {}
            }
            let na = 0;
            class no extends tK {
                constructor() {
                    super(...arguments), this.id = na++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: r
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === r) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            let nu = (t, e) => Math.abs(t - e);
            class nl {
                constructor(t, e, {
                    transformPagePoint: r,
                    contextWindow: n,
                    dragSnapToOrigin: i = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            var t, e;
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let r = nf(this.lastMoveEventInfo, this.history),
                                n = null !== this.startEvent,
                                i = (t = r.offset, e = {
                                    x: 0,
                                    y: 0
                                }, Math.sqrt(nu(t.x, e.x) ** 2 + nu(t.y, e.y) ** 2) >= 3);
                            if (!n && !i) return;
                            let {
                                point: s
                            } = r, {
                                timestamp: a
                            } = tM.frameData;
                            this.history.push({ ...s,
                                timestamp: a
                            });
                            let {
                                onStart: o,
                                onMove: u
                            } = this.handlers;
                            n || (o && o(this.lastMoveEvent, r), this.startEvent = this.lastMoveEvent), u && u(this.lastMoveEvent, r)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = nc(e, this.transformPagePoint), tM.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: r,
                                onSessionEnd: n,
                                resumeAnimation: i
                            } = this.handlers;
                            if (this.dragSnapToOrigin && i && i(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = nf("pointercancel" === t.type ? this.lastMoveEventInfo : nc(e, this.transformPagePoint), this.history);
                            this.startEvent && r && r(t, s), n && n(t, s)
                        }, !tV(t)) return;
                    this.dragSnapToOrigin = i, this.handlers = e, this.transformPagePoint = r, this.contextWindow = n || window;
                    let s = nc(tj(t), this.transformPagePoint),
                        {
                            point: a
                        } = s,
                        {
                            timestamp: o
                        } = tM.frameData;
                    this.history = [{ ...a,
                        timestamp: o
                    }];
                    let {
                        onSessionStart: u
                    } = e;
                    u && u(t, nf(s, this.history)), this.removeListeners = tX(tq(this.contextWindow, "pointermove", this.handlePointerMove), tq(this.contextWindow, "pointerup", this.handlePointerUp), tq(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, tM.Pn)(this.updatePoint)
                }
            }

            function nc(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function nh(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function nf({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: nh(t, np(e)),
                    offset: nh(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let r = t.length - 1,
                            n = null,
                            i = np(t);
                        for (; r >= 0 && (n = t[r], !(i.timestamp - n.timestamp > ee(.1)));) r--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = er(i.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let a = {
                            x: (i.x - n.x) / s,
                            y: (i.y - n.y) / s
                        };
                        return a.x === 1 / 0 && (a.x = 0), a.y === 1 / 0 && (a.y = 0), a
                    }(e, 0)
                }
            }

            function np(t) {
                return t[t.length - 1]
            }

            function nd(t) {
                return t.max - t.min
            }

            function nm(t, e = 0, r = .01) {
                return Math.abs(t - e) <= r
            }

            function ng(t, e, r, n = .5) {
                t.origin = n, t.originPoint = rD(e.min, e.max, t.origin), t.scale = nd(r) / nd(e), (nm(t.scale, 1, 1e-4) || isNaN(t.scale)) && (t.scale = 1), t.translate = rD(r.min, r.max, t.origin) - t.originPoint, (nm(t.translate) || isNaN(t.translate)) && (t.translate = 0)
            }

            function ny(t, e, r, n) {
                ng(t.x, e.x, r.x, n ? n.originX : void 0), ng(t.y, e.y, r.y, n ? n.originY : void 0)
            }

            function nv(t, e, r) {
                t.min = r.min + e.min, t.max = t.min + nd(e)
            }

            function nb(t, e, r) {
                t.min = e.min - r.min, t.max = t.min + nd(e)
            }

            function nE(t, e, r) {
                nb(t.x, e.x, r.x), nb(t.y, e.y, r.y)
            }

            function nw(t, e, r) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== r ? t.max + r - (t.max - t.min) : void 0
                }
            }

            function nT(t, e) {
                let r = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([r, n] = [n, r]), {
                    min: r,
                    max: n
                }
            }

            function nD(t, e, r) {
                return {
                    min: nx(t, e),
                    max: nx(t, r)
                }
            }

            function nx(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            let nS = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                nA = () => ({
                    x: nS(),
                    y: nS()
                }),
                nR = () => ({
                    min: 0,
                    max: 0
                }),
                nN = () => ({
                    x: nR(),
                    y: nR()
                });

            function nP(t) {
                return [t("x"), t("y")]
            }

            function nC({
                top: t,
                left: e,
                right: r,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: r
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function nO(t) {
                return void 0 === t || 1 === t
            }

            function nI({
                scale: t,
                scaleX: e,
                scaleY: r
            }) {
                return !nO(t) || !nO(e) || !nO(r)
            }

            function nL(t) {
                return nI(t) || nM(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function nM(t) {
                var e, r;
                return (e = t.x) && "0%" !== e || (r = t.y) && "0%" !== r
            }

            function nk(t, e, r, n, i) {
                return void 0 !== i && (t = n + i * (t - n)), n + r * (t - n) + e
            }

            function nU(t, e = 0, r = 1, n, i) {
                t.min = nk(t.min, e, r, n, i), t.max = nk(t.max, e, r, n, i)
            }

            function nB(t, {
                x: e,
                y: r
            }) {
                nU(t.x, e.translate, e.scale, e.originPoint), nU(t.y, r.translate, r.scale, r.originPoint)
            }

            function nV(t) {
                return Number.isInteger(t) ? t : t > 1.0000000000001 || t < .999999999999 ? t : 1
            }

            function nj(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function n_(t, e, [r, n, i]) {
                let s = void 0 !== e[i] ? e[i] : .5,
                    a = rD(t.min, t.max, s);
                nU(t, e[r], e[n], a, e.scale)
            }
            let nq = ["x", "scaleX", "originX"],
                nF = ["y", "scaleY", "originY"];

            function nX(t, e) {
                n_(t.x, e, nq), n_(t.y, e, nF)
            }

            function nG(t, e) {
                return nC(function(t, e) {
                    if (!e) return t;
                    let r = e({
                            x: t.left,
                            y: t.top
                        }),
                        n = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: r.y,
                        left: r.x,
                        bottom: n.y,
                        right: n.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            let nH = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null,
                n$ = new WeakMap;
            class nz {
                constructor(t) {
                    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = nN(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: r
                    } = this.visualElement;
                    if (r && !1 === r.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new nl(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: r
                            } = this.getProps();
                            r ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(tj(t, "page").point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: r,
                                dragPropagation: n,
                                onDragStart: i
                            } = this.getProps();
                            if (r && !n && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = tz(r), !this.openGlobalLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), nP(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (tr.test(e)) {
                                    let {
                                        projection: r
                                    } = this.visualElement;
                                    if (r && r.layout) {
                                        let n = r.layout.layoutBox[t];
                                        if (n) {
                                            let t = nd(n);
                                            e = parseFloat(e) / 100 * t
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            }), i && tM.Wi.postRender(() => i(t, e));
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: r,
                                dragDirectionLock: n,
                                onDirectionLock: i,
                                onDrag: s
                            } = this.getProps();
                            if (!r && !this.openGlobalLock) return;
                            let {
                                offset: a
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let r = null;
                                    return Math.abs(t.y) > e ? r = "y" : Math.abs(t.x) > e && (r = "x"), r
                                }(a), null !== this.currentDirection && i && i(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, a), this.updateAxis("y", e.point, a), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => nP(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: nH(this.visualElement)
                    })
                }
                stop(t, e) {
                    let r = this.isDragging;
                    if (this.cancel(), !r) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: i
                    } = this.getProps();
                    i && tM.Wi.postRender(() => i(t, e))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: r
                    } = this.getProps();
                    !r && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, r) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!r || !nW(t, n, this.currentDirection)) return;
                    let i = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + r[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: r
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? rD(e, t, n.min) : Math.max(t, e) : void 0 !== r && t > r && (t = n ? rD(r, t, n.max) : Math.min(t, r)), t
                    }(s, this.constraints[t], this.elastic[t])), i.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: r
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, i = this.constraints;
                    e && g(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: r,
                        bottom: n,
                        right: i
                    }) {
                        return {
                            x: nw(t.x, r, i),
                            y: nw(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: nD(t, "left", "right"),
                            y: nD(t, "top", "bottom")
                        }
                    }(r), i !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && nP(t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let r = {};
                            return void 0 !== e.min && (r.min = e.min - t.min), void 0 !== e.max && (r.max = e.max - t.min), r
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: r
                    } = this.getProps();
                    if (!e || !g(e)) return !1;
                    let n = e.current;
                    (0, eg.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: i
                    } = this.visualElement;
                    if (!i || !i.layout) return !1;
                    let s = function(t, e, r) {
                            let n = nG(t, r),
                                {
                                    scroll: i
                                } = e;
                            return i && (nj(n.x, i.offset.x), nj(n.y, i.offset.y)), n
                        }(n, i.root, this.visualElement.getTransformPagePoint()),
                        a = {
                            x: nT((t = i.layout.layoutBox).x, s.x),
                            y: nT(t.y, s.y)
                        };
                    if (r) {
                        let t = r(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(a));
                        this.hasMutatedConstraints = !!t, t && (a = nC(t))
                    }
                    return a
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: r,
                        dragElastic: n,
                        dragTransition: i,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: a
                    } = this.getProps(), o = this.constraints || {};
                    return Promise.all(nP(a => {
                        if (!nW(a, e, this.currentDirection)) return;
                        let u = o && o[a] || {};
                        s && (u = {
                            min: 0,
                            max: 0
                        });
                        let l = {
                            type: "inertia",
                            velocity: r ? t[a] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...i,
                            ...u
                        };
                        return this.startAxisValueAnimation(a, l)
                    })).then(a)
                }
                startAxisValueAnimation(t, e) {
                    let r = this.getAxisMotionValue(t);
                    return r.start(rQ(t, r, 0, e, this.visualElement))
                }
                stopAnimation() {
                    nP(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    nP(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`,
                        r = this.visualElement.getProps();
                    return r[e] || this.visualElement.getValue(t, (r.initial ? r.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    nP(e => {
                        let {
                            drag: r
                        } = this.getProps();
                        if (!nW(e, r, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, i = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: r,
                                max: s
                            } = n.layout.layoutBox[e];
                            i.set(t[e] - rD(r, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: r
                    } = this.visualElement;
                    if (!g(e) || !r || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    nP(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            let r = e.get();
                            n[t] = function(t, e) {
                                let r = .5,
                                    n = nd(t),
                                    i = nd(e);
                                return i > n ? r = rT(e.min, e.max - n, t.min) : n > i && (r = rT(t.min, t.max - i, e.min)), H(0, 1, r)
                            }({
                                min: r,
                                max: r
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: i
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = i ? i({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), nP(e => {
                        if (!nW(e, t, null)) return;
                        let r = this.getAxisMotionValue(e),
                            {
                                min: i,
                                max: s
                            } = this.constraints[e];
                        r.set(rD(i, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    n$.set(this.visualElement, this);
                    let t = tq(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: r = !0
                            } = this.getProps();
                            e && r && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            g(t) && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: r
                        } = this.visualElement,
                        n = r.addEventListener("measure", e);
                    r && !r.layout && (r.root && r.root.updateScroll(), r.updateLayout()), e();
                    let i = tB(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = r.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (nP(e => {
                                let r = this.getAxisMotionValue(e);
                                r && (this.originPoint[e] += t[e].translate, r.set(r.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        i(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: r = !1,
                            dragPropagation: n = !1,
                            dragConstraints: i = !1,
                            dragElastic: s = .35,
                            dragMomentum: a = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: r,
                        dragPropagation: n,
                        dragConstraints: i,
                        dragElastic: s,
                        dragMomentum: a
                    }
                }
            }

            function nW(t, e, r) {
                return (!0 === e || e === t) && (null === r || r === t)
            }
            class nK extends tK {
                constructor(t) {
                    super(t), this.removeGroupControls = t0.Z, this.removeListeners = t0.Z, this.controls = new nz(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || t0.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let nY = t => (e, r) => {
                t && tM.Wi.postRender(() => t(e, r))
            };
            class nZ extends tK {
                constructor() {
                    super(...arguments), this.removePointerDownListener = t0.Z
                }
                onPointerDown(t) {
                    this.session = new nl(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: nH(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: r,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: nY(t),
                        onStart: nY(e),
                        onMove: r,
                        onEnd: (t, e) => {
                            delete this.session, n && tM.Wi.postRender(() => n(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = tq(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            let nJ = {
                hasAnimatedSinceResize: !0,
                hasEverUpdated: !1
            };

            function nQ(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let n0 = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!tn.test(t)) return t;
                        t = parseFloat(t)
                    }
                    let r = nQ(t, e.target.x),
                        n = nQ(t, e.target.y);
                    return `${r}% ${n}%`
                }
            };
            class n1 extends a.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: r,
                        layoutId: n
                    } = this.props, {
                        projection: i
                    } = t;
                    Object.assign(I, n5), i && (e.group && e.group.add(i), r && r.register && n && r.register(i), i.root.didUpdate(), i.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), i.setOptions({ ...i.options,
                        onExitComplete: () => this.safeToRemove()
                    })), nJ.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: r,
                        drag: n,
                        isPresent: i
                    } = this.props, s = r.projection;
                    return s && (s.isPresent = i, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === i || (i ? s.promote() : s.relegate() || tM.Wi.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), d.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: r
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), r && r.deregister && r.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function n2(t) {
                let [e, r] = function() {
                    let t = (0, a.useContext)(l.O);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: r,
                        register: n
                    } = t, i = (0, a.useId)();
                    return (0, a.useEffect)(() => n(i), []), !e && r ? [!1, () => r && r(i)] : [!0]
                }(), n = (0, a.useContext)(R.p);
                return (0, s.jsx)(n1, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, a.useContext)(N),
                    isPresent: e,
                    safeToRemove: r
                })
            }
            let n5 = {
                    borderRadius: { ...n0,
                        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                    },
                    borderTopLeftRadius: n0,
                    borderTopRightRadius: n0,
                    borderBottomLeftRadius: n0,
                    borderBottomRightRadius: n0,
                    boxShadow: {
                        correct: (t, {
                            treeScale: e,
                            projectionDelta: r
                        }) => {
                            let n = eY.parse(t);
                            if (n.length > 5) return t;
                            let i = eY.createTransformer(t),
                                s = "number" != typeof n[0] ? 1 : 0,
                                a = r.x.scale * e.x,
                                o = r.y.scale * e.y;
                            n[0 + s] /= a, n[1 + s] /= o;
                            let u = rD(a, o, .5);
                            return "number" == typeof n[2 + s] && (n[2 + s] /= u), "number" == typeof n[3 + s] && (n[3 + s] /= u), i(n)
                        }
                    }
                },
                n3 = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                n6 = n3.length,
                n8 = t => "string" == typeof t ? parseFloat(t) : t,
                n4 = t => "number" == typeof t || tn.test(t);

            function n9(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let n7 = ie(0, .5, rm),
                it = ie(.5, .95, t0.Z);

            function ie(t, e, r) {
                return n => n < t ? 0 : n > e ? 1 : r(rT(t, e, n))
            }

            function ir(t, e) {
                t.min = e.min, t.max = e.max
            }

            function ii(t, e) {
                ir(t.x, e.x), ir(t.y, e.y)
            }

            function is(t, e, r, n, i) {
                return t -= e, t = n + 1 / r * (t - n), void 0 !== i && (t = n + 1 / i * (t - n)), t
            }

            function ia(t, e, [r, n, i], s, a) {
                ! function(t, e = 0, r = 1, n = .5, i, s = t, a = t) {
                    if (tr.test(e) && (e = parseFloat(e), e = rD(a.min, a.max, e / 100) - a.min), "number" != typeof e) return;
                    let o = rD(s.min, s.max, n);
                    t === s && (o -= e), t.min = is(t.min, e, r, o, i), t.max = is(t.max, e, r, o, i)
                }(t, e[r], e[n], e[i], e.scale, s, a)
            }
            let io = ["x", "scaleX", "originX"],
                iu = ["y", "scaleY", "originY"];

            function il(t, e, r, n) {
                ia(t.x, e, io, r ? r.x : void 0, n ? n.x : void 0), ia(t.y, e, iu, r ? r.y : void 0, n ? n.y : void 0)
            }

            function ic(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function ih(t) {
                return ic(t.x) && ic(t.y)
            }

            function ip(t, e) {
                return Math.round(t.x.min) === Math.round(e.x.min) && Math.round(t.x.max) === Math.round(e.x.max) && Math.round(t.y.min) === Math.round(e.y.min) && Math.round(t.y.max) === Math.round(e.y.max)
            }

            function id(t) {
                return nd(t.x) / nd(t.y)
            }
            class im {
                constructor() {
                    this.members = []
                }
                add(t) {
                    r1(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if (r2(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let r = this.members.findIndex(e => t === e);
                    if (0 === r) return !1;
                    for (let t = r; t >= 0; t--) {
                        let r = this.members[t];
                        if (!1 !== r.isPresent) {
                            e = r;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let r = this.lead;
                    if (t !== r && (this.prevLead = r, this.lead = t, t.show(), r)) {
                        r.instance && r.scheduleRender(), t.scheduleRender(), t.resumeFrom = r, e && (t.resumeFrom.preserveOpacity = !0), r.snapshot && (t.snapshot = r.snapshot, t.snapshot.latestValues = r.animationValues || r.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && r.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: r
                        } = t;
                        e.onExitComplete && e.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }

            function ig(t, e, r) {
                let n = "",
                    i = t.x.translate / e.x,
                    s = t.y.translate / e.y,
                    a = (null == r ? void 0 : r.z) || 0;
                if ((i || s || a) && (n = `translate3d(${i}px, ${s}px, ${a}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), r) {
                    let {
                        transformPerspective: t,
                        rotate: e,
                        rotateX: i,
                        rotateY: s,
                        skewX: a,
                        skewY: o
                    } = r;
                    t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), i && (n += `rotateX(${i}deg) `), s && (n += `rotateY(${s}deg) `), a && (n += `skewX(${a}deg) `), o && (n += `skewY(${o}deg) `)
                }
                let o = t.x.scale * e.x,
                    u = t.y.scale * e.y;
                return (1 !== o || 1 !== u) && (n += `scale(${o}, ${u})`), n || "none"
            }
            let iy = (t, e) => t.depth - e.depth;
            class iv {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    r1(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    r2(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(iy), this.isDirty = !1, this.children.forEach(t)
                }
            }
            let ib = ["", "X", "Y", "Z"],
                iE = {
                    visibility: "hidden"
                },
                iw = 0,
                iT = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                };

            function iD(t, e, r, n) {
                let {
                    latestValues: i
                } = e;
                i[t] && (r[t] = i[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function ix({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: r,
                checkIsScrollRoot: n,
                resetTransform: i
            }) {
                return class {
                    constructor(t = {}, r = null == e ? void 0 : e()) {
                        this.id = iw++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, iT.totalNodes = iT.resolvedTargetDeltas = iT.recalculatedProjection = 0, this.nodes.forEach(iR), this.nodes.forEach(iM), this.nodes.forEach(ik), this.nodes.forEach(iN), window.MotionDebug && window.MotionDebug.record(iT)
                        }, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = r ? r.root || r : this, this.path = r ? [...r.path, r] : [], this.parent = r, this.depth = r ? r.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new iv)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new r5), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let r = this.eventHandlers.get(t);
                        r && r.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, r = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = e instanceof SVGElement && "svg" !== e.tagName, this.instance = e;
                        let {
                            layoutId: n,
                            layout: i,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), r && (i || n) && (this.isLayoutDirty = !0), t) {
                            let r;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, r && r(), r = function(t, e) {
                                    let r = ed.now(),
                                        n = ({
                                            timestamp: e
                                        }) => {
                                            let i = e - r;
                                            i >= 250 && ((0, tM.Pn)(n), t(i - 250))
                                        };
                                    return tM.Wi.read(n, !0), () => (0, tM.Pn)(n)
                                }(n, 0), nJ.hasAnimatedSinceResize && (nJ.hasAnimatedSinceResize = !1, this.nodes.forEach(iL))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || i) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: r,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let i = this.options.transition || s.getDefaultTransition() || iq,
                                {
                                    onLayoutAnimationStart: a,
                                    onLayoutAnimationComplete: o
                                } = s.getProps(),
                                u = !this.targetLayout || !ip(this.targetLayout, n) || r,
                                l = !e && r;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || l || e && (u || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, l);
                                let e = { ...eu(i, "layout"),
                                    onPlay: a,
                                    onComplete: o
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || iL(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, tM.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(iU), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.HandoffCancelAllAnimations && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return !1;
                                let {
                                    visualElement: r
                                } = e.options;
                                return !!r && (!!r9(r) || !!e.parent && !e.parent.hasCheckedOptimisedAppear && t(e.parent))
                            }(this) && window.HandoffCancelAllAnimations(), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: r
                        } = this.options;
                        if (void 0 === e && !r) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(iC);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(iO), this.isUpdating = !1, this.nodes.forEach(iI), this.nodes.forEach(iS), this.nodes.forEach(iA), this.clearAllSnapshots();
                        let t = ed.now();
                        tM.frameData.delta = H(0, 1e3 / 60, t - tM.frameData.timestamp), tM.frameData.timestamp = t, tM.frameData.isProcessing = !0, tM.S6.update.process(tM.frameData), tM.S6.preRender.process(tM.frameData), tM.S6.render.process(tM.frameData), tM.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, d.read(() => this.update()))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(iP), this.sharedNodes.forEach(iB)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, tM.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        tM.Wi.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = nN(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && (this.scroll = {
                            animationId: this.root.animationId,
                            phase: t,
                            isRoot: n(this.instance),
                            offset: r(this.instance)
                        })
                    }
                    resetTransform() {
                        if (!i) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform,
                            e = this.projectionDelta && !ih(this.projectionDelta),
                            r = this.getTransformTemplate(),
                            n = r ? r(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || nL(this.latestValues) || s) && (i(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let r = this.measurePageBox(),
                            n = this.removeElementScroll(r);
                        return t && (n = this.removeTransform(n)), iG((e = n).x), iG(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: r,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return nN();
                        let e = t.measureViewportBox(),
                            {
                                scroll: r
                            } = this.root;
                        return r && (nj(e.x, r.offset.x), nj(e.y, r.offset.y)), e
                    }
                    removeElementScroll(t) {
                        let e = nN();
                        ii(e, t);
                        for (let r = 0; r < this.path.length; r++) {
                            let n = this.path[r],
                                {
                                    scroll: i,
                                    options: s
                                } = n;
                            if (n !== this.root && i && s.layoutScroll) {
                                if (i.isRoot) {
                                    ii(e, t);
                                    let {
                                        scroll: r
                                    } = this.root;
                                    r && (nj(e.x, -r.offset.x), nj(e.y, -r.offset.y))
                                }
                                nj(e.x, i.offset.x), nj(e.y, i.offset.y)
                            }
                        }
                        return e
                    }
                    applyTransform(t, e = !1) {
                        let r = nN();
                        ii(r, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && nX(r, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), nL(n.latestValues) && nX(r, n.latestValues)
                        }
                        return nL(this.latestValues) && nX(r, this.latestValues), r
                    }
                    removeTransform(t) {
                        let e = nN();
                        ii(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let r = this.path[t];
                            if (!r.instance || !nL(r.latestValues)) continue;
                            nI(r.latestValues) && r.updateSnapshot();
                            let n = nN();
                            ii(n, r.measurePageBox()), il(e, r.latestValues, r.snapshot ? r.snapshot.layoutBox : void 0, n)
                        }
                        return nL(this.latestValues) && il(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== tM.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, r, n, i;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let a = !!this.resumingFrom || this !== s;
                        if (!(t || a && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget)) return;
                        let {
                            layout: o,
                            layoutId: u
                        } = this.options;
                        if (this.layout && (o || u)) {
                            if (this.resolvedRelativeTargetAt = tM.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = nN(), this.relativeTargetOrigin = nN(), nE(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), ii(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = nN(), this.targetWithTransforms = nN()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), r = this.target, n = this.relativeTarget, i = this.relativeParent.target, nv(r.x, n.x, i.x), nv(r.y, n.y, i.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : ii(this.target, this.layout.layoutBox), nB(this.target, this.targetDelta)) : ii(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = nN(), this.relativeTargetOrigin = nN(), nE(this.relativeTargetOrigin, this.target, t.target), ii(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                iT.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || nI(this.parent.latestValues) || nM(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            r = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), r && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === tM.frameData.timestamp && (n = !1), n) return;
                        let {
                            layout: i,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(i || s)) return;
                        ii(this.layoutCorrected, this.layout.layoutBox);
                        let a = this.treeScale.x,
                            o = this.treeScale.y;
                        ! function(t, e, r, n = !1) {
                            let i, s;
                            let a = r.length;
                            if (a) {
                                e.x = e.y = 1;
                                for (let o = 0; o < a; o++) {
                                    s = (i = r[o]).projectionDelta;
                                    let a = i.instance;
                                    (!a || !a.style || "contents" !== a.style.display) && (n && i.options.layoutScroll && i.scroll && i !== i.root && nX(t, {
                                        x: -i.scroll.offset.x,
                                        y: -i.scroll.offset.y
                                    }), s && (e.x *= s.x.scale, e.y *= s.y.scale, nB(t, s)), n && nL(i.latestValues) && nX(t, i.latestValues))
                                }
                                e.x = nV(e.x), e.y = nV(e.y)
                            }
                        }(this.layoutCorrected, this.treeScale, this.path, r), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = nN());
                        let {
                            target: u
                        } = e;
                        if (!u) {
                            this.projectionTransform && (this.projectionDelta = nA(), this.projectionTransform = "none", this.scheduleRender());
                            return
                        }
                        this.projectionDelta || (this.projectionDelta = nA(), this.projectionDeltaWithTransform = nA());
                        let l = this.projectionTransform;
                        ny(this.projectionDelta, this.layoutCorrected, u, this.latestValues), this.projectionTransform = ig(this.projectionDelta, this.treeScale), (this.projectionTransform !== l || this.treeScale.x !== a || this.treeScale.y !== o) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", u)), iT.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        if (this.options.scheduleRender && this.options.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    setAnimationOrigin(t, e = !1) {
                        let r;
                        let n = this.snapshot,
                            i = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            a = nA();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let o = nN(),
                            u = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            l = this.getStack(),
                            c = !l || l.members.length <= 1,
                            h = !!(u && !c && !0 === this.options.crossfade && !this.path.some(i_));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (iV(a.x, t.x, n), iV(a.y, t.y, n), this.setTargetDelta(a), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var l, f, p, d;
                                nE(o, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, d = this.relativeTargetOrigin, ij(p.x, d.x, o.x, n), ij(p.y, d.y, o.y, n), r && (l = this.relativeTarget, f = r, l.x.min === f.x.min && l.x.max === f.x.max && l.y.min === f.y.min && l.y.max === f.y.max) && (this.isProjectionDirty = !1), r || (r = nN()), ii(r, this.relativeTarget)
                            }
                            u && (this.animationValues = s, function(t, e, r, n, i, s) {
                                i ? (t.opacity = rD(0, void 0 !== r.opacity ? r.opacity : 1, n7(n)), t.opacityExit = rD(void 0 !== e.opacity ? e.opacity : 1, 0, it(n))) : s && (t.opacity = rD(void 0 !== e.opacity ? e.opacity : 1, void 0 !== r.opacity ? r.opacity : 1, n));
                                for (let i = 0; i < n6; i++) {
                                    let s = `border${n3[i]}Radius`,
                                        a = n9(e, s),
                                        o = n9(r, s);
                                    (void 0 !== a || void 0 !== o) && (a || (a = 0), o || (o = 0), 0 === a || 0 === o || n4(a) === n4(o) ? (t[s] = Math.max(rD(n8(a), n8(o), n), 0), (tr.test(o) || tr.test(a)) && (t[s] += "%")) : t[s] = o)
                                }(e.rotate || r.rotate) && (t.rotate = rD(e.rotate || 0, r.rotate || 0, n))
                            }(s, i, this.latestValues, n, h, c)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, tM.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = tM.Wi.update(() => {
                            nJ.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, r) {
                                let n = U(0) ? 0 : r4(0);
                                return n.start(rQ("", n, 1e3, r)), n.animation
                            }(0, 0, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: r,
                                layout: n,
                                latestValues: i
                            } = t;
                        if (e && r && n) {
                            if (this !== t && this.layout && n && iH(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                r = this.target || nN();
                                let e = nd(this.layout.layoutBox.x);
                                r.x.min = t.target.x.min, r.x.max = r.x.min + e;
                                let n = nd(this.layout.layoutBox.y);
                                r.y.min = t.target.y.min, r.y.max = r.y.min + n
                            }
                            ii(e, r), nX(e, i), ny(this.projectionDeltaWithTransform, this.layoutCorrected, e, i)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new im), this.sharedNodes.get(t).add(e);
                        let r = e.options.initialPromotionConfig;
                        e.promote({
                            transition: r ? r.transition : void 0,
                            preserveFollowOpacity: r && r.shouldPreserveFollowOpacity ? r.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: r
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, r), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: r
                            } = t;
                        if ((r.z || r.rotate || r.rotateX || r.rotateY || r.rotateZ || r.skewX || r.skewY) && (e = !0), !e) return;
                        let n = {};
                        r.z && iD("z", t, n, this.animationValues);
                        for (let e = 0; e < ib.length; e++) iD(`rotate${ib[e]}`, t, n, this.animationValues), iD(`skew${ib[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, r;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return iE;
                        let n = {
                                visibility: ""
                            },
                            i = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = tI(null == t ? void 0 : t.pointerEvents) || "", n.transform = i ? i(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = tI(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !nL(this.latestValues) && (e.transform = i ? i({}, "") : "none", this.hasProjected = !1), e
                        }
                        let a = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = ig(this.projectionDeltaWithTransform, this.treeScale, a), i && (n.transform = i(a, n.transform));
                        let {
                            x: o,
                            y: u
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*o.origin}% ${100*u.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (r = null !== (e = a.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== r ? r : 1 : this.preserveOpacity ? this.latestValues.opacity : a.opacityExit : n.opacity = s === this ? void 0 !== a.opacity ? a.opacity : "" : void 0 !== a.opacityExit ? a.opacityExit : 0, I) {
                            if (void 0 === a[t]) continue;
                            let {
                                correct: e,
                                applyTo: r
                            } = I[t], i = "none" === n.transform ? a[t] : e(a[t], s);
                            if (r) {
                                let t = r.length;
                                for (let e = 0; e < t; e++) n[r[e]] = i
                            } else n[t] = i
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? tI(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(iC), this.root.sharedNodes.clear()
                    }
                }
            }

            function iS(t) {
                t.updateLayout()
            }

            function iA(t) {
                var e;
                let r = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && r && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: i
                    } = t.options, s = r.source !== t.layout.source;
                    "size" === i ? nP(t => {
                        let n = s ? r.measuredBox[t] : r.layoutBox[t],
                            i = nd(n);
                        n.min = e[t].min, n.max = n.min + i
                    }) : iH(i, r.layoutBox, e) && nP(n => {
                        let i = s ? r.measuredBox[n] : r.layoutBox[n],
                            a = nd(e[n]);
                        i.max = i.min + a, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + a)
                    });
                    let a = nA();
                    ny(a, e, r.layoutBox);
                    let o = nA();
                    s ? ny(o, t.applyTransform(n, !0), r.measuredBox) : ny(o, e, r.layoutBox);
                    let u = !ih(a),
                        l = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: i,
                                layout: s
                            } = n;
                            if (i && s) {
                                let a = nN();
                                nE(a, r.layoutBox, i.layoutBox);
                                let o = nN();
                                nE(o, e, s.layoutBox), ip(a, o) || (l = !0), n.options.layoutRoot && (t.relativeTarget = o, t.relativeTargetOrigin = a, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: r,
                        delta: o,
                        layoutDelta: a,
                        hasLayoutChanged: u,
                        hasRelativeTargetChanged: l
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function iR(t) {
                iT.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function iN(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function iP(t) {
                t.clearSnapshot()
            }

            function iC(t) {
                t.clearMeasurements()
            }

            function iO(t) {
                t.isLayoutDirty = !1
            }

            function iI(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function iL(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function iM(t) {
                t.resolveTargetDelta()
            }

            function ik(t) {
                t.calcProjection()
            }

            function iU(t) {
                t.resetSkewAndRotation()
            }

            function iB(t) {
                t.removeLeadSnapshot()
            }

            function iV(t, e, r) {
                t.translate = rD(e.translate, 0, r), t.scale = rD(e.scale, 1, r), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function ij(t, e, r, n) {
                t.min = rD(e.min, r.min, n), t.max = rD(e.max, r.max, n)
            }

            function i_(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let iq = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                iF = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                iX = iF("applewebkit/") && !iF("chrome/") ? Math.round : t0.Z;

            function iG(t) {
                t.min = iX(t.min), t.max = iX(t.max)
            }

            function iH(t, e, r) {
                return "position" === t || "preserve-aspect" === t && !nm(id(e), id(r), .2)
            }
            let i$ = ix({
                    attachResizeListener: (t, e) => tB(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                iz = {
                    current: void 0
                },
                iW = ix({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!iz.current) {
                            let t = new i$({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), iz.current = t
                        }
                        return iz.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                }),
                iK = {
                    current: null
                },
                iY = {
                    current: !1
                },
                iZ = new WeakMap,
                iJ = [...eR, eF, eY],
                iQ = t => iJ.find(eA(t)),
                i0 = Object.keys(S),
                i1 = i0.length,
                i2 = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
                i5 = E.length;
            class i3 {
                scrapeMotionValuesFromProps(t, e, r) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: r,
                    reducedMotionConfig: n,
                    blockInitialAnimation: i,
                    visualState: s
                }, a = {}) {
                    this.resolveKeyframes = (t, e, r, n) => new this.KeyframeResolver(t, e, r, n, this), this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = eM, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.scheduleRender = () => tM.Wi.render(this.render, !1, !0);
                    let {
                        latestValues: o,
                        renderState: u
                    } = s;
                    this.latestValues = o, this.baseTarget = { ...o
                    }, this.initialValues = e.initial ? { ...o
                    } : {}, this.renderState = u, this.parent = t, this.props = e, this.presenceContext = r, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = a, this.blockInitialAnimation = !!i, this.isControllingVariants = w(e), this.isVariantNode = T(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: l,
                        ...c
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in c) {
                        let e = c[t];
                        void 0 !== o[t] && U(e) && (e.set(o[t], !1), r0(l) && l.add(t))
                    }
                }
                mount(t) {
                    this.current = t, iZ.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), iY.current || function() {
                        if (iY.current = !0, A.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => iK.current = t.matches;
                                t.addListener(e), e()
                            } else iK.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || iK.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    var t;
                    for (let t in iZ.delete(this.current), this.projection && this.projection.unmount(), (0, tM.Pn)(this.notifyUpdate), (0, tM.Pn)(this.render), this.valueSubscriptions.forEach(t => t()), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let e in this.features) null === (t = this.features[e]) || void 0 === t || t.unmount();
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let r = M.has(t),
                        n = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && tM.Wi.preRender(this.notifyUpdate), r && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        i = e.on("renderRequest", this.scheduleRender);
                    this.valueSubscriptions.set(t, () => {
                        n(), i(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                loadFeatures({
                    children: t,
                    ...e
                }, r, n, i) {
                    let s, a;
                    for (let t = 0; t < i1; t++) {
                        let r = i0[t],
                            {
                                isEnabled: n,
                                Feature: i,
                                ProjectionNode: o,
                                MeasureLayout: u
                            } = S[r];
                        o && (s = o), n(e) && (!this.features[r] && i && (this.features[r] = new i(this)), u && (a = u))
                    }
                    if (("html" === this.type || "svg" === this.type) && !this.projection && s) {
                        let {
                            layoutId: t,
                            layout: r,
                            drag: n,
                            dragConstraints: a,
                            layoutScroll: o,
                            layoutRoot: u
                        } = e;
                        this.projection = new s(this.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                            if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                        }(this.parent)), this.projection.setOptions({
                            layoutId: t,
                            layout: r,
                            alwaysMeasureLayout: !!n || a && g(a),
                            visualElement: this,
                            scheduleRender: () => this.scheduleRender(),
                            animationType: "string" == typeof r ? r : "both",
                            initialPromotionConfig: i,
                            layoutScroll: o,
                            layoutRoot: u
                        })
                    }
                    return a
                }
                updateFeatures() {
                    for (let t in this.features) {
                        let e = this.features[t];
                        e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.options, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : nN()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < i2.length; e++) {
                        let r = i2[e];
                        this.propEventSubscriptions[r] && (this.propEventSubscriptions[r](), delete this.propEventSubscriptions[r]);
                        let n = t["on" + r];
                        n && (this.propEventSubscriptions[r] = this.on(r, n))
                    }
                    this.prevMotionValues = function(t, e, r) {
                        let {
                            willChange: n
                        } = e;
                        for (let i in e) {
                            let s = e[i],
                                a = r[i];
                            if (U(s)) t.addValue(i, s), r0(n) && n.add(i);
                            else if (U(a)) t.addValue(i, r4(s, {
                                owner: t
                            })), r0(n) && n.remove(i);
                            else if (a !== s) {
                                if (t.hasValue(i)) {
                                    let e = t.getValue(i);
                                    !0 === e.liveStyle ? e.jump(s) : e.hasAnimated || e.set(s)
                                } else {
                                    let e = t.getStaticValue(i);
                                    t.addValue(i, r4(void 0 !== e ? e : s, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in r) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                getVariantContext(t = !1) {
                    if (t) return this.parent ? this.parent.getVariantContext() : void 0;
                    if (!this.isControllingVariants) {
                        let t = this.parent && this.parent.getVariantContext() || {};
                        return void 0 !== this.props.initial && (t.initial = this.props.initial), t
                    }
                    let e = {};
                    for (let t = 0; t < i5; t++) {
                        let r = E[t],
                            n = this.props[r];
                        (y(n) || !1 === n) && (e[r] = n)
                    }
                    return e
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let r = this.values.get(t);
                    e !== r && (r && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let r = this.values.get(t);
                    return void 0 === r && void 0 !== e && (r = r4(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, r)), r
                }
                readValue(t, e) {
                    var r;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (r = this.getBaseTargetFromProps(this.props, t)) && void 0 !== r ? r : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && (ey(n) || em(n)) ? n = parseFloat(n) : !iQ(n) && eY.test(e) && (n = e5(t, e)), this.setBaseTarget(t, U(n) ? n.get() : n)), U(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let r;
                    let {
                        initial: n
                    } = this.props;
                    if ("string" == typeof n || "object" == typeof n) {
                        let i = tR(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        i && (r = i[t])
                    }
                    if (n && void 0 !== r) return r;
                    let i = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === i || U(i) ? void 0 !== this.initialValues[t] && void 0 === r ? void 0 : this.baseTarget[t] : i
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new r5), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            class i6 extends i3 {
                constructor() {
                    super(...arguments), this.KeyframeResolver = e6
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: r
                }) {
                    delete e[t], delete r[t]
                }
            }
            class i8 extends i6 {
                constructor() {
                    super(...arguments), this.type = "html"
                }
                readValueFromInstance(t, e) {
                    if (M.has(e)) {
                        let t = e2(e);
                        return t && t.default || 0
                    } {
                        let r = window.getComputedStyle(t),
                            n = (_(e) ? r.getPropertyValue(e) : r[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return nG(t, e)
                }
                build(t, e, r, n) {
                    tl(t, e, r, n.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, r) {
                    return tx(t, e, r)
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    U(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
                renderInstance(t, e, r, n) {
                    tw(t, e, r, n)
                }
            }
            class i4 extends i6 {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (M.has(e)) {
                        let t = e2(e);
                        return t && t.default || 0
                    }
                    return e = tT.has(e) ? e : f(e), t.getAttribute(e)
                }
                measureInstanceViewportBox() {
                    return nN()
                }
                scrapeMotionValuesFromProps(t, e, r) {
                    return tS(t, e, r)
                }
                build(t, e, r, n) {
                    tv(t, e, r, this.isSVGTag, n.transformTemplate)
                }
                renderInstance(t, e, r, n) {
                    tD(t, e, r, n)
                }
                mount(t) {
                    this.isSVGTag = tE(t.tagName), super.mount(t)
                }
            }
            let i9 = (t, e) => O(t) ? new i4(e, {
                    enableHardwareAcceleration: !1
                }) : new i8(e, {
                    allowProjection: t !== a.Fragment,
                    enableHardwareAcceleration: !0
                }),
                i7 = {
                    animation: {
                        Feature: ns
                    },
                    exit: {
                        Feature: no
                    },
                    inView: {
                        Feature: t9
                    },
                    tap: {
                        Feature: t2
                    },
                    focus: {
                        Feature: tJ
                    },
                    hover: {
                        Feature: tZ
                    },
                    pan: {
                        Feature: nZ
                    },
                    drag: {
                        Feature: nK,
                        ProjectionNode: iW,
                        MeasureLayout: n2
                    },
                    layout: {
                        ProjectionNode: iW,
                        MeasureLayout: n2
                    }
                },
                st = function(t) {
                    function e(e, r = {}) {
                        return function({
                            preloadedFeatures: t,
                            createVisualElement: e,
                            useRender: r,
                            useVisualState: n,
                            Component: i
                        }) {
                            t && function(t) {
                                for (let e in t) S[e] = { ...S[e],
                                    ...t[e]
                                }
                            }(t);
                            let f = (0, a.forwardRef)(function(f, m) {
                                var v;
                                let b;
                                let E = { ...(0, a.useContext)(o._),
                                        ...f,
                                        layoutId: function({
                                            layoutId: t
                                        }) {
                                            let e = (0, a.useContext)(R.p).id;
                                            return e && void 0 !== t ? e + "-" + t : t
                                        }(f)
                                    },
                                    {
                                        isStatic: T
                                    } = E,
                                    x = function(t) {
                                        let {
                                            initial: e,
                                            animate: r
                                        } = function(t, e) {
                                            if (w(t)) {
                                                let {
                                                    initial: e,
                                                    animate: r
                                                } = t;
                                                return {
                                                    initial: !1 === e || y(e) ? e : void 0,
                                                    animate: y(r) ? r : void 0
                                                }
                                            }
                                            return !1 !== t.inherit ? e : {}
                                        }(t, (0, a.useContext)(u));
                                        return (0, a.useMemo)(() => ({
                                            initial: e,
                                            animate: r
                                        }), [D(e), D(r)])
                                    }(f),
                                    S = n(f, T);
                                if (!T && A.j) {
                                    x.visualElement = function(t, e, r, n) {
                                        let {
                                            visualElement: i
                                        } = (0, a.useContext)(u), s = (0, a.useContext)(h), f = (0, a.useContext)(l.O), m = (0, a.useContext)(o._).reducedMotion, g = (0, a.useRef)();
                                        n = n || s.renderer, !g.current && n && (g.current = n(t, {
                                            visualState: e,
                                            parent: i,
                                            props: r,
                                            presenceContext: f,
                                            blockInitialAnimation: !!f && !1 === f.initial,
                                            reducedMotionConfig: m
                                        }));
                                        let y = g.current;
                                        (0, a.useInsertionEffect)(() => {
                                            y && y.update(r, f)
                                        });
                                        let v = (0, a.useRef)(!!(r[p] && !window.HandoffComplete));
                                        return (0, c.L)(() => {
                                            y && (d.render(y.render), v.current && y.animationState && y.animationState.animateChanges())
                                        }), (0, a.useEffect)(() => {
                                            y && (y.updateFeatures(), !v.current && y.animationState && y.animationState.animateChanges(), v.current && (v.current = !1, window.HandoffComplete = !0))
                                        }), y
                                    }(i, S, E, e);
                                    let r = (0, a.useContext)(N),
                                        n = (0, a.useContext)(h).strict;
                                    x.visualElement && (b = x.visualElement.loadFeatures(E, n, t, r))
                                }
                                return (0, s.jsxs)(u.Provider, {
                                    value: x,
                                    children: [b && x.visualElement ? (0, s.jsx)(b, {
                                        visualElement: x.visualElement,
                                        ...E
                                    }) : null, r(i, f, (v = x.visualElement, (0, a.useCallback)(t => {
                                        t && S.mount && S.mount(t), v && (t ? v.mount(t) : v.unmount()), m && ("function" == typeof m ? m(t) : g(m) && (m.current = t))
                                    }, [v])), S, T, x.visualElement)]
                                })
                            });
                            return f[P] = i, f
                        }(t(e, r))
                    }
                    if ("undefined" == typeof Proxy) return e;
                    let r = new Map;
                    return new Proxy(e, {
                        get: (t, n) => (r.has(n) || r.set(n, e(n)), r.get(n))
                    })
                }((t, e) => (function(t, {
                    forwardMotionProps: e = !1
                }, r, n) {
                    return { ...O(t) ? tk : tU,
                        preloadedFeatures: r,
                        useRender: function(t = !1) {
                            return (e, r, n, {
                                latestValues: i
                            }, s) => {
                                let o = (O(e) ? function(t, e, r, n) {
                                        let i = (0, a.useMemo)(() => {
                                            let r = tb();
                                            return tv(r, e, {
                                                enableHardwareAcceleration: !1
                                            }, tE(n), t.transformTemplate), { ...r.attrs,
                                                style: { ...r.style
                                                }
                                            }
                                        }, [e]);
                                        if (t.style) {
                                            let e = {};
                                            th(e, t.style, t), i.style = { ...e,
                                                ...i.style
                                            }
                                        }
                                        return i
                                    } : function(t, e, r) {
                                        let n = {},
                                            i = function(t, e, r) {
                                                let n = t.style || {},
                                                    i = {};
                                                return th(i, n, t), Object.assign(i, function({
                                                    transformTemplate: t
                                                }, e, r) {
                                                    return (0, a.useMemo)(() => {
                                                        let n = tc();
                                                        return tl(n, e, {
                                                            enableHardwareAcceleration: !r
                                                        }, t), Object.assign({}, n.vars, n.style)
                                                    }, [e])
                                                }(t, e, r)), i
                                            }(t, e, r);
                                        return t.drag && !1 !== t.dragListener && (n.draggable = !1, i.userSelect = i.WebkitUserSelect = i.WebkitTouchCallout = "none", i.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (n.tabIndex = 0), n.style = i, n
                                    })(r, i, s, e),
                                    u = function(t, e, r) {
                                        let n = {};
                                        for (let i in t)("values" !== i || "object" != typeof t.values) && (td(i) || !0 === r && tp(i) || !e && !tp(i) || t.draggable && i.startsWith("onDrag")) && (n[i] = t[i]);
                                        return n
                                    }(r, "string" == typeof e, t),
                                    l = e !== a.Fragment ? { ...u,
                                        ...o,
                                        ref: n
                                    } : {},
                                    {
                                        children: c
                                    } = r,
                                    h = (0, a.useMemo)(() => U(c) ? c.get() : c, [c]);
                                return (0, a.createElement)(e, { ...l,
                                    children: h
                                })
                            }
                        }(e),
                        createVisualElement: n,
                        Component: t
                    }
                })(t, e, i7, i9))
        },
        565: function(t, e, r) {
            "use strict";
            r.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        9047: function(t, e, r) {
            "use strict";
            r.d(e, {
                K: function() {
                    return i
                },
                k: function() {
                    return s
                }
            });
            var n = r(9276);
            let i = n.Z,
                s = n.Z
        },
        7282: function(t, e, r) {
            "use strict";
            r.d(e, {
                j: function() {
                    return n
                }
            });
            let n = "undefined" != typeof document
        },
        9276: function(t, e, r) {
            "use strict";
            r.d(e, {
                Z: function() {
                    return n
                }
            });
            let n = t => t
        },
        458: function(t, e, r) {
            "use strict";
            r.d(e, {
                h: function() {
                    return i
                }
            });
            var n = r(2265);

            function i(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        9033: function(t, e, r) {
            "use strict";
            r.d(e, {
                L: function() {
                    return i
                }
            });
            var n = r(2265);
            let i = r(7282).j ? n.useLayoutEffect : n.useEffect
        }
    }
]);