"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [194], {
        7138: function(t, e, i) {
            i.d(e, {
                default: function() {
                    return r.a
                }
            });
            var n = i(231),
                r = i.n(n)
        },
        844: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "addLocale", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), i(8157);
            let n = function(t) {
                for (var e = arguments.length, i = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) i[n - 1] = arguments[n];
                return t
            };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        5944: function(t, e, i) {
            function n(t, e, i, n) {
                return !1
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getDomainLocale", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), i(8157), ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        231: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "default", {
                enumerable: !0,
                get: function() {
                    return P
                }
            });
            let n = i(9920),
                r = i(7437),
                s = n._(i(2265)),
                o = i(8016),
                a = i(8029),
                l = i(1142),
                u = i(3461),
                h = i(844),
                c = i(291),
                d = i(4467),
                p = i(323),
                f = i(5944),
                m = i(4897),
                g = i(1507),
                v = new Set;

            function y(t, e, i, n, r, s) {
                if ("undefined" != typeof window && (s || (0, a.isLocalURL)(e))) {
                    if (!n.bypassPrefetchedCheck) {
                        let r = e + "%" + i + "%" + (void 0 !== n.locale ? n.locale : "locale" in t ? t.locale : void 0);
                        if (v.has(r)) return;
                        v.add(r)
                    }
                    Promise.resolve(s ? t.prefetch(e, r) : t.prefetch(e, i, n)).catch(t => {})
                }
            }

            function x(t) {
                return "string" == typeof t ? t : (0, l.formatUrl)(t)
            }
            let P = s.default.forwardRef(function(t, e) {
                let i, n;
                let {
                    href: l,
                    as: v,
                    children: P,
                    prefetch: b = null,
                    passHref: w,
                    replace: T,
                    shallow: S,
                    scroll: A,
                    locale: E,
                    onClick: R,
                    onMouseEnter: M,
                    onTouchStart: C,
                    legacyBehavior: V = !1,
                    ...j
                } = t;
                i = P, V && ("string" == typeof i || "number" == typeof i) && (i = (0, r.jsx)("a", {
                    children: i
                }));
                let k = s.default.useContext(c.RouterContext),
                    D = s.default.useContext(d.AppRouterContext),
                    L = null != k ? k : D,
                    O = !k,
                    F = !1 !== b,
                    B = null === b ? g.PrefetchKind.AUTO : g.PrefetchKind.FULL,
                    {
                        href: I,
                        as: U
                    } = s.default.useMemo(() => {
                        if (!k) {
                            let t = x(l);
                            return {
                                href: t,
                                as: v ? x(v) : t
                            }
                        }
                        let [t, e] = (0, o.resolveHref)(k, l, !0);
                        return {
                            href: t,
                            as: v ? (0, o.resolveHref)(k, v) : e || t
                        }
                    }, [k, l, v]),
                    N = s.default.useRef(I),
                    W = s.default.useRef(U);
                V && (n = s.default.Children.only(i));
                let _ = V ? n && "object" == typeof n && n.ref : e,
                    [$, z, K] = (0, p.useIntersection)({
                        rootMargin: "200px"
                    }),
                    H = s.default.useCallback(t => {
                        (W.current !== U || N.current !== I) && (K(), W.current = U, N.current = I), $(t), _ && ("function" == typeof _ ? _(t) : "object" == typeof _ && (_.current = t))
                    }, [U, _, I, K, $]);
                s.default.useEffect(() => {
                    L && z && F && y(L, I, U, {
                        locale: E
                    }, {
                        kind: B
                    }, O)
                }, [U, I, z, E, F, null == k ? void 0 : k.locale, L, O, B]);
                let Y = {
                    ref: H,
                    onClick(t) {
                        V || "function" != typeof R || R(t), V && n.props && "function" == typeof n.props.onClick && n.props.onClick(t), L && !t.defaultPrevented && function(t, e, i, n, r, o, l, u, h) {
                            let {
                                nodeName: c
                            } = t.currentTarget;
                            if ("A" === c.toUpperCase() && (function(t) {
                                    let e = t.currentTarget.getAttribute("target");
                                    return e && "_self" !== e || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which
                                }(t) || !h && !(0, a.isLocalURL)(i))) return;
                            t.preventDefault();
                            let d = () => {
                                let t = null == l || l;
                                "beforePopState" in e ? e[r ? "replace" : "push"](i, n, {
                                    shallow: o,
                                    locale: u,
                                    scroll: t
                                }) : e[r ? "replace" : "push"](n || i, {
                                    scroll: t
                                })
                            };
                            h ? s.default.startTransition(d) : d()
                        }(t, L, I, U, T, S, A, E, O)
                    },
                    onMouseEnter(t) {
                        V || "function" != typeof M || M(t), V && n.props && "function" == typeof n.props.onMouseEnter && n.props.onMouseEnter(t), L && (F || !O) && y(L, I, U, {
                            locale: E,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: B
                        }, O)
                    },
                    onTouchStart: function(t) {
                        V || "function" != typeof C || C(t), V && n.props && "function" == typeof n.props.onTouchStart && n.props.onTouchStart(t), L && (F || !O) && y(L, I, U, {
                            locale: E,
                            priority: !0,
                            bypassPrefetchedCheck: !0
                        }, {
                            kind: B
                        }, O)
                    }
                };
                if ((0, u.isAbsoluteUrl)(U)) Y.href = U;
                else if (!V || w || "a" === n.type && !("href" in n.props)) {
                    let t = void 0 !== E ? E : null == k ? void 0 : k.locale,
                        e = (null == k ? void 0 : k.isLocaleDomain) && (0, f.getDomainLocale)(U, t, null == k ? void 0 : k.locales, null == k ? void 0 : k.domainLocales);
                    Y.href = e || (0, m.addBasePath)((0, h.addLocale)(U, t, null == k ? void 0 : k.defaultLocale))
                }
                return V ? s.default.cloneElement(n, Y) : (0, r.jsx)("a", { ...j,
                    ...Y,
                    children: i
                })
            });
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        9189: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    cancelIdleCallback: function() {
                        return n
                    },
                    requestIdleCallback: function() {
                        return i
                    }
                });
            let i = "undefined" != typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(t) {
                    let e = Date.now();
                    return self.setTimeout(function() {
                        t({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - e))
                            }
                        })
                    }, 1)
                },
                n = "undefined" != typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(t) {
                    return clearTimeout(t)
                };
            ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        8016: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "resolveHref", {
                enumerable: !0,
                get: function() {
                    return c
                }
            });
            let n = i(8323),
                r = i(1142),
                s = i(5519),
                o = i(3461),
                a = i(8157),
                l = i(8029),
                u = i(9195),
                h = i(20);

            function c(t, e, i) {
                let c;
                let d = "string" == typeof e ? e : (0, r.formatWithValidation)(e),
                    p = d.match(/^[a-zA-Z]{1,}:\/\//),
                    f = p ? d.slice(p[0].length) : d;
                if ((f.split("?", 1)[0] || "").match(/(\/\/|\\)/)) {
                    console.error("Invalid href '" + d + "' passed to next/router in page: '" + t.pathname + "'. Repeated forward-slashes (//) or backslashes \\ are not valid in the href.");
                    let e = (0, o.normalizeRepeatedSlashes)(f);
                    d = (p ? p[0] : "") + e
                }
                if (!(0, l.isLocalURL)(d)) return i ? [d] : d;
                try {
                    c = new URL(d.startsWith("#") ? t.asPath : t.pathname, "http://n")
                } catch (t) {
                    c = new URL("/", "http://n")
                }
                try {
                    let t = new URL(d, c);
                    t.pathname = (0, a.normalizePathTrailingSlash)(t.pathname);
                    let e = "";
                    if ((0, u.isDynamicRoute)(t.pathname) && t.searchParams && i) {
                        let i = (0, n.searchParamsToUrlQuery)(t.searchParams),
                            {
                                result: o,
                                params: a
                            } = (0, h.interpolateAs)(t.pathname, t.pathname, i);
                        o && (e = (0, r.formatWithValidation)({
                            pathname: o,
                            hash: t.hash,
                            query: (0, s.omit)(i, a)
                        }))
                    }
                    let o = t.origin === c.origin ? t.href.slice(t.origin.length) : t.href;
                    return i ? [o, e || o] : o
                } catch (t) {
                    return i ? [d] : d
                }
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        323: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "useIntersection", {
                enumerable: !0,
                get: function() {
                    return l
                }
            });
            let n = i(2265),
                r = i(9189),
                s = "function" == typeof IntersectionObserver,
                o = new Map,
                a = [];

            function l(t) {
                let {
                    rootRef: e,
                    rootMargin: i,
                    disabled: l
                } = t, u = l || !s, [h, c] = (0, n.useState)(!1), d = (0, n.useRef)(null), p = (0, n.useCallback)(t => {
                    d.current = t
                }, []);
                return (0, n.useEffect)(() => {
                    if (s) {
                        if (u || h) return;
                        let t = d.current;
                        if (t && t.tagName) return function(t, e, i) {
                            let {
                                id: n,
                                observer: r,
                                elements: s
                            } = function(t) {
                                let e;
                                let i = {
                                        root: t.root || null,
                                        margin: t.rootMargin || ""
                                    },
                                    n = a.find(t => t.root === i.root && t.margin === i.margin);
                                if (n && (e = o.get(n))) return e;
                                let r = new Map;
                                return e = {
                                    id: i,
                                    observer: new IntersectionObserver(t => {
                                        t.forEach(t => {
                                            let e = r.get(t.target),
                                                i = t.isIntersecting || t.intersectionRatio > 0;
                                            e && i && e(i)
                                        })
                                    }, t),
                                    elements: r
                                }, a.push(i), o.set(i, e), e
                            }(i);
                            return s.set(t, e), r.observe(t),
                                function() {
                                    if (s.delete(t), r.unobserve(t), 0 === s.size) {
                                        r.disconnect(), o.delete(n);
                                        let t = a.findIndex(t => t.root === n.root && t.margin === n.margin);
                                        t > -1 && a.splice(t, 1)
                                    }
                                }
                        }(t, t => t && c(t), {
                            root: null == e ? void 0 : e.current,
                            rootMargin: i
                        })
                    } else if (!h) {
                        let t = (0, r.requestIdleCallback)(() => c(!0));
                        return () => (0, r.cancelIdleCallback)(t)
                    }
                }, [u, i, e, h, d.current]), [p, h, (0, n.useCallback)(() => {
                    c(!1)
                }, [])]
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        1943: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "escapeStringRegexp", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let i = /[|\\{}()[\]^$+*?.-]/,
                n = /[|\\{}()[\]^$+*?.-]/g;

            function r(t) {
                return i.test(t) ? t.replace(n, "\\$&") : t
            }
        },
        291: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "RouterContext", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = i(9920)._(i(2265)).default.createContext(null)
        },
        1142: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    formatUrl: function() {
                        return s
                    },
                    formatWithValidation: function() {
                        return a
                    },
                    urlObjectKeys: function() {
                        return o
                    }
                });
            let n = i(1452)._(i(8323)),
                r = /https?|ftp|gopher|file/;

            function s(t) {
                let {
                    auth: e,
                    hostname: i
                } = t, s = t.protocol || "", o = t.pathname || "", a = t.hash || "", l = t.query || "", u = !1;
                e = e ? encodeURIComponent(e).replace(/%3A/i, ":") + "@" : "", t.host ? u = e + t.host : i && (u = e + (~i.indexOf(":") ? "[" + i + "]" : i), t.port && (u += ":" + t.port)), l && "object" == typeof l && (l = String(n.urlQueryToSearchParams(l)));
                let h = t.search || l && "?" + l || "";
                return s && !s.endsWith(":") && (s += ":"), t.slashes || (!s || r.test(s)) && !1 !== u ? (u = "//" + (u || ""), o && "/" !== o[0] && (o = "/" + o)) : u || (u = ""), a && "#" !== a[0] && (a = "#" + a), h && "?" !== h[0] && (h = "?" + h), "" + s + u + (o = o.replace(/[?#]/g, encodeURIComponent)) + (h = h.replace("#", "%23")) + a
            }
            let o = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

            function a(t) {
                return s(t)
            }
        },
        9195: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    getSortedRoutes: function() {
                        return n.getSortedRoutes
                    },
                    isDynamicRoute: function() {
                        return r.isDynamicRoute
                    }
                });
            let n = i(9089),
                r = i(8083)
        },
        20: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "interpolateAs", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = i(1533),
                r = i(3169);

            function s(t, e, i) {
                let s = "",
                    o = (0, r.getRouteRegex)(t),
                    a = o.groups,
                    l = (e !== t ? (0, n.getRouteMatcher)(o)(e) : "") || i;
                s = t;
                let u = Object.keys(a);
                return u.every(t => {
                    let e = l[t] || "",
                        {
                            repeat: i,
                            optional: n
                        } = a[t],
                        r = "[" + (i ? "..." : "") + t + "]";
                    return n && (r = (e ? "" : "/") + "[" + r + "]"), i && !Array.isArray(e) && (e = [e]), (n || t in l) && (s = s.replace(r, i ? e.map(t => encodeURIComponent(t)).join("/") : encodeURIComponent(e)) || "/")
                }) || (s = ""), {
                    params: u,
                    result: s
                }
            }
        },
        8083: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isDynamicRoute", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = i(2269),
                r = /\/\[[^/]+?\](?=\/|$)/;

            function s(t) {
                return (0, n.isInterceptionRouteAppPath)(t) && (t = (0, n.extractInterceptionRouteInformation)(t).interceptedRoute), r.test(t)
            }
        },
        8029: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "isLocalURL", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let n = i(3461),
                r = i(9404);

            function s(t) {
                if (!(0, n.isAbsoluteUrl)(t)) return !0;
                try {
                    let e = (0, n.getLocationOrigin)(),
                        i = new URL(t, e);
                    return i.origin === e && (0, r.hasBasePath)(i.pathname)
                } catch (t) {
                    return !1
                }
            }
        },
        5519: function(t, e) {
            function i(t, e) {
                let i = {};
                return Object.keys(t).forEach(n => {
                    e.includes(n) || (i[n] = t[n])
                }), i
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "omit", {
                enumerable: !0,
                get: function() {
                    return i
                }
            })
        },
        8323: function(t, e) {
            function i(t) {
                let e = {};
                return t.forEach((t, i) => {
                    void 0 === e[i] ? e[i] = t : Array.isArray(e[i]) ? e[i].push(t) : e[i] = [e[i], t]
                }), e
            }

            function n(t) {
                return "string" != typeof t && ("number" != typeof t || isNaN(t)) && "boolean" != typeof t ? "" : String(t)
            }

            function r(t) {
                let e = new URLSearchParams;
                return Object.entries(t).forEach(t => {
                    let [i, r] = t;
                    Array.isArray(r) ? r.forEach(t => e.append(i, n(t))) : e.set(i, n(r))
                }), e
            }

            function s(t) {
                for (var e = arguments.length, i = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) i[n - 1] = arguments[n];
                return i.forEach(e => {
                    Array.from(e.keys()).forEach(e => t.delete(e)), e.forEach((e, i) => t.append(i, e))
                }), t
            }
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    assign: function() {
                        return s
                    },
                    searchParamsToUrlQuery: function() {
                        return i
                    },
                    urlQueryToSearchParams: function() {
                        return r
                    }
                })
        },
        1533: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getRouteMatcher", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let n = i(3461);

            function r(t) {
                let {
                    re: e,
                    groups: i
                } = t;
                return t => {
                    let r = e.exec(t);
                    if (!r) return !1;
                    let s = t => {
                            try {
                                return decodeURIComponent(t)
                            } catch (t) {
                                throw new n.DecodeError("failed to decode param")
                            }
                        },
                        o = {};
                    return Object.keys(i).forEach(t => {
                        let e = i[t],
                            n = r[e.pos];
                        void 0 !== n && (o[t] = ~n.indexOf("/") ? n.split("/").map(t => s(t)) : e.repeat ? [s(n)] : s(n))
                    }), o
                }
            }
        },
        3169: function(t, e, i) {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    getNamedMiddlewareRegex: function() {
                        return d
                    },
                    getNamedRouteRegex: function() {
                        return c
                    },
                    getRouteRegex: function() {
                        return l
                    }
                });
            let n = i(2269),
                r = i(1943),
                s = i(7741);

            function o(t) {
                let e = t.startsWith("[") && t.endsWith("]");
                e && (t = t.slice(1, -1));
                let i = t.startsWith("...");
                return i && (t = t.slice(3)), {
                    key: t,
                    repeat: i,
                    optional: e
                }
            }

            function a(t) {
                let e = (0, s.removeTrailingSlash)(t).slice(1).split("/"),
                    i = {},
                    a = 1;
                return {
                    parameterizedRoute: e.map(t => {
                        let e = n.INTERCEPTION_ROUTE_MARKERS.find(e => t.startsWith(e)),
                            s = t.match(/\[((?:\[.*\])|.+)\]/);
                        if (e && s) {
                            let {
                                key: t,
                                optional: n,
                                repeat: l
                            } = o(s[1]);
                            return i[t] = {
                                pos: a++,
                                repeat: l,
                                optional: n
                            }, "/" + (0, r.escapeStringRegexp)(e) + "([^/]+?)"
                        }
                        if (!s) return "/" + (0, r.escapeStringRegexp)(t); {
                            let {
                                key: t,
                                repeat: e,
                                optional: n
                            } = o(s[1]);
                            return i[t] = {
                                pos: a++,
                                repeat: e,
                                optional: n
                            }, e ? n ? "(?:/(.+?))?" : "/(.+?)" : "/([^/]+?)"
                        }
                    }).join(""),
                    groups: i
                }
            }

            function l(t) {
                let {
                    parameterizedRoute: e,
                    groups: i
                } = a(t);
                return {
                    re: RegExp("^" + e + "(?:/)?$"),
                    groups: i
                }
            }

            function u(t) {
                let {
                    interceptionMarker: e,
                    getSafeRouteKey: i,
                    segment: n,
                    routeKeys: s,
                    keyPrefix: a
                } = t, {
                    key: l,
                    optional: u,
                    repeat: h
                } = o(n), c = l.replace(/\W/g, "");
                a && (c = "" + a + c);
                let d = !1;
                (0 === c.length || c.length > 30) && (d = !0), isNaN(parseInt(c.slice(0, 1))) || (d = !0), d && (c = i()), a ? s[c] = "" + a + l : s[c] = l;
                let p = e ? (0, r.escapeStringRegexp)(e) : "";
                return h ? u ? "(?:/" + p + "(?<" + c + ">.+?))?" : "/" + p + "(?<" + c + ">.+?)" : "/" + p + "(?<" + c + ">[^/]+?)"
            }

            function h(t, e) {
                let i;
                let o = (0, s.removeTrailingSlash)(t).slice(1).split("/"),
                    a = (i = 0, () => {
                        let t = "",
                            e = ++i;
                        for (; e > 0;) t += String.fromCharCode(97 + (e - 1) % 26), e = Math.floor((e - 1) / 26);
                        return t
                    }),
                    l = {};
                return {
                    namedParameterizedRoute: o.map(t => {
                        let i = n.INTERCEPTION_ROUTE_MARKERS.some(e => t.startsWith(e)),
                            s = t.match(/\[((?:\[.*\])|.+)\]/);
                        if (i && s) {
                            let [i] = t.split(s[0]);
                            return u({
                                getSafeRouteKey: a,
                                interceptionMarker: i,
                                segment: s[1],
                                routeKeys: l,
                                keyPrefix: e ? "nxtI" : void 0
                            })
                        }
                        return s ? u({
                            getSafeRouteKey: a,
                            segment: s[1],
                            routeKeys: l,
                            keyPrefix: e ? "nxtP" : void 0
                        }) : "/" + (0, r.escapeStringRegexp)(t)
                    }).join(""),
                    routeKeys: l
                }
            }

            function c(t, e) {
                let i = h(t, e);
                return { ...l(t),
                    namedRegex: "^" + i.namedParameterizedRoute + "(?:/)?$",
                    routeKeys: i.routeKeys
                }
            }

            function d(t, e) {
                let {
                    parameterizedRoute: i
                } = a(t), {
                    catchAll: n = !0
                } = e;
                if ("/" === i) return {
                    namedRegex: "^/" + (n ? ".*" : "") + "$"
                };
                let {
                    namedParameterizedRoute: r
                } = h(t, !1);
                return {
                    namedRegex: "^" + r + (n ? "(?:(/.*)?)" : "") + "$"
                }
            }
        },
        9089: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), Object.defineProperty(e, "getSortedRoutes", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            class i {
                insert(t) {
                    this._insert(t.split("/").filter(Boolean), [], !1)
                }
                smoosh() {
                    return this._smoosh()
                }
                _smoosh(t) {
                    void 0 === t && (t = "/");
                    let e = [...this.children.keys()].sort();
                    null !== this.slugName && e.splice(e.indexOf("[]"), 1), null !== this.restSlugName && e.splice(e.indexOf("[...]"), 1), null !== this.optionalRestSlugName && e.splice(e.indexOf("[[...]]"), 1);
                    let i = e.map(e => this.children.get(e)._smoosh("" + t + e + "/")).reduce((t, e) => [...t, ...e], []);
                    if (null !== this.slugName && i.push(...this.children.get("[]")._smoosh(t + "[" + this.slugName + "]/")), !this.placeholder) {
                        let e = "/" === t ? "/" : t.slice(0, -1);
                        if (null != this.optionalRestSlugName) throw Error('You cannot define a route with the same specificity as a optional catch-all route ("' + e + '" and "' + e + "[[..." + this.optionalRestSlugName + ']]").');
                        i.unshift(e)
                    }
                    return null !== this.restSlugName && i.push(...this.children.get("[...]")._smoosh(t + "[..." + this.restSlugName + "]/")), null !== this.optionalRestSlugName && i.push(...this.children.get("[[...]]")._smoosh(t + "[[..." + this.optionalRestSlugName + "]]/")), i
                }
                _insert(t, e, n) {
                    if (0 === t.length) {
                        this.placeholder = !1;
                        return
                    }
                    if (n) throw Error("Catch-all must be the last part of the URL.");
                    let r = t[0];
                    if (r.startsWith("[") && r.endsWith("]")) {
                        let i = r.slice(1, -1),
                            o = !1;
                        if (i.startsWith("[") && i.endsWith("]") && (i = i.slice(1, -1), o = !0), i.startsWith("...") && (i = i.substring(3), n = !0), i.startsWith("[") || i.endsWith("]")) throw Error("Segment names may not start or end with extra brackets ('" + i + "').");
                        if (i.startsWith(".")) throw Error("Segment names may not start with erroneous periods ('" + i + "').");

                        function s(t, i) {
                            if (null !== t && t !== i) throw Error("You cannot use different slug names for the same dynamic path ('" + t + "' !== '" + i + "').");
                            e.forEach(t => {
                                if (t === i) throw Error('You cannot have the same slug name "' + i + '" repeat within a single dynamic path');
                                if (t.replace(/\W/g, "") === r.replace(/\W/g, "")) throw Error('You cannot have the slug names "' + t + '" and "' + i + '" differ only by non-word symbols within a single dynamic path')
                            }), e.push(i)
                        }
                        if (n) {
                            if (o) {
                                if (null != this.restSlugName) throw Error('You cannot use both an required and optional catch-all route at the same level ("[...' + this.restSlugName + ']" and "' + t[0] + '" ).');
                                s(this.optionalRestSlugName, i), this.optionalRestSlugName = i, r = "[[...]]"
                            } else {
                                if (null != this.optionalRestSlugName) throw Error('You cannot use both an optional and required catch-all route at the same level ("[[...' + this.optionalRestSlugName + ']]" and "' + t[0] + '").');
                                s(this.restSlugName, i), this.restSlugName = i, r = "[...]"
                            }
                        } else {
                            if (o) throw Error('Optional route parameters are not yet supported ("' + t[0] + '").');
                            s(this.slugName, i), this.slugName = i, r = "[]"
                        }
                    }
                    this.children.has(r) || this.children.set(r, new i), this.children.get(r)._insert(t.slice(1), e, n)
                }
                constructor() {
                    this.placeholder = !0, this.children = new Map, this.slugName = null, this.restSlugName = null, this.optionalRestSlugName = null
                }
            }

            function n(t) {
                let e = new i;
                return t.forEach(t => e.insert(t)), e.smoosh()
            }
        },
        3461: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function(t, e) {
                    for (var i in e) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: e[i]
                    })
                }(e, {
                    DecodeError: function() {
                        return f
                    },
                    MiddlewareNotFoundError: function() {
                        return y
                    },
                    MissingStaticPage: function() {
                        return v
                    },
                    NormalizeError: function() {
                        return m
                    },
                    PageNotFoundError: function() {
                        return g
                    },
                    SP: function() {
                        return d
                    },
                    ST: function() {
                        return p
                    },
                    WEB_VITALS: function() {
                        return i
                    },
                    execOnce: function() {
                        return n
                    },
                    getDisplayName: function() {
                        return l
                    },
                    getLocationOrigin: function() {
                        return o
                    },
                    getURL: function() {
                        return a
                    },
                    isAbsoluteUrl: function() {
                        return s
                    },
                    isResSent: function() {
                        return u
                    },
                    loadGetInitialProps: function() {
                        return c
                    },
                    normalizeRepeatedSlashes: function() {
                        return h
                    },
                    stringifyError: function() {
                        return x
                    }
                });
            let i = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

            function n(t) {
                let e, i = !1;
                return function() {
                    for (var n = arguments.length, r = Array(n), s = 0; s < n; s++) r[s] = arguments[s];
                    return i || (i = !0, e = t(...r)), e
                }
            }
            let r = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
                s = t => r.test(t);

            function o() {
                let {
                    protocol: t,
                    hostname: e,
                    port: i
                } = window.location;
                return t + "//" + e + (i ? ":" + i : "")
            }

            function a() {
                let {
                    href: t
                } = window.location, e = o();
                return t.substring(e.length)
            }

            function l(t) {
                return "string" == typeof t ? t : t.displayName || t.name || "Unknown"
            }

            function u(t) {
                return t.finished || t.headersSent
            }

            function h(t) {
                let e = t.split("?");
                return e[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (e[1] ? "?" + e.slice(1).join("?") : "")
            }
            async function c(t, e) {
                let i = e.res || e.ctx && e.ctx.res;
                if (!t.getInitialProps) return e.ctx && e.Component ? {
                    pageProps: await c(e.Component, e.ctx)
                } : {};
                let n = await t.getInitialProps(e);
                if (i && u(i)) return n;
                if (!n) throw Error('"' + l(t) + '.getInitialProps()" should resolve to an object. But found "' + n + '" instead.');
                return n
            }
            let d = "undefined" != typeof performance,
                p = d && ["mark", "measure", "getEntriesByName"].every(t => "function" == typeof performance[t]);
            class f extends Error {}
            class m extends Error {}
            class g extends Error {
                constructor(t) {
                    super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = "Cannot find module for page: " + t
                }
            }
            class v extends Error {
                constructor(t, e) {
                    super(), this.message = "Failed to load static file for page: " + t + " " + e
                }
            }
            class y extends Error {
                constructor() {
                    super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
                }
            }

            function x(t) {
                return JSON.stringify({
                    message: t.message,
                    stack: t.stack
                })
            }
        },
        5127: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return y
                }
            });
            var n = i(7437),
                r = i(2265),
                s = i(9033);

            function o() {
                let t = (0, r.useRef)(!1);
                return (0, s.L)(() => (t.current = !0, () => {
                    t.current = !1
                }), []), t
            }
            var a = i(6219),
                l = i(7797),
                u = i(458),
                h = i(9791);
            class c extends r.Component {
                getSnapshotBeforeUpdate(t) {
                    let e = this.props.childRef.current;
                    if (e && t.isPresent && !this.props.isPresent) {
                        let t = this.props.sizeRef.current;
                        t.height = e.offsetHeight || 0, t.width = e.offsetWidth || 0, t.top = e.offsetTop, t.left = e.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function d({
                children: t,
                isPresent: e
            }) {
                let i = (0, r.useId)(),
                    s = (0, r.useRef)(null),
                    o = (0, r.useRef)({
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0
                    }),
                    {
                        nonce: a
                    } = (0, r.useContext)(h._);
                return (0, r.useInsertionEffect)(() => {
                    let {
                        width: t,
                        height: n,
                        top: r,
                        left: l
                    } = o.current;
                    if (e || !s.current || !t || !n) return;
                    s.current.dataset.motionPopId = i;
                    let u = document.createElement("style");
                    return a && (u.nonce = a), document.head.appendChild(u), u.sheet && u.sheet.insertRule(`
          [data-motion-pop-id="${i}"] {
            position: absolute !important;
            width: ${t}px !important;
            height: ${n}px !important;
            top: ${r}px !important;
            left: ${l}px !important;
          }
        `), () => {
                        document.head.removeChild(u)
                    }
                }, [e]), (0, n.jsx)(c, {
                    isPresent: e,
                    childRef: s,
                    sizeRef: o,
                    children: r.cloneElement(t, {
                        ref: s
                    })
                })
            }
            let p = ({
                children: t,
                initial: e,
                isPresent: i,
                onExitComplete: s,
                custom: o,
                presenceAffectsLayout: a,
                mode: h
            }) => {
                let c = (0, u.h)(f),
                    p = (0, r.useId)(),
                    m = (0, r.useMemo)(() => ({
                        id: p,
                        initial: e,
                        isPresent: i,
                        custom: o,
                        onExitComplete: t => {
                            for (let e of (c.set(t, !0), c.values()))
                                if (!e) return;
                            s && s()
                        },
                        register: t => (c.set(t, !1), () => c.delete(t))
                    }), a ? [Math.random()] : [i]);
                return (0, r.useMemo)(() => {
                    c.forEach((t, e) => c.set(e, !1))
                }, [i]), r.useEffect(() => {
                    i || c.size || !s || s()
                }, [i]), "popLayout" === h && (t = (0, n.jsx)(d, {
                    isPresent: i,
                    children: t
                })), (0, n.jsx)(l.O.Provider, {
                    value: m,
                    children: t
                })
            };

            function f() {
                return new Map
            }
            var m = i(5050),
                g = i(9047);
            let v = t => t.key || "",
                y = ({
                    children: t,
                    custom: e,
                    initial: i = !0,
                    onExitComplete: l,
                    exitBeforeEnter: u,
                    presenceAffectsLayout: h = !0,
                    mode: c = "sync"
                }) => {
                    var d;
                    (0, g.k)(!u, "Replace exitBeforeEnter with mode='wait'");
                    let f = (0, r.useContext)(m.p).forceRender || function() {
                            let t = o(),
                                [e, i] = (0, r.useState)(0),
                                n = (0, r.useCallback)(() => {
                                    t.current && i(e + 1)
                                }, [e]);
                            return [(0, r.useCallback)(() => a.Wi.postRender(n), [n]), e]
                        }()[0],
                        y = o(),
                        x = function(t) {
                            let e = [];
                            return r.Children.forEach(t, t => {
                                (0, r.isValidElement)(t) && e.push(t)
                            }), e
                        }(t),
                        P = x,
                        b = (0, r.useRef)(new Map).current,
                        w = (0, r.useRef)(P),
                        T = (0, r.useRef)(new Map).current,
                        S = (0, r.useRef)(!0);
                    if ((0, s.L)(() => {
                            S.current = !1,
                                function(t, e) {
                                    t.forEach(t => {
                                        let i = v(t);
                                        e.set(i, t)
                                    })
                                }(x, T), w.current = P
                        }), d = () => {
                            S.current = !0, T.clear(), b.clear()
                        }, (0, r.useEffect)(() => () => d(), []), S.current) return (0, n.jsx)(n.Fragment, {
                        children: P.map(t => (0, n.jsx)(p, {
                            isPresent: !0,
                            initial: !!i && void 0,
                            presenceAffectsLayout: h,
                            mode: c,
                            children: t
                        }, v(t)))
                    });
                    P = [...P];
                    let A = w.current.map(v),
                        E = x.map(v),
                        R = A.length;
                    for (let t = 0; t < R; t++) {
                        let e = A[t]; - 1 !== E.indexOf(e) || b.has(e) || b.set(e, void 0)
                    }
                    return "wait" === c && b.size && (P = []), b.forEach((t, i) => {
                        if (-1 !== E.indexOf(i)) return;
                        let r = T.get(i);
                        if (!r) return;
                        let s = A.indexOf(i),
                            o = t;
                        o || (o = (0, n.jsx)(p, {
                            isPresent: !1,
                            onExitComplete: () => {
                                b.delete(i);
                                let t = Array.from(T.keys()).filter(t => !E.includes(t));
                                if (t.forEach(t => T.delete(t)), w.current = x.filter(e => {
                                        let n = v(e);
                                        return n === i || t.includes(n)
                                    }), !b.size) {
                                    if (!1 === y.current) return;
                                    f(), l && l()
                                }
                            },
                            custom: e,
                            presenceAffectsLayout: h,
                            mode: c,
                            children: r
                        }, v(r)), b.set(i, o)), P.splice(s, 0, o)
                    }), P = P.map(t => {
                        let e = t.key;
                        return b.has(e) ? t : (0, n.jsx)(p, {
                            isPresent: !0,
                            presenceAffectsLayout: h,
                            mode: c,
                            children: t
                        }, v(t))
                    }), (0, n.jsx)(n.Fragment, {
                        children: b.size ? P : P.map(t => (0, r.cloneElement)(t))
                    })
                }
        },
        5050: function(t, e, i) {
            i.d(e, {
                p: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({})
        },
        9791: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        7797: function(t, e, i) {
            i.d(e, {
                O: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)(null)
        },
        2981: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return o
                }
            });
            var n = i(565);
            class r {
                constructor() {
                    this.order = [], this.scheduled = new Set
                }
                add(t) {
                    if (!this.scheduled.has(t)) return this.scheduled.add(t), this.order.push(t), !0
                }
                remove(t) {
                    let e = this.order.indexOf(t); - 1 !== e && (this.order.splice(e, 1), this.scheduled.delete(t))
                }
                clear() {
                    this.order.length = 0, this.scheduled.clear()
                }
            }
            let s = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function o(t, e) {
                let i = !1,
                    o = !0,
                    a = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    l = s.reduce((t, e) => (t[e] = function(t) {
                        let e = new r,
                            i = new r,
                            n = 0,
                            s = !1,
                            o = !1,
                            a = new WeakSet,
                            l = {
                                schedule: (t, r = !1, o = !1) => {
                                    let l = o && s,
                                        u = l ? e : i;
                                    return r && a.add(t), u.add(t) && l && s && (n = e.order.length), t
                                },
                                cancel: t => {
                                    i.remove(t), a.delete(t)
                                },
                                process: r => {
                                    if (s) {
                                        o = !0;
                                        return
                                    }
                                    if (s = !0, [e, i] = [i, e], i.clear(), n = e.order.length)
                                        for (let i = 0; i < n; i++) {
                                            let n = e.order[i];
                                            a.has(n) && (l.schedule(n), t()), n(r)
                                        }
                                    s = !1, o && (o = !1, l.process(r))
                                }
                            };
                        return l
                    }(() => i = !0), t), {}),
                    u = t => {
                        l[t].process(a)
                    },
                    h = () => {
                        let r = n.c.useManualTiming ? a.timestamp : performance.now();
                        i = !1, a.delta = o ? 1e3 / 60 : Math.max(Math.min(r - a.timestamp, 40), 1), a.timestamp = r, a.isProcessing = !0, s.forEach(u), a.isProcessing = !1, i && e && (o = !1, t(h))
                    },
                    c = () => {
                        i = !0, o = !0, a.isProcessing || t(h)
                    };
                return {
                    schedule: s.reduce((t, e) => {
                        let n = l[e];
                        return t[e] = (t, e = !1, r = !1) => (i || c(), n.schedule(t, e, r)), t
                    }, {}),
                    cancel: t => s.forEach(e => l[e].cancel(t)),
                    state: a,
                    steps: l
                }
            }
        },
        6219: function(t, e, i) {
            i.d(e, {
                Pn: function() {
                    return s
                },
                S6: function() {
                    return a
                },
                Wi: function() {
                    return r
                },
                frameData: function() {
                    return o
                }
            });
            var n = i(9276);
            let {
                schedule: r,
                cancel: s,
                state: o,
                steps: a
            } = (0, i(2981).Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.Z, !0)
        },
        4599: function(t, e, i) {
            let n;
            i.d(e, {
                E: function() {
                    return st
                }
            });
            var r, s = i(7437),
                o = i(2265),
                a = i(9791);
            let l = (0, o.createContext)({});
            var u = i(7797),
                h = i(9033);
            let c = (0, o.createContext)({
                    strict: !1
                }),
                d = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
                p = "data-" + d("framerAppearId"),
                {
                    schedule: f,
                    cancel: m
                } = (0, i(2981).Z)(queueMicrotask, !1);

            function g(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }

            function v(t) {
                return "string" == typeof t || Array.isArray(t)
            }

            function y(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
            let x = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                P = ["initial", ...x];

            function b(t) {
                return y(t.animate) || P.some(e => v(t[e]))
            }

            function w(t) {
                return !!(b(t) || t.variants)
            }

            function T(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            let S = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                A = {};
            for (let t in S) A[t] = {
                isEnabled: e => S[t].some(t => !!e[t])
            };
            var E = i(7282),
                R = i(5050);
            let M = (0, o.createContext)({}),
                C = Symbol.for("motionComponentSymbol"),
                V = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function j(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (V.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }
            let k = {},
                D = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                L = new Set(D);

            function O(t, {
                layout: e,
                layoutId: i
            }) {
                return L.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!k[t] || "opacity" === t)
            }
            let F = t => !!(t && t.getVelocity),
                B = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                I = D.length,
                U = t => e => "string" == typeof e && e.startsWith(t),
                N = U("--"),
                W = U("var(--"),
                _ = t => !!W(t) && $.test(t.split("/*")[0].trim()),
                $ = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
                z = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
                K = (t, e, i) => i > e ? e : i < t ? t : i,
                H = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                Y = { ...H,
                    transform: t => K(0, 1, t)
                },
                Z = { ...H,
                    default: 1
                },
                q = t => Math.round(1e5 * t) / 1e5,
                X = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
                G = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
                Q = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;

            function J(t) {
                return "string" == typeof t
            }
            let tt = t => ({
                    test: e => J(e) && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                te = tt("deg"),
                ti = tt("%"),
                tn = tt("px"),
                tr = tt("vh"),
                ts = tt("vw"),
                to = { ...ti,
                    parse: t => ti.parse(t) / 100,
                    transform: t => ti.transform(100 * t)
                },
                ta = { ...H,
                    transform: Math.round
                },
                tl = {
                    borderWidth: tn,
                    borderTopWidth: tn,
                    borderRightWidth: tn,
                    borderBottomWidth: tn,
                    borderLeftWidth: tn,
                    borderRadius: tn,
                    radius: tn,
                    borderTopLeftRadius: tn,
                    borderTopRightRadius: tn,
                    borderBottomRightRadius: tn,
                    borderBottomLeftRadius: tn,
                    width: tn,
                    maxWidth: tn,
                    height: tn,
                    maxHeight: tn,
                    size: tn,
                    top: tn,
                    right: tn,
                    bottom: tn,
                    left: tn,
                    padding: tn,
                    paddingTop: tn,
                    paddingRight: tn,
                    paddingBottom: tn,
                    paddingLeft: tn,
                    margin: tn,
                    marginTop: tn,
                    marginRight: tn,
                    marginBottom: tn,
                    marginLeft: tn,
                    rotate: te,
                    rotateX: te,
                    rotateY: te,
                    rotateZ: te,
                    scale: Z,
                    scaleX: Z,
                    scaleY: Z,
                    scaleZ: Z,
                    skew: te,
                    skewX: te,
                    skewY: te,
                    distance: tn,
                    translateX: tn,
                    translateY: tn,
                    translateZ: tn,
                    x: tn,
                    y: tn,
                    z: tn,
                    perspective: tn,
                    transformPerspective: tn,
                    opacity: Y,
                    originX: to,
                    originY: to,
                    originZ: tn,
                    zIndex: ta,
                    backgroundPositionX: tn,
                    backgroundPositionY: tn,
                    fillOpacity: Y,
                    strokeOpacity: Y,
                    numOctaves: ta
                };

            function tu(t, e, i, n) {
                let {
                    style: r,
                    vars: s,
                    transform: o,
                    transformOrigin: a
                } = t, l = !1, u = !1, h = !0;
                for (let t in e) {
                    let i = e[t];
                    if (N(t)) {
                        s[t] = i;
                        continue
                    }
                    let n = tl[t],
                        c = z(i, n);
                    if (L.has(t)) {
                        if (l = !0, o[t] = c, !h) continue;
                        i !== (n.default || 0) && (h = !1)
                    } else t.startsWith("origin") ? (u = !0, a[t] = c) : r[t] = c
                }
                if (!e.transform && (l || n ? r.transform = function(t, {
                        enableHardwareAcceleration: e = !0,
                        allowTransformNone: i = !0
                    }, n, r) {
                        let s = "";
                        for (let e = 0; e < I; e++) {
                            let i = D[e];
                            if (void 0 !== t[i]) {
                                let e = B[i] || i;
                                s += `${e}(${t[i]}) `
                            }
                        }
                        return e && !t.z && (s += "translateZ(0)"), s = s.trim(), r ? s = r(t, n ? "" : s) : i && n && (s = "none"), s
                    }(t.transform, i, h, n) : r.transform && (r.transform = "none")), u) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = a;
                    r.transformOrigin = `${t} ${e} ${i}`
                }
            }
            let th = () => ({
                style: {},
                transform: {},
                transformOrigin: {},
                vars: {}
            });

            function tc(t, e, i) {
                for (let n in e) F(e[n]) || O(n, i) || (t[n] = e[n])
            }
            let td = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function tp(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || td.has(t)
            }
            let tf = t => !tp(t);
            try {
                (r = require("@emotion/is-prop-valid").default) && (tf = t => t.startsWith("on") ? !tp(t) : r(t))
            } catch (t) {}

            function tm(t, e, i) {
                return "string" == typeof t ? t : tn.transform(e + i * t)
            }
            let tg = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                tv = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function ty(t, {
                attrX: e,
                attrY: i,
                attrScale: n,
                originX: r,
                originY: s,
                pathLength: o,
                pathSpacing: a = 1,
                pathOffset: l = 0,
                ...u
            }, h, c, d) {
                if (tu(t, u, h, d), c) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: p,
                    style: f,
                    dimensions: m
                } = t;
                p.transform && (m && (f.transform = p.transform), delete p.transform), m && (void 0 !== r || void 0 !== s || f.transform) && (f.transformOrigin = function(t, e, i) {
                    let n = tm(e, t.x, t.width),
                        r = tm(i, t.y, t.height);
                    return `${n} ${r}`
                }(m, void 0 !== r ? r : .5, void 0 !== s ? s : .5)), void 0 !== e && (p.x = e), void 0 !== i && (p.y = i), void 0 !== n && (p.scale = n), void 0 !== o && function(t, e, i = 1, n = 0, r = !0) {
                    t.pathLength = 1;
                    let s = r ? tg : tv;
                    t[s.offset] = tn.transform(-n);
                    let o = tn.transform(e),
                        a = tn.transform(i);
                    t[s.array] = `${o} ${a}`
                }(p, o, a, l, !1)
            }
            let tx = () => ({ ...th(),
                    attrs: {}
                }),
                tP = t => "string" == typeof t && "svg" === t.toLowerCase();

            function tb(t, {
                style: e,
                vars: i
            }, n, r) {
                for (let s in Object.assign(t.style, e, r && r.getProjectionStyles(n)), i) t.style.setProperty(s, i[s])
            }
            let tw = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

            function tT(t, e, i, n) {
                for (let i in tb(t, e, void 0, n), e.attrs) t.setAttribute(tw.has(i) ? i : d(i), e.attrs[i])
            }

            function tS(t, e, i) {
                var n;
                let {
                    style: r
                } = t, s = {};
                for (let o in r)(F(r[o]) || e.style && F(e.style[o]) || O(o, t) || (null === (n = null == i ? void 0 : i.getValue(o)) || void 0 === n ? void 0 : n.liveStyle) !== void 0) && (s[o] = r[o]);
                return s
            }

            function tA(t, e, i) {
                let n = tS(t, e, i);
                for (let i in t)(F(t[i]) || F(e[i])) && (n[-1 !== D.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return n
            }

            function tE(t) {
                let e = [{}, {}];
                return null == t || t.values.forEach((t, i) => {
                    e[0][i] = t.get(), e[1][i] = t.getVelocity()
                }), e
            }

            function tR(t, e, i, n) {
                if ("function" == typeof e) {
                    let [r, s] = tE(n);
                    e = e(void 0 !== i ? i : t.custom, r, s)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    let [r, s] = tE(n);
                    e = e(void 0 !== i ? i : t.custom, r, s)
                }
                return e
            }
            var tM = i(458);
            let tC = t => Array.isArray(t),
                tV = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                tj = t => tC(t) ? t[t.length - 1] || 0 : t;

            function tk(t) {
                let e = F(t) ? t.get() : t;
                return tV(e) ? e.toValue() : e
            }
            let tD = t => (e, i) => {
                let n = (0, o.useContext)(l),
                    r = (0, o.useContext)(u.O),
                    s = () => (function({
                        scrapeMotionValuesFromProps: t,
                        createRenderState: e,
                        onMount: i
                    }, n, r, s) {
                        let o = {
                            latestValues: function(t, e, i, n) {
                                let r = {},
                                    s = n(t, {});
                                for (let t in s) r[t] = tk(s[t]);
                                let {
                                    initial: o,
                                    animate: a
                                } = t, l = b(t), u = w(t);
                                e && u && !l && !1 !== t.inherit && (void 0 === o && (o = e.initial), void 0 === a && (a = e.animate));
                                let h = !!i && !1 === i.initial,
                                    c = (h = h || !1 === o) ? a : o;
                                return c && "boolean" != typeof c && !y(c) && (Array.isArray(c) ? c : [c]).forEach(e => {
                                    let i = tR(t, e);
                                    if (!i) return;
                                    let {
                                        transitionEnd: n,
                                        transition: s,
                                        ...o
                                    } = i;
                                    for (let t in o) {
                                        let e = o[t];
                                        if (Array.isArray(e)) {
                                            let t = h ? e.length - 1 : 0;
                                            e = e[t]
                                        }
                                        null !== e && (r[t] = e)
                                    }
                                    for (let t in n) r[t] = n[t]
                                }), r
                            }(n, r, s, t),
                            renderState: e()
                        };
                        return i && (o.mount = t => i(n, t, o)), o
                    })(t, e, n, r);
                return i ? s() : (0, tM.h)(s)
            };
            var tL = i(6219);
            let tO = {
                    useVisualState: tD({
                        scrapeMotionValuesFromProps: tA,
                        createRenderState: tx,
                        onMount: (t, e, {
                            renderState: i,
                            latestValues: n
                        }) => {
                            tL.Wi.read(() => {
                                try {
                                    i.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    i.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), tL.Wi.render(() => {
                                ty(i, n, {
                                    enableHardwareAcceleration: !1
                                }, tP(e.tagName), t.transformTemplate), tT(e, i)
                            })
                        }
                    })
                },
                tF = {
                    useVisualState: tD({
                        scrapeMotionValuesFromProps: tS,
                        createRenderState: th
                    })
                };

            function tB(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }
            let tI = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

            function tU(t, e = "page") {
                return {
                    point: {
                        x: t[`${e}X`],
                        y: t[`${e}Y`]
                    }
                }
            }
            let tN = t => e => tI(e) && t(e, tU(e));

            function tW(t, e, i, n) {
                return tB(t, e, tN(i), n)
            }
            let t_ = (t, e) => i => e(t(i)),
                t$ = (...t) => t.reduce(t_);

            function tz(t) {
                let e = null;
                return () => null === e && (e = t, () => {
                    e = null
                })
            }
            let tK = tz("dragHorizontal"),
                tH = tz("dragVertical");

            function tY(t) {
                let e = !1;
                if ("y" === t) e = tH();
                else if ("x" === t) e = tK();
                else {
                    let t = tK(),
                        i = tH();
                    t && i ? e = () => {
                        t(), i()
                    } : (t && t(), i && i())
                }
                return e
            }

            function tZ() {
                let t = tY(!0);
                return !t || (t(), !1)
            }
            class tq {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }

            function tX(t, e) {
                let i = e ? "onHoverStart" : "onHoverEnd";
                return tW(t.current, e ? "pointerenter" : "pointerleave", (n, r) => {
                    if ("touch" === n.pointerType || tZ()) return;
                    let s = t.getProps();
                    t.animationState && s.whileHover && t.animationState.setActive("whileHover", e);
                    let o = s[i];
                    o && tL.Wi.postRender(() => o(n, r))
                }, {
                    passive: !t.getProps()[i]
                })
            }
            class tG extends tq {
                mount() {
                    this.unmount = t$(tX(this.node, !0), tX(this.node, !1))
                }
                unmount() {}
            }
            class tQ extends tq {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = t$(tB(this.node.current, "focus", () => this.onFocus()), tB(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            let tJ = (t, e) => !!e && (t === e || tJ(t, e.parentElement));
            var t0 = i(9276);

            function t1(t, e) {
                if (!e) return;
                let i = new PointerEvent("pointer" + t);
                e(i, tU(i))
            }
            class t2 extends tq {
                constructor() {
                    super(...arguments), this.removeStartListeners = t0.Z, this.removeEndListeners = t0.Z, this.removeAccessibleListeners = t0.Z, this.startPointerPress = (t, e) => {
                        if (this.isPressing) return;
                        this.removeEndListeners();
                        let i = this.node.getProps(),
                            n = tW(window, "pointerup", (t, e) => {
                                if (!this.checkPressEnd()) return;
                                let {
                                    onTap: i,
                                    onTapCancel: n,
                                    globalTapTarget: r
                                } = this.node.getProps(), s = r || tJ(this.node.current, t.target) ? i : n;
                                s && tL.Wi.update(() => s(t, e))
                            }, {
                                passive: !(i.onTap || i.onPointerUp)
                            }),
                            r = tW(window, "pointercancel", (t, e) => this.cancelPress(t, e), {
                                passive: !(i.onTapCancel || i.onPointerCancel)
                            });
                        this.removeEndListeners = t$(n, r), this.startPress(t, e)
                    }, this.startAccessiblePress = () => {
                        let t = tB(this.node.current, "keydown", t => {
                                "Enter" !== t.key || this.isPressing || (this.removeEndListeners(), this.removeEndListeners = tB(this.node.current, "keyup", t => {
                                    "Enter" === t.key && this.checkPressEnd() && t1("up", (t, e) => {
                                        let {
                                            onTap: i
                                        } = this.node.getProps();
                                        i && tL.Wi.postRender(() => i(t, e))
                                    })
                                }), t1("down", (t, e) => {
                                    this.startPress(t, e)
                                }))
                            }),
                            e = tB(this.node.current, "blur", () => {
                                this.isPressing && t1("cancel", (t, e) => this.cancelPress(t, e))
                            });
                        this.removeAccessibleListeners = t$(t, e)
                    }
                }
                startPress(t, e) {
                    this.isPressing = !0;
                    let {
                        onTapStart: i,
                        whileTap: n
                    } = this.node.getProps();
                    n && this.node.animationState && this.node.animationState.setActive("whileTap", !0), i && tL.Wi.postRender(() => i(t, e))
                }
                checkPressEnd() {
                    return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !tZ()
                }
                cancelPress(t, e) {
                    if (!this.checkPressEnd()) return;
                    let {
                        onTapCancel: i
                    } = this.node.getProps();
                    i && tL.Wi.postRender(() => i(t, e))
                }
                mount() {
                    let t = this.node.getProps(),
                        e = tW(t.globalTapTarget ? window : this.node.current, "pointerdown", this.startPointerPress, {
                            passive: !(t.onTapStart || t.onPointerStart)
                        }),
                        i = tB(this.node.current, "focus", this.startAccessiblePress);
                    this.removeStartListeners = t$(e, i)
                }
                unmount() {
                    this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners()
                }
            }
            let t5 = new WeakMap,
                t3 = new WeakMap,
                t9 = t => {
                    let e = t5.get(t.target);
                    e && e(t)
                },
                t6 = t => {
                    t.forEach(t9)
                },
                t4 = {
                    some: 0,
                    all: 1
                };
            class t7 extends tq {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: i,
                        amount: n = "some",
                        once: r
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: i,
                        threshold: "number" == typeof n ? n : t4[n]
                    };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            t3.has(i) || t3.set(i, {});
                            let n = t3.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(t6, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return t5.set(t, i), n.observe(t), () => {
                            t5.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: i,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? i : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return i => t[i] !== e[i]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }

            function t8(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }

            function et(t, e, i) {
                let n = t.getProps();
                return tR(n, e, void 0 !== i ? i : n.custom, t)
            }
            let ee = t => 1e3 * t,
                ei = t => t / 1e3,
                en = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                er = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                es = {
                    type: "keyframes",
                    duration: .8
                },
                eo = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                ea = (t, {
                    keyframes: e
                }) => e.length > 2 ? es : L.has(t) ? t.startsWith("scale") ? er(e[1]) : en : eo;

            function el(t, e) {
                return t[e] || t.default || t
            }
            var eu = i(565);
            let eh = {
                    current: !1
                },
                ec = t => null !== t;

            function ed(t, {
                repeat: e,
                repeatType: i = "loop"
            }, n) {
                let r = t.filter(ec),
                    s = e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
                return s && void 0 !== n ? n : r[s]
            }

            function ep() {
                n = void 0
            }
            let ef = {
                    now: () => (void 0 === n && ef.set(tL.frameData.isProcessing || eu.c.useManualTiming ? tL.frameData.timestamp : performance.now()), n),
                    set: t => {
                        n = t, queueMicrotask(ep)
                    }
                },
                em = t => /^0[^.\s]+$/u.test(t);
            var eg = i(9047);
            let ev = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t),
                ey = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u,
                ex = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                eP = t => t === H || t === tn,
                eb = (t, e) => parseFloat(t.split(", ")[e]),
                ew = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/u);
                    if (r) return eb(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? eb(e[1], t) : 0
                    }
                },
                eT = new Set(["x", "y", "z"]),
                eS = D.filter(t => !eT.has(t)),
                eA = {
                    width: ({
                        x: t
                    }, {
                        paddingLeft: e = "0",
                        paddingRight: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    height: ({
                        y: t
                    }, {
                        paddingTop: e = "0",
                        paddingBottom: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    top: (t, {
                        top: e
                    }) => parseFloat(e),
                    left: (t, {
                        left: e
                    }) => parseFloat(e),
                    bottom: ({
                        y: t
                    }, {
                        top: e
                    }) => parseFloat(e) + (t.max - t.min),
                    right: ({
                        x: t
                    }, {
                        left: e
                    }) => parseFloat(e) + (t.max - t.min),
                    x: ew(4, 13),
                    y: ew(5, 14)
                };
            eA.translateX = eA.x, eA.translateY = eA.y;
            let eE = t => e => e.test(t),
                eR = [H, tn, ti, te, ts, tr, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                eM = t => eR.find(eE(t)),
                eC = new Set,
                eV = !1,
                ej = !1;

            function ek() {
                if (ej) {
                    let t = Array.from(eC).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        let e = function(t) {
                            let e = [];
                            return eS.forEach(i => {
                                let n = t.getValue(i);
                                void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                            }), e
                        }(t);
                        e.length && (i.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = i.get(t);
                        e && e.forEach(([e, i]) => {
                            var n;
                            null === (n = t.getValue(e)) || void 0 === n || n.set(i)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                ej = !1, eV = !1, eC.forEach(t => t.complete()), eC.clear()
            }

            function eD() {
                eC.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (ej = !0)
                })
            }
            class eL {
                constructor(t, e, i, n, r, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = r, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (eC.add(this), eV || (eV = !0, tL.Wi.read(eD), tL.Wi.resolveKeyframes(ek))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r]) {
                            if (0 === r) {
                                let r = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (i && e) {
                                    let n = i.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === r && n.set(t[0])
                            } else t[r] = t[r - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), eC.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, eC.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
            let eO = (t, e) => i => !!(J(i) && Q.test(i) && i.startsWith(t) || e && Object.prototype.hasOwnProperty.call(i, e)),
                eF = (t, e, i) => n => {
                    if (!J(n)) return n;
                    let [r, s, o, a] = n.match(X);
                    return {
                        [t]: parseFloat(r),
                        [e]: parseFloat(s),
                        [i]: parseFloat(o),
                        alpha: void 0 !== a ? parseFloat(a) : 1
                    }
                },
                eB = t => K(0, 255, t),
                eI = { ...H,
                    transform: t => Math.round(eB(t))
                },
                eU = {
                    test: eO("rgb", "red"),
                    parse: eF("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: n = 1
                    }) => "rgba(" + eI.transform(t) + ", " + eI.transform(e) + ", " + eI.transform(i) + ", " + q(Y.transform(n)) + ")"
                },
                eN = {
                    test: eO("#"),
                    parse: function(t) {
                        let e = "",
                            i = "",
                            n = "",
                            r = "";
                        return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), r = t.substring(4, 5), e += e, i += i, n += n, r += r), {
                            red: parseInt(e, 16),
                            green: parseInt(i, 16),
                            blue: parseInt(n, 16),
                            alpha: r ? parseInt(r, 16) / 255 : 1
                        }
                    },
                    transform: eU.transform
                },
                eW = {
                    test: eO("hsl", "hue"),
                    parse: eF("hue", "saturation", "lightness"),
                    transform: ({
                        hue: t,
                        saturation: e,
                        lightness: i,
                        alpha: n = 1
                    }) => "hsla(" + Math.round(t) + ", " + ti.transform(q(e)) + ", " + ti.transform(q(i)) + ", " + q(Y.transform(n)) + ")"
                },
                e_ = {
                    test: t => eU.test(t) || eN.test(t) || eW.test(t),
                    parse: t => eU.test(t) ? eU.parse(t) : eW.test(t) ? eW.parse(t) : eN.parse(t),
                    transform: t => J(t) ? t : t.hasOwnProperty("red") ? eU.transform(t) : eW.transform(t)
                },
                e$ = "number",
                ez = "color",
                eK = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function eH(t) {
                let e = t.toString(),
                    i = [],
                    n = {
                        color: [],
                        number: [],
                        var: []
                    },
                    r = [],
                    s = 0,
                    o = e.replace(eK, t => (e_.test(t) ? (n.color.push(s), r.push(ez), i.push(e_.parse(t))) : t.startsWith("var(") ? (n.var.push(s), r.push("var"), i.push(t)) : (n.number.push(s), r.push(e$), i.push(parseFloat(t))), ++s, "${}")).split("${}");
                return {
                    values: i,
                    split: o,
                    indexes: n,
                    types: r
                }
            }

            function eY(t) {
                return eH(t).values
            }

            function eZ(t) {
                let {
                    split: e,
                    types: i
                } = eH(t), n = e.length;
                return t => {
                    let r = "";
                    for (let s = 0; s < n; s++)
                        if (r += e[s], void 0 !== t[s]) {
                            let e = i[s];
                            e === e$ ? r += q(t[s]) : e === ez ? r += e_.transform(t[s]) : r += t[s]
                        }
                    return r
                }
            }
            let eq = t => "number" == typeof t ? 0 : t,
                eX = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && J(t) && ((null === (e = t.match(X)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(G)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: eY,
                    createTransformer: eZ,
                    getAnimatableNone: function(t) {
                        let e = eY(t);
                        return eZ(t)(e.map(eq))
                    }
                },
                eG = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function eQ(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(X) || [];
                if (!n) return t;
                let r = i.replace(n, ""),
                    s = eG.has(e) ? 1 : 0;
                return n !== i && (s *= 100), e + "(" + s + r + ")"
            }
            let eJ = /\b([a-z-]*)\(.*?\)/gu,
                e0 = { ...eX,
                    getAnimatableNone: t => {
                        let e = t.match(eJ);
                        return e ? e.map(eQ).join(" ") : t
                    }
                },
                e1 = { ...tl,
                    color: e_,
                    backgroundColor: e_,
                    outlineColor: e_,
                    fill: e_,
                    stroke: e_,
                    borderColor: e_,
                    borderTopColor: e_,
                    borderRightColor: e_,
                    borderBottomColor: e_,
                    borderLeftColor: e_,
                    filter: e0,
                    WebkitFilter: e0
                },
                e2 = t => e1[t];

            function e5(t, e) {
                let i = e2(t);
                return i !== e0 && (i = eX), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
            let e3 = new Set(["auto", "none", "0"]);
            class e9 extends eL {
                constructor(t, e, i, n) {
                    super(t, e, i, n, null == n ? void 0 : n.owner, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let n = t[i];
                        if ("string" == typeof n && _(n = n.trim())) {
                            let r = function t(e, i, n = 1) {
                                (0, eg.k)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [r, s] = function(t) {
                                    let e = ey.exec(t);
                                    if (!e) return [, ];
                                    let [, i, n, r] = e;
                                    return [`--${null!=i?i:n}`, r]
                                }(e);
                                if (!r) return;
                                let o = window.getComputedStyle(i).getPropertyValue(r);
                                if (o) {
                                    let t = o.trim();
                                    return ev(t) ? parseFloat(t) : t
                                }
                                return _(s) ? t(s, i, n + 1) : s
                            }(n, e.current);
                            void 0 !== r && (t[i] = r), i === t.length - 1 && (this.finalKeyframe = n)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !ex.has(i) || 2 !== t.length) return;
                    let [n, r] = t, s = eM(n), o = eM(r);
                    if (s !== o) {
                        if (eP(s) && eP(o))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var n;
                        ("number" == typeof(n = t[e]) ? 0 === n : null === n || "none" === n || "0" === n || em(n)) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let n, r = 0;
                        for (; r < t.length && !n;) {
                            let e = t[r];
                            "string" == typeof e && !e3.has(e) && eH(e).values.length && (n = t[r]), r++
                        }
                        if (n && i)
                            for (let r of e) t[r] = e5(i, n)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = eA[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(i, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: i,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e.current) return;
                    let r = e.getValue(i);
                    r && r.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        o = n[s];
                    n[s] = eA[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, i]) => {
                        e.getValue(t).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }

            function e6(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
            let e4 = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (eX.test(t) || "0" === t) && !t.startsWith("url("));
            class e7 {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: n = 0,
                    repeatDelay: r = 0,
                    repeatType: s = "loop",
                    ...o
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: n,
                        repeatDelay: r,
                        repeatType: s,
                        ...o
                    }, this.updateFinishedPromise()
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (eD(), ek()), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.hasAttemptedResolve = !0;
                    let {
                        name: i,
                        type: n,
                        velocity: r,
                        delay: s,
                        onComplete: o,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && ! function(t, e, i, n) {
                            let r = t[0];
                            if (null === r) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            let s = t[t.length - 1],
                                o = e4(r, e),
                                a = e4(s, e);
                            return (0, eg.K)(o === a, `You are trying to animate ${e} from "${r}" to "${s}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${s} via the \`style\` property.`), !!o && !!a && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let i = 0; i < t.length; i++)
                                    if (t[i] !== e) return !0
                            }(t) || "spring" === i && n)
                        }(t, i, n, r)) {
                        if (eh.current || !s) {
                            null == a || a(ed(t, this.options, e)), null == o || o(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let u = this.initPlayback(t, e);
                    !1 !== u && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...u
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }

            function e8(t, e, i) {
                var n, r;
                let s = Math.max(e - 5, 0);
                return n = i - t(s), (r = e - s) ? 1e3 / r * n : 0
            }

            function it(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            let ie = ["duration", "bounce"],
                ii = ["stiffness", "damping", "mass"];

            function ir(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function is({
                keyframes: t,
                restDelta: e,
                restSpeed: i,
                ...n
            }) {
                let r;
                let s = t[0],
                    o = t[t.length - 1],
                    a = {
                        done: !1,
                        value: s
                    },
                    {
                        stiffness: l,
                        damping: u,
                        mass: h,
                        duration: c,
                        velocity: d,
                        isResolvedFromDuration: p
                    } = function(t) {
                        let e = {
                            velocity: 0,
                            stiffness: 100,
                            damping: 10,
                            mass: 1,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!ir(t, ii) && ir(t, ie)) {
                            let i = function({
                                duration: t = 800,
                                bounce: e = .25,
                                velocity: i = 0,
                                mass: n = 1
                            }) {
                                let r, s;
                                (0, eg.K)(t <= ee(10), "Spring duration must be 10 seconds or less");
                                let o = 1 - e;
                                o = K(.05, 1, o), t = K(.01, 10, ei(t)), o < 1 ? (r = e => {
                                    let n = e * o,
                                        r = n * t;
                                    return .001 - (n - i) / it(e, o) * Math.exp(-r)
                                }, s = e => {
                                    let n = e * o * t,
                                        s = Math.pow(o, 2) * Math.pow(e, 2) * t,
                                        a = it(Math.pow(e, 2), o);
                                    return (n * i + i - s) * Math.exp(-n) * (-r(e) + .001 > 0 ? -1 : 1) / a
                                }) : (r = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), s = e => t * t * (i - e) * Math.exp(-e * t));
                                let a = function(t, e, i) {
                                    let n = i;
                                    for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                    return n
                                }(r, s, 5 / t);
                                if (t = ee(t), isNaN(a)) return {
                                    stiffness: 100,
                                    damping: 10,
                                    duration: t
                                }; {
                                    let e = Math.pow(a, 2) * n;
                                    return {
                                        stiffness: e,
                                        damping: 2 * o * Math.sqrt(n * e),
                                        duration: t
                                    }
                                }
                            }(t);
                            (e = { ...e,
                                ...i,
                                mass: 1
                            }).isResolvedFromDuration = !0
                        }
                        return e
                    }({ ...n,
                        velocity: -ei(n.velocity || 0)
                    }),
                    f = d || 0,
                    m = u / (2 * Math.sqrt(l * h)),
                    g = o - s,
                    v = ei(Math.sqrt(l / h)),
                    y = 5 > Math.abs(g);
                if (i || (i = y ? .01 : 2), e || (e = y ? .005 : .5), m < 1) {
                    let t = it(v, m);
                    r = e => o - Math.exp(-m * v * e) * ((f + m * v * g) / t * Math.sin(t * e) + g * Math.cos(t * e))
                } else if (1 === m) r = t => o - Math.exp(-v * t) * (g + (f + v * g) * t);
                else {
                    let t = v * Math.sqrt(m * m - 1);
                    r = e => {
                        let i = Math.exp(-m * v * e),
                            n = Math.min(t * e, 300);
                        return o - i * ((f + m * v * g) * Math.sinh(n) + t * g * Math.cosh(n)) / t
                    }
                }
                return {
                    calculatedDuration: p && c || null,
                    next: t => {
                        let n = r(t);
                        if (p) a.done = t >= c;
                        else {
                            let s = f;
                            0 !== t && (s = m < 1 ? e8(r, t, n) : 0);
                            let l = Math.abs(s) <= i,
                                u = Math.abs(o - n) <= e;
                            a.done = l && u
                        }
                        return a.value = a.done ? o : n, a
                    }
                }
            }

            function io({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: n = 325,
                bounceDamping: r = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: a,
                max: l,
                restDelta: u = .5,
                restSpeed: h
            }) {
                let c, d;
                let p = t[0],
                    f = {
                        done: !1,
                        value: p
                    },
                    m = t => void 0 !== a && t < a || void 0 !== l && t > l,
                    g = t => void 0 === a ? l : void 0 === l ? a : Math.abs(a - t) < Math.abs(l - t) ? a : l,
                    v = i * e,
                    y = p + v,
                    x = void 0 === o ? y : o(y);
                x !== y && (v = x - p);
                let P = t => -v * Math.exp(-t / n),
                    b = t => x + P(t),
                    w = t => {
                        let e = P(t),
                            i = b(t);
                        f.done = Math.abs(e) <= u, f.value = f.done ? x : i
                    },
                    T = t => {
                        m(f.value) && (c = t, d = is({
                            keyframes: [f.value, g(f.value)],
                            velocity: e8(b, t, f.value),
                            damping: r,
                            stiffness: s,
                            restDelta: u,
                            restSpeed: h
                        }))
                    };
                return T(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (d || void 0 !== c || (e = !0, w(t), T(t)), void 0 !== c && t >= c) ? d.next(t - c) : (e || w(t), f)
                    }
                }
            }
            let ia = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function il(t, e, i, n) {
                if (t === e && i === n) return t0.Z;
                let r = e => (function(t, e, i, n, r) {
                    let s, o;
                    let a = 0;
                    do(s = ia(o = e + (i - e) / 2, n, r) - t) > 0 ? i = o : e = o; while (Math.abs(s) > 1e-7 && ++a < 12);
                    return o
                })(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : ia(r(t), e, n)
            }
            let iu = il(.42, 0, 1, 1),
                ih = il(0, 0, .58, 1),
                ic = il(.42, 0, .58, 1),
                id = t => Array.isArray(t) && "number" != typeof t[0],
                ip = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
                im = t => e => 1 - t(1 - e),
                ig = t => 1 - Math.sin(Math.acos(t)),
                iv = im(ig),
                iy = ip(ig),
                ix = il(.33, 1.53, .69, .99),
                iP = im(ix),
                ib = ip(iP),
                iw = {
                    linear: t0.Z,
                    easeIn: iu,
                    easeInOut: ic,
                    easeOut: ih,
                    circIn: ig,
                    circInOut: iy,
                    circOut: iv,
                    backIn: iP,
                    backInOut: ib,
                    backOut: ix,
                    anticipate: t => (t *= 2) < 1 ? .5 * iP(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
                },
                iT = t => {
                    if (Array.isArray(t)) {
                        (0, eg.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, i, n, r] = t;
                        return il(e, i, n, r)
                    }
                    return "string" == typeof t ? ((0, eg.k)(void 0 !== iw[t], `Invalid easing type '${t}'`), iw[t]) : t
                },
                iS = (t, e, i) => {
                    let n = e - t;
                    return 0 === n ? 1 : (i - t) / n
                },
                iA = (t, e, i) => t + (e - t) * i;

            function iE(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }

            function iR(t, e) {
                return i => i > 0 ? e : t
            }
            let iM = (t, e, i) => {
                    let n = t * t,
                        r = i * (e * e - n) + n;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                iC = [eN, eU, eW],
                iV = t => iC.find(e => e.test(t));

            function ij(t) {
                let e = iV(t);
                if ((0, eg.K)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
                let i = e.parse(t);
                return e === eW && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: n
                }) {
                    t /= 360, i /= 100;
                    let r = 0,
                        s = 0,
                        o = 0;
                    if (e /= 100) {
                        let n = i < .5 ? i * (1 + e) : i + e - i * e,
                            a = 2 * i - n;
                        r = iE(a, n, t + 1 / 3), s = iE(a, n, t), o = iE(a, n, t - 1 / 3)
                    } else r = s = o = i;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * o),
                        alpha: n
                    }
                }(i)), i
            }
            let ik = (t, e) => {
                    let i = ij(t),
                        n = ij(e);
                    if (!i || !n) return iR(t, e);
                    let r = { ...i
                    };
                    return t => (r.red = iM(i.red, n.red, t), r.green = iM(i.green, n.green, t), r.blue = iM(i.blue, n.blue, t), r.alpha = iA(i.alpha, n.alpha, t), eU.transform(r))
                },
                iD = new Set(["none", "hidden"]);

            function iL(t, e) {
                return i => iA(t, e, i)
            }

            function iO(t) {
                return "number" == typeof t ? iL : "string" == typeof t ? _(t) ? iR : e_.test(t) ? ik : iI : Array.isArray(t) ? iF : "object" == typeof t ? e_.test(t) ? ik : iB : iR
            }

            function iF(t, e) {
                let i = [...t],
                    n = i.length,
                    r = t.map((t, i) => iO(t)(t, e[i]));
                return t => {
                    for (let e = 0; e < n; e++) i[e] = r[e](t);
                    return i
                }
            }

            function iB(t, e) {
                let i = { ...t,
                        ...e
                    },
                    n = {};
                for (let r in i) void 0 !== t[r] && void 0 !== e[r] && (n[r] = iO(t[r])(t[r], e[r]));
                return t => {
                    for (let e in n) i[e] = n[e](t);
                    return i
                }
            }
            let iI = (t, e) => {
                let i = eX.createTransformer(e),
                    n = eH(t),
                    r = eH(e);
                return n.indexes.var.length === r.indexes.var.length && n.indexes.color.length === r.indexes.color.length && n.indexes.number.length >= r.indexes.number.length ? iD.has(t) && !r.values.length || iD.has(e) && !n.values.length ? iD.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t : t$(iF(function(t, e) {
                    var i;
                    let n = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let o = e.types[s],
                            a = t.indexes[o][r[o]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        n[s] = l, r[o]++
                    }
                    return n
                }(n, r), r.values), i) : ((0, eg.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), iR(t, e))
            };

            function iU(t, e, i) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof i ? iA(t, e, i) : iO(t)(t, e)
            }

            function iN({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: n = "easeInOut"
            }) {
                let r = id(n) ? n.map(iT) : iT(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    o = function(t, e, {
                        clamp: i = !0,
                        ease: n,
                        mixer: r
                    } = {}) {
                        let s = t.length;
                        if ((0, eg.k)(s === e.length, "Both input and output ranges must be the same length"), 1 === s) return () => e[0];
                        if (2 === s && t[0] === t[1]) return () => e[1];
                        t[0] > t[s - 1] && (t = [...t].reverse(), e = [...e].reverse());
                        let o = function(t, e, i) {
                                let n = [],
                                    r = i || iU,
                                    s = t.length - 1;
                                for (let i = 0; i < s; i++) {
                                    let s = r(t[i], t[i + 1]);
                                    e && (s = t$(Array.isArray(e) ? e[i] || t0.Z : e, s)), n.push(s)
                                }
                                return n
                            }(e, n, r),
                            a = o.length,
                            l = e => {
                                let i = 0;
                                if (a > 1)
                                    for (; i < t.length - 2 && !(e < t[i + 1]); i++);
                                let n = iS(t[i], t[i + 1], e);
                                return o[i](n)
                            };
                        return i ? e => l(K(t[0], t[s - 1], e)) : l
                    }((i && i.length === e.length ? i : function(t) {
                        let e = [0];
                        return function(t, e) {
                            let i = t[t.length - 1];
                            for (let n = 1; n <= e; n++) {
                                let r = iS(0, e, n);
                                t.push(iA(i, 1, r))
                            }
                        }(e, t.length - 1), e
                    }(e)).map(e => e * t), e, {
                        ease: Array.isArray(r) ? r : e.map(() => r || ic).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = o(e), s.done = e >= t, s)
                }
            }
            let iW = t => {
                    let e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => tL.Wi.update(e, !0),
                        stop: () => (0, tL.Pn)(e),
                        now: () => tL.frameData.isProcessing ? tL.frameData.timestamp : ef.now()
                    }
                },
                i_ = {
                    decay: io,
                    inertia: io,
                    tween: iN,
                    keyframes: iN,
                    spring: is
                },
                i$ = t => t / 100;
            class iz extends e7 {
                constructor({
                    KeyframeResolver: t = eL,
                    ...e
                }) {
                    super(e), this.holdTime = null, this.startTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    let {
                        name: i,
                        motionValue: n,
                        keyframes: r
                    } = this.options, s = (t, e) => this.onKeyframesResolved(t, e);
                    i && n && n.owner ? this.resolver = n.owner.resolveKeyframes(r, s, i, n) : this.resolver = new t(r, s, i, n), this.resolver.scheduleResolve()
                }
                initPlayback(t) {
                    let e, i;
                    let {
                        type: n = "keyframes",
                        repeat: r = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = i_[n] || iN;
                    l !== iN && "number" != typeof t[0] && (e = t$(i$, iU(t[0], t[1])), t = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (i = l({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = function(t) {
                        let e = 0,
                            i = t.next(e);
                        for (; !i.done && e < 2e4;) e += 50, i = t.next(e);
                        return e >= 2e4 ? 1 / 0 : e
                    }(u));
                    let {
                        calculatedDuration: h
                    } = u, c = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: i,
                        mapPercentToKeyframes: e,
                        calculatedDuration: h,
                        resolvedDuration: c,
                        totalDuration: c * (r + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: i
                    } = this;
                    if (!i) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: r,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: u,
                        resolvedDuration: h
                    } = i;
                    if (null === this.startTime) return r.next(0);
                    let {
                        delay: c,
                        repeat: d,
                        repeatType: p,
                        repeatDelay: f,
                        onUpdate: m
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - u / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let g = this.currentTime - c * (this.speed >= 0 ? 1 : -1),
                        v = this.speed >= 0 ? g < 0 : g > u;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = u);
                    let y = this.currentTime,
                        x = r;
                    if (d) {
                        let t = Math.min(this.currentTime, u) / h,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, d + 1)) % 2 && ("reverse" === p ? (i = 1 - i, f && (i -= f / h)) : "mirror" === p && (x = s)), y = K(0, 1, i) * h
                    }
                    let P = v ? {
                        done: !1,
                        value: a[0]
                    } : x.next(y);
                    o && (P.value = o(P.value));
                    let {
                        done: b
                    } = P;
                    v || null === l || (b = this.speed >= 0 ? this.currentTime >= u : this.currentTime <= 0);
                    let w = null === this.holdTime && ("finished" === this.state || "running" === this.state && b);
                    return w && void 0 !== n && (P.value = ed(a, this.options, n)), m && m(P.value), w && this.finish(), P
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? ei(t.calculatedDuration) : 0
                }
                get time() {
                    return ei(this.currentTime)
                }
                set time(t) {
                    t = ee(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = ei(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = iW,
                        onPlay: e
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let i = this.driver.now();
                    null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime && "finished" !== this.state || (this.startTime = i), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            let iK = t => Array.isArray(t) && "number" == typeof t[0],
                iH = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                iY = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: iH([0, .65, .55, 1]),
                    circOut: iH([.55, 0, 1, .45]),
                    backIn: iH([.31, .01, .66, -.59]),
                    backOut: iH([.33, 1.53, .69, .99])
                };

            function iZ(t) {
                return iq(t) || iY.easeOut
            }

            function iq(t) {
                if (t) return iK(t) ? iH(t) : Array.isArray(t) ? t.map(iZ) : iY[t]
            }
            let iX = e6(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                iG = new Set(["opacity", "clipPath", "filter", "transform"]);
            class iQ extends e7 {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: i,
                        keyframes: n
                    } = this.options;
                    this.resolver = new e9(n, (t, e) => this.onKeyframesResolved(t, e), e, i), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var i, n;
                    let {
                        duration: r = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u
                    } = this.options;
                    if (!(null === (i = l.owner) || void 0 === i ? void 0 : i.current)) return !1;
                    if ("spring" === (n = this.options).type || "backgroundColor" === n.name || ! function t(e) {
                            return !!(!e || "string" == typeof e && e in iY || iK(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: n,
                            ...l
                        } = this.options, u = function(t, e) {
                            let i = new iz({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                r = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) r.push((n = i.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, l);
                        1 === (t = u.keyframes).length && (t[1] = t[0]), r = u.duration, s = u.times, o = u.ease, a = "keyframes"
                    }
                    let h = function(t, e, i, {
                        delay: n = 0,
                        duration: r = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a,
                        times: l
                    } = {}) {
                        let u = {
                            [e]: i
                        };
                        l && (u.offset = l);
                        let h = iq(a);
                        return Array.isArray(h) && (u.easing = h), t.animate(u, {
                            delay: n,
                            duration: r,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, t, { ...this.options,
                        duration: r,
                        times: s,
                        ease: o
                    });
                    return h.startTime = ef.now(), this.pendingTimeline ? (h.timeline = this.pendingTimeline, this.pendingTimeline = void 0) : h.onfinish = () => {
                        let {
                            onComplete: i
                        } = this.options;
                        l.set(ed(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: h,
                        duration: r,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return ei(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return ei(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.currentTime = ee(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return t0.Z;
                        let {
                            animation: i
                        } = e;
                        i.timeline = t, i.onfinish = null
                    } else this.pendingTimeline = t;
                    return t0.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: i,
                        duration: n,
                        type: r,
                        ease: s,
                        times: o
                    } = t;
                    if ("idle" !== e.playState && "finished" !== e.playState) {
                        if (this.time) {
                            let {
                                motionValue: t,
                                onUpdate: e,
                                onComplete: a,
                                ...l
                            } = this.options, u = new iz({ ...l,
                                keyframes: i,
                                duration: n,
                                type: r,
                                ease: s,
                                times: o,
                                isGenerator: !0
                            }), h = ee(this.time);
                            t.setWithVelocity(u.sample(h - 10).value, u.sample(h).value, 10)
                        }
                        this.cancel()
                    }
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: r,
                        damping: s,
                        type: o
                    } = t;
                    return iX() && i && iG.has(i) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== r && 0 !== s && "inertia" !== o
                }
            }
            let iJ = e6(() => void 0 !== window.ScrollTimeline);
            class i0 {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let i = 0; i < this.animations.length; i++) this.animations[i][t] = e
                }
                attachTimeline(t) {
                    let e = this.animations.map(e => {
                        if (!iJ() || !e.attachTimeline) return e.pause(),
                            function(t, e) {
                                let i;
                                let n = () => {
                                    let {
                                        currentTime: n
                                    } = e, r = (null === n ? 0 : n.value) / 100;
                                    i !== r && t(r), i = r
                                };
                                return tL.Wi.update(n, !0), () => (0, tL.Pn)(n)
                            }(t => {
                                e.time = e.duration * t
                            }, t);
                        e.attachTimeline(t)
                    });
                    return () => {
                        e.forEach((t, e) => {
                            t && t(), this.animations[e].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach(e => e[t]())
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            let i1 = (t, e, i, n = {}, r, s) => o => {
                let a = el(n, t) || {},
                    l = a.delay || n.delay || 0,
                    {
                        elapsed: u = 0
                    } = n;
                u -= ee(l);
                let h = {
                    keyframes: Array.isArray(i) ? i : [null, i],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...a,
                    delay: -u,
                    onUpdate: t => {
                        e.set(t), a.onUpdate && a.onUpdate(t)
                    },
                    onComplete: () => {
                        o(), a.onComplete && a.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: s ? void 0 : r
                };
                ! function({
                    when: t,
                    delay: e,
                    delayChildren: i,
                    staggerChildren: n,
                    staggerDirection: r,
                    repeat: s,
                    repeatType: o,
                    repeatDelay: a,
                    from: l,
                    elapsed: u,
                    ...h
                }) {
                    return !!Object.keys(h).length
                }(a) && (h = { ...h,
                    ...ea(t, h)
                }), h.duration && (h.duration = ee(h.duration)), h.repeatDelay && (h.repeatDelay = ee(h.repeatDelay)), void 0 !== h.from && (h.keyframes[0] = h.from);
                let c = !1;
                if (!1 !== h.type && (0 !== h.duration || h.repeatDelay) || (h.duration = 0, 0 !== h.delay || (c = !0)), (eh.current || eu.c.skipAnimations) && (c = !0, h.duration = 0, h.delay = 0), c && !s && void 0 !== e.get()) {
                    let t = ed(h.keyframes, a);
                    if (void 0 !== t) return tL.Wi.update(() => {
                        h.onUpdate(t), h.onComplete()
                    }), new i0([])
                }
                return !s && iQ.supports(h) ? new iQ(h) : new iz(h)
            };

            function i2(t) {
                return !!(F(t) && t.add)
            }

            function i5(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function i3(t, e) {
                let i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            class i9 {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return i5(this.subscriptions, t), () => i3(this.subscriptions, t)
                }
                notify(t, e, i) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, i);
                        else
                            for (let r = 0; r < n; r++) {
                                let n = this.subscriptions[r];
                                n && n(t, e, i)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
            let i6 = t => !isNaN(parseFloat(t)),
                i4 = {
                    current: void 0
                };
            class i7 {
                constructor(t, e = {}) {
                    this.version = "11.2.10", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let i = ef.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = ef.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = i6(this.current))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new i9);
                    let i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), tL.Wi.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : i
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return i4.current && i4.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    var t;
                    let e = ef.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
                    let i = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return t = parseFloat(this.current) - parseFloat(this.prevFrameValue), i ? 1e3 / i * t : 0
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function i8(t, e) {
                return new i7(t, e)
            }

            function nt(t) {
                return t.getProps()[p]
            }

            function ne(t, e, {
                delay: i = 0,
                transitionOverride: n,
                type: r
            } = {}) {
                var s;
                let {
                    transition: o = t.getDefaultTransition(),
                    transitionEnd: a,
                    ...l
                } = e, u = t.getValue("willChange");
                n && (o = n);
                let h = [],
                    c = r && t.animationState && t.animationState.getState()[r];
                for (let e in l) {
                    let n = t.getValue(e, null !== (s = t.latestValues[e]) && void 0 !== s ? s : null),
                        r = l[e];
                    if (void 0 === r || c && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(c, e)) continue;
                    let a = {
                            delay: i,
                            elapsed: 0,
                            ...el(o || {}, e)
                        },
                        d = !1;
                    if (window.HandoffAppearAnimations) {
                        let i = nt(t);
                        if (i) {
                            let t = window.HandoffAppearAnimations(i, e, n, tL.Wi);
                            null !== t && (a.elapsed = t, d = !0)
                        }
                    }
                    n.start(i1(e, n, r, t.shouldReduceMotion && L.has(e) ? {
                        type: !1
                    } : a, t, d));
                    let p = n.animation;
                    p && (i2(u) && (u.add(e), p.then(() => u.remove(e))), h.push(p))
                }
                return a && Promise.all(h).then(() => {
                    tL.Wi.update(() => {
                        a && function(t, e) {
                            let {
                                transitionEnd: i = {},
                                transition: n = {},
                                ...r
                            } = et(t, e) || {};
                            for (let e in r = { ...r,
                                    ...i
                                }) {
                                let i = tj(r[e]);
                                t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, i8(i))
                            }
                        }(t, a)
                    })
                }), h
            }

            function ni(t, e, i = {}) {
                var n;
                let r = et(t, e, "exit" === i.type ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0),
                    {
                        transition: s = t.getDefaultTransition() || {}
                    } = r || {};
                i.transitionOverride && (s = i.transitionOverride);
                let o = r ? () => Promise.all(ne(t, r, i)) : () => Promise.resolve(),
                    a = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: o,
                            staggerDirection: a
                        } = s;
                        return function(t, e, i = 0, n = 0, r = 1, s) {
                            let o = [],
                                a = (t.variantChildren.size - 1) * n,
                                l = 1 === r ? (t = 0) => t * n : (t = 0) => a - t * n;
                            return Array.from(t.variantChildren).sort(nn).forEach((t, n) => {
                                t.notify("AnimationStart", e), o.push(ni(t, e, { ...s,
                                    delay: i + l(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(o)
                        }(t, e, r + n, o, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = s;
                if (!l) return Promise.all([o(), a(i.delay)]); {
                    let [t, e] = "beforeChildren" === l ? [o, a] : [a, o];
                    return t().then(() => e())
                }
            }

            function nn(t, e) {
                return t.sortNodePosition(e)
            }
            let nr = [...x].reverse(),
                ns = x.length;

            function no(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }
            class na extends tq {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => ni(t, e, i)));
                                else if ("string" == typeof e) n = ni(t, e, i);
                                else {
                                    let r = "function" == typeof e ? et(t, e, i.custom) : e;
                                    n = Promise.all(ne(t, r, i))
                                }
                                return n.then(() => {
                                    tL.Wi.postRender(() => {
                                        t.notify("AnimationComplete", e)
                                    })
                                })
                            })(t, e, i))),
                            i = {
                                animate: no(!0),
                                whileInView: no(),
                                whileHover: no(),
                                whileTap: no(),
                                whileDrag: no(),
                                whileFocus: no(),
                                exit: no()
                            },
                            n = !0,
                            r = e => (i, n) => {
                                var r;
                                let s = et(t, n, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    i = { ...i,
                                        ...n,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function s(s) {
                            let o = t.getProps(),
                                a = t.getVariantContext(!0) || {},
                                l = [],
                                u = new Set,
                                h = {},
                                c = 1 / 0;
                            for (let e = 0; e < ns; e++) {
                                var d;
                                let p = nr[e],
                                    f = i[p],
                                    m = void 0 !== o[p] ? o[p] : a[p],
                                    g = v(m),
                                    x = p === s ? f.isActive : null;
                                !1 === x && (c = e);
                                let P = m === a[p] && m !== o[p] && g;
                                if (P && n && t.manuallyAnimateOnMount && (P = !1), f.protectedKeys = { ...h
                                    }, !f.isActive && null === x || !m && !f.prevProp || y(m) || "boolean" == typeof m) continue;
                                let b = (d = f.prevProp, ("string" == typeof m ? m !== d : !!Array.isArray(m) && !t8(m, d)) || p === s && f.isActive && !P && g || e > c && g),
                                    w = !1,
                                    T = Array.isArray(m) ? m : [m],
                                    S = T.reduce(r(p), {});
                                !1 === x && (S = {});
                                let {
                                    prevResolvedValues: A = {}
                                } = f, E = { ...A,
                                    ...S
                                }, R = e => {
                                    b = !0, u.has(e) && (w = !0, u.delete(e)), f.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in E) {
                                    let e = S[t],
                                        i = A[t];
                                    if (!h.hasOwnProperty(t))(tC(e) && tC(i) ? t8(e, i) : e === i) ? void 0 !== e && u.has(t) ? R(t) : f.protectedKeys[t] = !0 : null != e ? R(t) : u.add(t)
                                }
                                f.prevProp = m, f.prevResolvedValues = S, f.isActive && (h = { ...h,
                                    ...S
                                }), n && t.blockInitialAnimation && (b = !1), b && (!P || w) && l.push(...T.map(t => ({
                                    animation: t,
                                    options: {
                                        type: p
                                    }
                                })))
                            }
                            if (u.size) {
                                let e = {};
                                u.forEach(i => {
                                    let n = t.getBaseTarget(i),
                                        r = t.getValue(i);
                                    r && (r.liveStyle = !0), e[i] = null != n ? n : null
                                }), l.push({
                                    animation: e
                                })
                            }
                            let p = !!l.length;
                            return n && (!1 === o.initial || o.initial === o.animate) && !t.manuallyAnimateOnMount && (p = !1), n = !1, p ? e(l) : Promise.resolve()
                        }
                        return {
                            animateChanges: s,
                            setActive: function(e, n) {
                                var r;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (r = t.variantChildren) || void 0 === r || r.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let o = s(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return o
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    this.unmount(), y(t) && (this.unmount = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {}
            }
            let nl = 0;
            class nu extends tq {
                constructor() {
                    super(...arguments), this.id = nl++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            let nh = (t, e) => Math.abs(t - e);
            class nc {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: n,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            var t, e;
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let i = nf(this.lastMoveEventInfo, this.history),
                                n = null !== this.startEvent,
                                r = (t = i.offset, e = {
                                    x: 0,
                                    y: 0
                                }, Math.sqrt(nh(t.x, e.x) ** 2 + nh(t.y, e.y) ** 2) >= 3);
                            if (!n && !r) return;
                            let {
                                point: s
                            } = i, {
                                timestamp: o
                            } = tL.frameData;
                            this.history.push({ ...s,
                                timestamp: o
                            });
                            let {
                                onStart: a,
                                onMove: l
                            } = this.handlers;
                            n || (a && a(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), l && l(this.lastMoveEvent, i)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = nd(e, this.transformPagePoint), tL.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = nf("pointercancel" === t.type ? this.lastMoveEventInfo : nd(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, s), n && n(t, s)
                        }, !tI(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = i, this.contextWindow = n || window;
                    let s = nd(tU(t), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = tL.frameData;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = e;
                    l && l(t, nf(s, this.history)), this.removeListeners = t$(tW(this.contextWindow, "pointermove", this.handlePointerMove), tW(this.contextWindow, "pointerup", this.handlePointerUp), tW(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, tL.Pn)(this.updatePoint)
                }
            }

            function nd(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function np(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function nf({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: np(t, nm(e)),
                    offset: np(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = nm(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > ee(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = ei(r.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (r.x - n.x) / s,
                            y: (r.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e, 0)
                }
            }

            function nm(t) {
                return t[t.length - 1]
            }

            function ng(t) {
                return t.max - t.min
            }

            function nv(t, e = 0, i = .01) {
                return Math.abs(t - e) <= i
            }

            function ny(t, e, i, n = .5) {
                t.origin = n, t.originPoint = iA(e.min, e.max, t.origin), t.scale = ng(i) / ng(e), (nv(t.scale, 1, 1e-4) || isNaN(t.scale)) && (t.scale = 1), t.translate = iA(i.min, i.max, t.origin) - t.originPoint, (nv(t.translate) || isNaN(t.translate)) && (t.translate = 0)
            }

            function nx(t, e, i, n) {
                ny(t.x, e.x, i.x, n ? n.originX : void 0), ny(t.y, e.y, i.y, n ? n.originY : void 0)
            }

            function nP(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + ng(e)
            }

            function nb(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + ng(e)
            }

            function nw(t, e, i) {
                nb(t.x, e.x, i.x), nb(t.y, e.y, i.y)
            }

            function nT(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function nS(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function nA(t, e, i) {
                return {
                    min: nE(t, e),
                    max: nE(t, i)
                }
            }

            function nE(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            let nR = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                nM = () => ({
                    x: nR(),
                    y: nR()
                }),
                nC = () => ({
                    min: 0,
                    max: 0
                }),
                nV = () => ({
                    x: nC(),
                    y: nC()
                });

            function nj(t) {
                return [t("x"), t("y")]
            }

            function nk({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function nD(t) {
                return void 0 === t || 1 === t
            }

            function nL({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !nD(t) || !nD(e) || !nD(i)
            }

            function nO(t) {
                return nL(t) || nF(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function nF(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }

            function nB(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function nI(t, e = 0, i = 1, n, r) {
                t.min = nB(t.min, e, i, n, r), t.max = nB(t.max, e, i, n, r)
            }

            function nU(t, {
                x: e,
                y: i
            }) {
                nI(t.x, e.translate, e.scale, e.originPoint), nI(t.y, i.translate, i.scale, i.originPoint)
            }

            function nN(t) {
                return Number.isInteger(t) ? t : t > 1.0000000000001 || t < .999999999999 ? t : 1
            }

            function nW(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function n_(t, e, [i, n, r]) {
                let s = void 0 !== e[r] ? e[r] : .5,
                    o = iA(t.min, t.max, s);
                nI(t, e[i], e[n], o, e.scale)
            }
            let n$ = ["x", "scaleX", "originX"],
                nz = ["y", "scaleY", "originY"];

            function nK(t, e) {
                n_(t.x, e, n$), n_(t.y, e, nz)
            }

            function nH(t, e) {
                return nk(function(t, e) {
                    if (!e) return t;
                    let i = e({
                            x: t.left,
                            y: t.top
                        }),
                        n = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: i.y,
                        left: i.x,
                        bottom: n.y,
                        right: n.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            let nY = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null,
                nZ = new WeakMap;
            class nq {
                constructor(t) {
                    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = nV(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new nc(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(tU(t, "page").point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: r
                            } = this.getProps();
                            if (i && !n && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = tY(i), !this.openGlobalLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), nj(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (ti.test(e)) {
                                    let {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        let n = i.layout.layoutBox[t];
                                        if (n) {
                                            let t = ng(n);
                                            e = parseFloat(e) / 100 * t
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            }), r && tL.Wi.postRender(() => r(t, e));
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: s
                            } = this.getProps();
                            if (!i && !this.openGlobalLock) return;
                            let {
                                offset: o
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(o), null !== this.currentDirection && r && r(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => nj(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: nY(this.visualElement)
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && tL.Wi.postRender(() => r(t, e))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !nX(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? iA(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? iA(i, t, n.max) : Math.min(t, i)), t
                    }(s, this.constraints[t], this.elastic[t])), r.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && g(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: nT(t.x, i, r),
                            y: nT(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: nA(t, "left", "right"),
                            y: nA(t, "top", "bottom")
                        }
                    }(i), r !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && nj(t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !g(e)) return !1;
                    let n = e.current;
                    (0, eg.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let s = function(t, e, i) {
                            let n = nH(t, i),
                                {
                                    scroll: r
                                } = e;
                            return r && (nW(n.x, r.offset.x), nW(n.y, r.offset.y)), n
                        }(n, r.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: nS((t = r.layout.layoutBox).x, s.x),
                            y: nS(t.y, s.y)
                        };
                    if (i) {
                        let t = i(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(o));
                        this.hasMutatedConstraints = !!t, t && (o = nk(t))
                    }
                    return o
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(nj(o => {
                        if (!nX(o, e, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[o] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return i.start(i1(t, i, 0, e, this.visualElement))
                }
                stopAnimation() {
                    nj(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    nj(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`,
                        i = this.visualElement.getProps();
                    return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    nj(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!nX(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: s
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - iA(i, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!g(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    nj(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            let i = e.get();
                            n[t] = function(t, e) {
                                let i = .5,
                                    n = ng(t),
                                    r = ng(e);
                                return r > n ? i = iS(e.min, e.max - n, t.min) : n > r && (i = iS(t.min, t.max - r, e.min)), K(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), nj(e => {
                        if (!nX(e, t, null)) return;
                        let i = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: s
                            } = this.constraints[e];
                        i.set(iA(r, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    nZ.set(this.visualElement, this);
                    let t = tW(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            g(t) && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        n = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), e();
                    let r = tB(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = i.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (nj(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function nX(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            class nG extends tq {
                constructor(t) {
                    super(t), this.removeGroupControls = t0.Z, this.removeListeners = t0.Z, this.controls = new nq(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || t0.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let nQ = t => (e, i) => {
                t && tL.Wi.postRender(() => t(e, i))
            };
            class nJ extends tq {
                constructor() {
                    super(...arguments), this.removePointerDownListener = t0.Z
                }
                onPointerDown(t) {
                    this.session = new nc(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: nY(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: i,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: nQ(t),
                        onStart: nQ(e),
                        onMove: i,
                        onEnd: (t, e) => {
                            delete this.session, n && tL.Wi.postRender(() => n(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = tW(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            let n0 = {
                hasAnimatedSinceResize: !0,
                hasEverUpdated: !1
            };

            function n1(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let n2 = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!tn.test(t)) return t;
                        t = parseFloat(t)
                    }
                    let i = n1(t, e.target.x),
                        n = n1(t, e.target.y);
                    return `${i}% ${n}%`
                }
            };
            class n5 extends o.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    Object.assign(k, n9), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), n0.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, s = i.projection;
                    return s && (s.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? s.promote() : s.relegate() || tL.Wi.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), f.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function n3(t) {
                let [e, i] = function() {
                    let t = (0, o.useContext)(u.O);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: i,
                        register: n
                    } = t, r = (0, o.useId)();
                    return (0, o.useEffect)(() => n(r), []), !e && i ? [!1, () => i && i(r)] : [!0]
                }(), n = (0, o.useContext)(R.p);
                return (0, s.jsx)(n5, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, o.useContext)(M),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            let n9 = {
                    borderRadius: { ...n2,
                        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                    },
                    borderTopLeftRadius: n2,
                    borderTopRightRadius: n2,
                    borderBottomLeftRadius: n2,
                    borderBottomRightRadius: n2,
                    boxShadow: {
                        correct: (t, {
                            treeScale: e,
                            projectionDelta: i
                        }) => {
                            let n = eX.parse(t);
                            if (n.length > 5) return t;
                            let r = eX.createTransformer(t),
                                s = "number" != typeof n[0] ? 1 : 0,
                                o = i.x.scale * e.x,
                                a = i.y.scale * e.y;
                            n[0 + s] /= o, n[1 + s] /= a;
                            let l = iA(o, a, .5);
                            return "number" == typeof n[2 + s] && (n[2 + s] /= l), "number" == typeof n[3 + s] && (n[3 + s] /= l), r(n)
                        }
                    }
                },
                n6 = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                n4 = n6.length,
                n7 = t => "string" == typeof t ? parseFloat(t) : t,
                n8 = t => "number" == typeof t || tn.test(t);

            function rt(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let re = rn(0, .5, iv),
                ri = rn(.5, .95, t0.Z);

            function rn(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i(iS(t, e, n))
            }

            function rr(t, e) {
                t.min = e.min, t.max = e.max
            }

            function rs(t, e) {
                rr(t.x, e.x), rr(t.y, e.y)
            }

            function ro(t, e, i, n, r) {
                return t -= e, t = n + 1 / i * (t - n), void 0 !== r && (t = n + 1 / r * (t - n)), t
            }

            function ra(t, e, [i, n, r], s, o) {
                ! function(t, e = 0, i = 1, n = .5, r, s = t, o = t) {
                    if (ti.test(e) && (e = parseFloat(e), e = iA(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
                    let a = iA(s.min, s.max, n);
                    t === s && (a -= e), t.min = ro(t.min, e, i, a, r), t.max = ro(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, s, o)
            }
            let rl = ["x", "scaleX", "originX"],
                ru = ["y", "scaleY", "originY"];

            function rh(t, e, i, n) {
                ra(t.x, e, rl, i ? i.x : void 0, n ? n.x : void 0), ra(t.y, e, ru, i ? i.y : void 0, n ? n.y : void 0)
            }

            function rc(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function rd(t) {
                return rc(t.x) && rc(t.y)
            }

            function rp(t, e) {
                return Math.round(t.x.min) === Math.round(e.x.min) && Math.round(t.x.max) === Math.round(e.x.max) && Math.round(t.y.min) === Math.round(e.y.min) && Math.round(t.y.max) === Math.round(e.y.max)
            }

            function rf(t) {
                return ng(t.x) / ng(t.y)
            }
            class rm {
                constructor() {
                    this.members = []
                }
                add(t) {
                    i5(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if (i3(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }

            function rg(t, e, i) {
                let n = "",
                    r = t.x.translate / e.x,
                    s = t.y.translate / e.y,
                    o = (null == i ? void 0 : i.z) || 0;
                if ((r || s || o) && (n = `translate3d(${r}px, ${s}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                    let {
                        transformPerspective: t,
                        rotate: e,
                        rotateX: r,
                        rotateY: s,
                        skewX: o,
                        skewY: a
                    } = i;
                    t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), r && (n += `rotateX(${r}deg) `), s && (n += `rotateY(${s}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                }
                let a = t.x.scale * e.x,
                    l = t.y.scale * e.y;
                return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
            }
            let rv = (t, e) => t.depth - e.depth;
            class ry {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    i5(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    i3(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(rv), this.isDirty = !1, this.children.forEach(t)
                }
            }
            let rx = ["", "X", "Y", "Z"],
                rP = {
                    visibility: "hidden"
                },
                rb = 0,
                rw = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                };

            function rT(t, e, i, n) {
                let {
                    latestValues: r
                } = e;
                r[t] && (i[t] = r[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function rS({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, i = null == e ? void 0 : e()) {
                        this.id = rb++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, rw.totalNodes = rw.resolvedTargetDeltas = rw.recalculatedProjection = 0, this.nodes.forEach(rR), this.nodes.forEach(rL), this.nodes.forEach(rO), this.nodes.forEach(rM), window.MotionDebug && window.MotionDebug.record(rw)
                        }, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new ry)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new i9), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = e instanceof SVGElement && "svg" !== e.tagName, this.instance = e;
                        let {
                            layoutId: n,
                            layout: r,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (r || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = function(t, e) {
                                    let i = ef.now(),
                                        n = ({
                                            timestamp: e
                                        }) => {
                                            let r = e - i;
                                            r >= 250 && ((0, tL.Pn)(n), t(r - 250))
                                        };
                                    return tL.Wi.read(n, !0), () => (0, tL.Pn)(n)
                                }(n, 0), n0.hasAnimatedSinceResize && (n0.hasAnimatedSinceResize = !1, this.nodes.forEach(rD))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || r) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || s.getDefaultTransition() || rW,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !rp(this.targetLayout, n) || i,
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || e && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                let e = { ...el(r, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || rD(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, tL.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(rF), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.HandoffCancelAllAnimations && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return !1;
                                let {
                                    visualElement: i
                                } = e.options;
                                return !!i && (!!nt(i) || !!e.parent && !e.parent.hasCheckedOptimisedAppear && t(e.parent))
                            }(this) && window.HandoffCancelAllAnimations(), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(rV);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(rj), this.isUpdating = !1, this.nodes.forEach(rk), this.nodes.forEach(rA), this.nodes.forEach(rE), this.clearAllSnapshots();
                        let t = ef.now();
                        tL.frameData.delta = K(0, 1e3 / 60, t - tL.frameData.timestamp), tL.frameData.timestamp = t, tL.frameData.isProcessing = !0, tL.S6.update.process(tL.frameData), tL.S6.preRender.process(tL.frameData), tL.S6.render.process(tL.frameData), tL.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, f.read(() => this.update()))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(rC), this.sharedNodes.forEach(rB)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, tL.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        tL.Wi.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = nV(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && (this.scroll = {
                            animationId: this.root.animationId,
                            phase: t,
                            isRoot: n(this.instance),
                            offset: i(this.instance)
                        })
                    }
                    resetTransform() {
                        if (!r) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform,
                            e = this.projectionDelta && !rd(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            n = i ? i(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || nO(this.latestValues) || s) && (r(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), rz((e = n).x), rz(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return nV();
                        let e = t.measureViewportBox(),
                            {
                                scroll: i
                            } = this.root;
                        return i && (nW(e.x, i.offset.x), nW(e.y, i.offset.y)), e
                    }
                    removeElementScroll(t) {
                        let e = nV();
                        rs(e, t);
                        for (let i = 0; i < this.path.length; i++) {
                            let n = this.path[i],
                                {
                                    scroll: r,
                                    options: s
                                } = n;
                            if (n !== this.root && r && s.layoutScroll) {
                                if (r.isRoot) {
                                    rs(e, t);
                                    let {
                                        scroll: i
                                    } = this.root;
                                    i && (nW(e.x, -i.offset.x), nW(e.y, -i.offset.y))
                                }
                                nW(e.x, r.offset.x), nW(e.y, r.offset.y)
                            }
                        }
                        return e
                    }
                    applyTransform(t, e = !1) {
                        let i = nV();
                        rs(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && nK(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), nO(n.latestValues) && nK(i, n.latestValues)
                        }
                        return nO(this.latestValues) && nK(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        let e = nV();
                        rs(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            if (!i.instance || !nO(i.latestValues)) continue;
                            nL(i.latestValues) && i.updateSnapshot();
                            let n = nV();
                            rs(n, i.measurePageBox()), rh(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, n)
                        }
                        return nO(this.latestValues) && rh(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== tL.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, i, n, r;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(t || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = tL.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = nV(), this.relativeTargetOrigin = nV(), nw(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), rs(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = nV(), this.targetWithTransforms = nV()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), i = this.target, n = this.relativeTarget, r = this.relativeParent.target, nP(i.x, n.x, r.x), nP(i.y, n.y, r.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : rs(this.target, this.layout.layoutBox), nU(this.target, this.targetDelta)) : rs(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = nV(), this.relativeTargetOrigin = nV(), nw(this.relativeTargetOrigin, this.target, t.target), rs(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                rw.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || nL(this.parent.latestValues) || nF(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            i = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === tL.frameData.timestamp && (n = !1), n) return;
                        let {
                            layout: r,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || s)) return;
                        rs(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        ! function(t, e, i, n = !1) {
                            let r, s;
                            let o = i.length;
                            if (o) {
                                e.x = e.y = 1;
                                for (let a = 0; a < o; a++) {
                                    s = (r = i[a]).projectionDelta;
                                    let o = r.instance;
                                    (!o || !o.style || "contents" !== o.style.display) && (n && r.options.layoutScroll && r.scroll && r !== r.root && nK(t, {
                                        x: -r.scroll.offset.x,
                                        y: -r.scroll.offset.y
                                    }), s && (e.x *= s.x.scale, e.y *= s.y.scale, nU(t, s)), n && nO(r.latestValues) && nK(t, r.latestValues))
                                }
                                e.x = nN(e.x), e.y = nN(e.y)
                            }
                        }(this.layoutCorrected, this.treeScale, this.path, i), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = nV());
                        let {
                            target: l
                        } = e;
                        if (!l) {
                            this.projectionTransform && (this.projectionDelta = nM(), this.projectionTransform = "none", this.scheduleRender());
                            return
                        }
                        this.projectionDelta || (this.projectionDelta = nM(), this.projectionDeltaWithTransform = nM());
                        let u = this.projectionTransform;
                        nx(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.projectionTransform = rg(this.projectionDelta, this.treeScale), (this.projectionTransform !== u || this.treeScale.x !== o || this.treeScale.y !== a) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), rw.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        if (this.options.scheduleRender && this.options.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    setAnimationOrigin(t, e = !1) {
                        let i;
                        let n = this.snapshot,
                            r = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = nM();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let a = nV(),
                            l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            c = !!(l && !h && !0 === this.options.crossfade && !this.path.some(rN));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (rI(o.x, t.x, n), rI(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, d, p, f;
                                nw(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, f = this.relativeTargetOrigin, rU(p.x, f.x, a.x, n), rU(p.y, f.y, a.y, n), i && (u = this.relativeTarget, d = i, u.x.min === d.x.min && u.x.max === d.x.max && u.y.min === d.y.min && u.y.max === d.y.max) && (this.isProjectionDirty = !1), i || (i = nV()), rs(i, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(t, e, i, n, r, s) {
                                r ? (t.opacity = iA(0, void 0 !== i.opacity ? i.opacity : 1, re(n)), t.opacityExit = iA(void 0 !== e.opacity ? e.opacity : 1, 0, ri(n))) : s && (t.opacity = iA(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < n4; r++) {
                                    let s = `border${n6[r]}Radius`,
                                        o = rt(e, s),
                                        a = rt(i, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || n8(o) === n8(a) ? (t[s] = Math.max(iA(n7(o), n7(a), n), 0), (ti.test(a) || ti.test(o)) && (t[s] += "%")) : t[s] = a)
                                }(e.rotate || i.rotate) && (t.rotate = iA(e.rotate || 0, i.rotate || 0, n))
                            }(s, r, this.latestValues, n, c, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, tL.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = tL.Wi.update(() => {
                            n0.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, i) {
                                let n = F(0) ? 0 : i8(0);
                                return n.start(i1("", n, 1e3, i)), n.animation
                            }(0, 0, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && rK(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || nV();
                                let e = ng(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = ng(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            rs(e, i), nK(e, r), nx(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new rm), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let n = {};
                        i.z && rT("z", t, n, this.animationValues);
                        for (let e = 0; e < rx.length; e++) rT(`rotate${rx[e]}`, t, n, this.animationValues), rT(`skew${rx[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return rP;
                        let n = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = tk(null == t ? void 0 : t.pointerEvents) || "", n.transform = r ? r(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = tk(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !nO(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = rg(this.projectionDeltaWithTransform, this.treeScale, o), r && (n.transform = r(o, n.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (i = null !== (e = o.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, k) {
                            if (void 0 === o[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = k[t], r = "none" === n.transform ? o[t] : e(o[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) n[i[e]] = r
                            } else n[t] = r
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? tk(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(rV), this.root.sharedNodes.clear()
                    }
                }
            }

            function rA(t) {
                t.updateLayout()
            }

            function rE(t) {
                var e;
                let i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: r
                    } = t.options, s = i.source !== t.layout.source;
                    "size" === r ? nj(t => {
                        let n = s ? i.measuredBox[t] : i.layoutBox[t],
                            r = ng(n);
                        n.min = e[t].min, n.max = n.min + r
                    }) : rK(r, i.layoutBox, e) && nj(n => {
                        let r = s ? i.measuredBox[n] : i.layoutBox[n],
                            o = ng(e[n]);
                        r.max = r.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
                    });
                    let o = nM();
                    nx(o, e, i.layoutBox);
                    let a = nM();
                    s ? nx(a, t.applyTransform(n, !0), i.measuredBox) : nx(a, e, i.layoutBox);
                    let l = !rd(o),
                        u = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: r,
                                layout: s
                            } = n;
                            if (r && s) {
                                let o = nV();
                                nw(o, i.layoutBox, r.layoutBox);
                                let a = nV();
                                nw(a, e, s.layoutBox), rp(o, a) || (u = !0), n.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = o, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function rR(t) {
                rw.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function rM(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function rC(t) {
                t.clearSnapshot()
            }

            function rV(t) {
                t.clearMeasurements()
            }

            function rj(t) {
                t.isLayoutDirty = !1
            }

            function rk(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function rD(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function rL(t) {
                t.resolveTargetDelta()
            }

            function rO(t) {
                t.calcProjection()
            }

            function rF(t) {
                t.resetSkewAndRotation()
            }

            function rB(t) {
                t.removeLeadSnapshot()
            }

            function rI(t, e, i) {
                t.translate = iA(e.translate, 0, i), t.scale = iA(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function rU(t, e, i, n) {
                t.min = iA(e.min, i.min, n), t.max = iA(e.max, i.max, n)
            }

            function rN(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let rW = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                r_ = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                r$ = r_("applewebkit/") && !r_("chrome/") ? Math.round : t0.Z;

            function rz(t) {
                t.min = r$(t.min), t.max = r$(t.max)
            }

            function rK(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !nv(rf(e), rf(i), .2)
            }
            let rH = rS({
                    attachResizeListener: (t, e) => tB(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                rY = {
                    current: void 0
                },
                rZ = rS({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!rY.current) {
                            let t = new rH({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), rY.current = t
                        }
                        return rY.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                }),
                rq = {
                    current: null
                },
                rX = {
                    current: !1
                },
                rG = new WeakMap,
                rQ = [...eR, e_, eX],
                rJ = t => rQ.find(eE(t)),
                r0 = Object.keys(A),
                r1 = r0.length,
                r2 = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
                r5 = P.length;
            class r3 {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: n,
                    blockInitialAnimation: r,
                    visualState: s
                }, o = {}) {
                    this.resolveKeyframes = (t, e, i, n) => new this.KeyframeResolver(t, e, i, n, this), this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = eL, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.scheduleRender = () => tL.Wi.render(this.render, !1, !0);
                    let {
                        latestValues: a,
                        renderState: l
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = !!r, this.isControllingVariants = b(e), this.isVariantNode = w(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: u,
                        ...h
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in h) {
                        let e = h[t];
                        void 0 !== a[t] && F(e) && (e.set(a[t], !1), i2(u) && u.add(t))
                    }
                }
                mount(t) {
                    this.current = t, rG.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), rX.current || function() {
                        if (rX.current = !0, E.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => rq.current = t.matches;
                                t.addListener(e), e()
                            } else rq.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || rq.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    var t;
                    for (let t in rG.delete(this.current), this.projection && this.projection.unmount(), (0, tL.Pn)(this.notifyUpdate), (0, tL.Pn)(this.render), this.valueSubscriptions.forEach(t => t()), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let e in this.features) null === (t = this.features[e]) || void 0 === t || t.unmount();
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i = L.has(t),
                        n = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && tL.Wi.preRender(this.notifyUpdate), i && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        r = e.on("renderRequest", this.scheduleRender);
                    this.valueSubscriptions.set(t, () => {
                        n(), r(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                loadFeatures({
                    children: t,
                    ...e
                }, i, n, r) {
                    let s, o;
                    for (let t = 0; t < r1; t++) {
                        let i = r0[t],
                            {
                                isEnabled: n,
                                Feature: r,
                                ProjectionNode: a,
                                MeasureLayout: l
                            } = A[i];
                        a && (s = a), n(e) && (!this.features[i] && r && (this.features[i] = new r(this)), l && (o = l))
                    }
                    if (("html" === this.type || "svg" === this.type) && !this.projection && s) {
                        let {
                            layoutId: t,
                            layout: i,
                            drag: n,
                            dragConstraints: o,
                            layoutScroll: a,
                            layoutRoot: l
                        } = e;
                        this.projection = new s(this.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                            if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                        }(this.parent)), this.projection.setOptions({
                            layoutId: t,
                            layout: i,
                            alwaysMeasureLayout: !!n || o && g(o),
                            visualElement: this,
                            scheduleRender: () => this.scheduleRender(),
                            animationType: "string" == typeof i ? i : "both",
                            initialPromotionConfig: r,
                            layoutScroll: a,
                            layoutRoot: l
                        })
                    }
                    return o
                }
                updateFeatures() {
                    for (let t in this.features) {
                        let e = this.features[t];
                        e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.options, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : nV()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < r2.length; e++) {
                        let i = r2[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        let {
                            willChange: n
                        } = e;
                        for (let r in e) {
                            let s = e[r],
                                o = i[r];
                            if (F(s)) t.addValue(r, s), i2(n) && n.add(r);
                            else if (F(o)) t.addValue(r, i8(s, {
                                owner: t
                            })), i2(n) && n.remove(r);
                            else if (o !== s) {
                                if (t.hasValue(r)) {
                                    let e = t.getValue(r);
                                    !0 === e.liveStyle ? e.jump(s) : e.hasAnimated || e.set(s)
                                } else {
                                    let e = t.getStaticValue(r);
                                    t.addValue(r, i8(void 0 !== e ? e : s, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                getVariantContext(t = !1) {
                    if (t) return this.parent ? this.parent.getVariantContext() : void 0;
                    if (!this.isControllingVariants) {
                        let t = this.parent && this.parent.getVariantContext() || {};
                        return void 0 !== this.props.initial && (t.initial = this.props.initial), t
                    }
                    let e = {};
                    for (let t = 0; t < r5; t++) {
                        let i = P[t],
                            n = this.props[i];
                        (v(n) || !1 === n) && (e[i] = n)
                    }
                    return e
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = i8(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && (ev(n) || em(n)) ? n = parseFloat(n) : !rJ(n) && eX.test(e) && (n = e5(t, e)), this.setBaseTarget(t, F(n) ? n.get() : n)), F(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let i;
                    let {
                        initial: n
                    } = this.props;
                    if ("string" == typeof n || "object" == typeof n) {
                        let r = tR(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        r && (i = r[t])
                    }
                    if (n && void 0 !== i) return i;
                    let r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || F(r) ? void 0 !== this.initialValues[t] && void 0 === i ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new i9), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            class r9 extends r3 {
                constructor() {
                    super(...arguments), this.KeyframeResolver = e9
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
            }
            class r6 extends r9 {
                constructor() {
                    super(...arguments), this.type = "html"
                }
                readValueFromInstance(t, e) {
                    if (L.has(e)) {
                        let t = e2(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = (N(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return nH(t, e)
                }
                build(t, e, i, n) {
                    tu(t, e, i, n.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return tS(t, e, i)
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    F(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
                renderInstance(t, e, i, n) {
                    tb(t, e, i, n)
                }
            }
            class r4 extends r9 {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (L.has(e)) {
                        let t = e2(e);
                        return t && t.default || 0
                    }
                    return e = tw.has(e) ? e : d(e), t.getAttribute(e)
                }
                measureInstanceViewportBox() {
                    return nV()
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return tA(t, e, i)
                }
                build(t, e, i, n) {
                    ty(t, e, i, this.isSVGTag, n.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    tT(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = tP(t.tagName), super.mount(t)
                }
            }
            let r7 = (t, e) => j(t) ? new r4(e, {
                    enableHardwareAcceleration: !1
                }) : new r6(e, {
                    allowProjection: t !== o.Fragment,
                    enableHardwareAcceleration: !0
                }),
                r8 = {
                    animation: {
                        Feature: na
                    },
                    exit: {
                        Feature: nu
                    },
                    inView: {
                        Feature: t7
                    },
                    tap: {
                        Feature: t2
                    },
                    focus: {
                        Feature: tQ
                    },
                    hover: {
                        Feature: tG
                    },
                    pan: {
                        Feature: nJ
                    },
                    drag: {
                        Feature: nG,
                        ProjectionNode: rZ,
                        MeasureLayout: n3
                    },
                    layout: {
                        ProjectionNode: rZ,
                        MeasureLayout: n3
                    }
                },
                st = function(t) {
                    function e(e, i = {}) {
                        return function({
                            preloadedFeatures: t,
                            createVisualElement: e,
                            useRender: i,
                            useVisualState: n,
                            Component: r
                        }) {
                            t && function(t) {
                                for (let e in t) A[e] = { ...A[e],
                                    ...t[e]
                                }
                            }(t);
                            let d = (0, o.forwardRef)(function(d, m) {
                                var y;
                                let x;
                                let P = { ...(0, o.useContext)(a._),
                                        ...d,
                                        layoutId: function({
                                            layoutId: t
                                        }) {
                                            let e = (0, o.useContext)(R.p).id;
                                            return e && void 0 !== t ? e + "-" + t : t
                                        }(d)
                                    },
                                    {
                                        isStatic: w
                                    } = P,
                                    S = function(t) {
                                        let {
                                            initial: e,
                                            animate: i
                                        } = function(t, e) {
                                            if (b(t)) {
                                                let {
                                                    initial: e,
                                                    animate: i
                                                } = t;
                                                return {
                                                    initial: !1 === e || v(e) ? e : void 0,
                                                    animate: v(i) ? i : void 0
                                                }
                                            }
                                            return !1 !== t.inherit ? e : {}
                                        }(t, (0, o.useContext)(l));
                                        return (0, o.useMemo)(() => ({
                                            initial: e,
                                            animate: i
                                        }), [T(e), T(i)])
                                    }(d),
                                    A = n(d, w);
                                if (!w && E.j) {
                                    S.visualElement = function(t, e, i, n) {
                                        let {
                                            visualElement: r
                                        } = (0, o.useContext)(l), s = (0, o.useContext)(c), d = (0, o.useContext)(u.O), m = (0, o.useContext)(a._).reducedMotion, g = (0, o.useRef)();
                                        n = n || s.renderer, !g.current && n && (g.current = n(t, {
                                            visualState: e,
                                            parent: r,
                                            props: i,
                                            presenceContext: d,
                                            blockInitialAnimation: !!d && !1 === d.initial,
                                            reducedMotionConfig: m
                                        }));
                                        let v = g.current;
                                        (0, o.useInsertionEffect)(() => {
                                            v && v.update(i, d)
                                        });
                                        let y = (0, o.useRef)(!!(i[p] && !window.HandoffComplete));
                                        return (0, h.L)(() => {
                                            v && (f.render(v.render), y.current && v.animationState && v.animationState.animateChanges())
                                        }), (0, o.useEffect)(() => {
                                            v && (v.updateFeatures(), !y.current && v.animationState && v.animationState.animateChanges(), y.current && (y.current = !1, window.HandoffComplete = !0))
                                        }), v
                                    }(r, A, P, e);
                                    let i = (0, o.useContext)(M),
                                        n = (0, o.useContext)(c).strict;
                                    S.visualElement && (x = S.visualElement.loadFeatures(P, n, t, i))
                                }
                                return (0, s.jsxs)(l.Provider, {
                                    value: S,
                                    children: [x && S.visualElement ? (0, s.jsx)(x, {
                                        visualElement: S.visualElement,
                                        ...P
                                    }) : null, i(r, d, (y = S.visualElement, (0, o.useCallback)(t => {
                                        t && A.mount && A.mount(t), y && (t ? y.mount(t) : y.unmount()), m && ("function" == typeof m ? m(t) : g(m) && (m.current = t))
                                    }, [y])), A, w, S.visualElement)]
                                })
                            });
                            return d[C] = r, d
                        }(t(e, i))
                    }
                    if ("undefined" == typeof Proxy) return e;
                    let i = new Map;
                    return new Proxy(e, {
                        get: (t, n) => (i.has(n) || i.set(n, e(n)), i.get(n))
                    })
                }((t, e) => (function(t, {
                    forwardMotionProps: e = !1
                }, i, n) {
                    return { ...j(t) ? tO : tF,
                        preloadedFeatures: i,
                        useRender: function(t = !1) {
                            return (e, i, n, {
                                latestValues: r
                            }, s) => {
                                let a = (j(e) ? function(t, e, i, n) {
                                        let r = (0, o.useMemo)(() => {
                                            let i = tx();
                                            return ty(i, e, {
                                                enableHardwareAcceleration: !1
                                            }, tP(n), t.transformTemplate), { ...i.attrs,
                                                style: { ...i.style
                                                }
                                            }
                                        }, [e]);
                                        if (t.style) {
                                            let e = {};
                                            tc(e, t.style, t), r.style = { ...e,
                                                ...r.style
                                            }
                                        }
                                        return r
                                    } : function(t, e, i) {
                                        let n = {},
                                            r = function(t, e, i) {
                                                let n = t.style || {},
                                                    r = {};
                                                return tc(r, n, t), Object.assign(r, function({
                                                    transformTemplate: t
                                                }, e, i) {
                                                    return (0, o.useMemo)(() => {
                                                        let n = th();
                                                        return tu(n, e, {
                                                            enableHardwareAcceleration: !i
                                                        }, t), Object.assign({}, n.vars, n.style)
                                                    }, [e])
                                                }(t, e, i)), r
                                            }(t, e, i);
                                        return t.drag && !1 !== t.dragListener && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (n.tabIndex = 0), n.style = r, n
                                    })(i, r, s, e),
                                    l = function(t, e, i) {
                                        let n = {};
                                        for (let r in t)("values" !== r || "object" != typeof t.values) && (tf(r) || !0 === i && tp(r) || !e && !tp(r) || t.draggable && r.startsWith("onDrag")) && (n[r] = t[r]);
                                        return n
                                    }(i, "string" == typeof e, t),
                                    u = e !== o.Fragment ? { ...l,
                                        ...a,
                                        ref: n
                                    } : {},
                                    {
                                        children: h
                                    } = i,
                                    c = (0, o.useMemo)(() => F(h) ? h.get() : h, [h]);
                                return (0, o.createElement)(e, { ...u,
                                    children: c
                                })
                            }
                        }(e),
                        createVisualElement: n,
                        Component: t
                    }
                })(t, e, r8, r7))
        },
        565: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        9047: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return r
                },
                k: function() {
                    return s
                }
            });
            var n = i(9276);
            let r = n.Z,
                s = n.Z
        },
        7282: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return n
                }
            });
            let n = "undefined" != typeof document
        },
        9276: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return n
                }
            });
            let n = t => t
        },
        458: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return r
                }
            });
            var n = i(2265);

            function r(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        9033: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(2265);
            let r = i(7282).j ? n.useLayoutEffect : n.useEffect
        }
    }
]);