(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [931], {
        7986: function(e, t, a) {
            Promise.resolve().then(a.bind(a, 5727))
        },
        5727: function(e, t, a) {
            "use strict";
            a.r(t), a.d(t, {
                default: function() {
                    return ec
                }
            });
            var s = a(7437),
                l = a(2265);
            let i = () => {
                    let e = window.location.hash.slice(1);
                    return c.includes(e) ? e : "index"
                },
                n = e => {
                    window.location.hash = e
                },
                r = async (e, t) => {
                    var a;
                    let s = await fetch(e);
                    if (!s.ok) throw Error("Failed to fetch resource: ".concat(e));
                    let l = null === (a = s.body) || void 0 === a ? void 0 : a.getReader(),
                        i = s.headers.get("Content-Length"),
                        n = i ? Number(i) : 0;
                    if (!l) return t && t(1), new Uint8Array;
                    let r = 0,
                        o = [];
                    for (;;) {
                        let {
                            done: e,
                            value: a
                        } = await l.read();
                        if (e) break;
                        o.push(a), r += a.length, t && n > 0 && t(r / n)
                    }
                    t && t(1);
                    let c = new Uint8Array(r),
                        d = 0;
                    for (let e of o) c.set(e, d), d += e.length;
                    return c
                },
                o = [],
                c = ["index", "products", "about-us", "careers"],
                d = e => "undefined" != typeof document && "true" === document.body.dataset.reservationModalOpen || e instanceof HTMLElement && !!e.closest('input, textarea, select, button, a, [data-slide-scroll-lock="true"], [data-slide-scrollable="true"]'),
                u = () => {
                    let [e, t] = (0, l.useState)({
                        direction: "",
                        distance: 0,
                        type: ""
                    }), [a, s] = (0, l.useState)(""), [u, h] = (0, l.useState)(!1), [x, m] = (0, l.useState)(!0), [f, p] = (0, l.useState)(0);
                    return (0, l.useEffect)(() => {
                        let e = i();
                        console.log("=================", e), s(e), n(e), console.log("initSlideId:", e)
                    }, []), (0, l.useEffect)(() => {
                        let e = e => {
                                if (d(e.target)) return;
                                let l = e.deltaY,
                                    i = l > 0 ? "down" : "up",
                                    r = "desktop";
                                if (t({
                                        direction: i,
                                        distance: Math.abs(l),
                                        type: r
                                    }), console.log("Scroll direction: ".concat(i, ", Distance: ").concat(Math.abs(l), ", Type: ").concat(r)), !u) {
                                    if ("down" === i && "careers" !== a) {
                                        let e = c[c.indexOf(a) + 1];
                                        s(e), n(e), h(!0), console.log("current slide down:", e)
                                    } else if ("up" === i && "index" !== a) {
                                        let e = c[c.indexOf(a) - 1];
                                        s(e), n(e), h(!0), console.log("current slide up:", e)
                                    } else console.log("do not wheel:", a)
                                }
                            },
                            l = 0,
                            i = e => {
                                if (d(e.target)) {
                                    l = 0;
                                    return
                                }
                                l = e.touches[0].clientY
                            },
                            r = e => {
                                if (d(e.target) || 0 === l) return;
                                let i = e.touches[0].clientY - l,
                                    r = i < 0 ? "down" : "up",
                                    o = "mobile";
                                if (t({
                                        direction: r,
                                        distance: Math.abs(i),
                                        type: o
                                    }), console.log("Swipe direction: ".concat(r, ", Distance: ").concat(Math.abs(i), ", Type: ").concat(o)), !u) {
                                    if ("down" === r && "careers" !== a) {
                                        let e = c[c.indexOf(a) + 1];
                                        s(e), n(e), h(!0), console.log("current slide down:", e)
                                    } else if ("up" === r && "index" !== a) {
                                        let e = c[c.indexOf(a) - 1];
                                        s(e), n(e), h(!0), console.log("current slide up:", e)
                                    } else console.log("do not swipe:", a)
                                }
                            };
                        return window.addEventListener("wheel", e), window.addEventListener("touchstart", i), window.addEventListener("touchmove", r), () => {
                            window.removeEventListener("wheel", e), window.removeEventListener("touchstart", i), window.removeEventListener("touchmove", r)
                        }
                    }, [a, u]), (0, l.useEffect)(() => {
                        if (u) {
                            let e = setTimeout(() => {
                                h(!1), console.log("Animation ended")
                            }, 1e3);
                            return () => clearTimeout(e)
                        }
                    }, [u]), (0, l.useEffect)(() => {
                        (async () => {
                            if (0 === o.length) {
                                p(1), m(!1);
                                return
                            }
                            let e = 0;
                            try {
                                for (let t = 0; t < o.length; t++) try {
                                    await r(o[t], t => {
                                        p((e + t) / o.length)
                                    })
                                } catch (e) {
                                    console.error("download resource failed:", o[t], e)
                                } finally {
                                    e++, p(e / o.length)
                                }
                            } finally {
                                m(!1)
                            }
                        })()
                    }, [!1]), {
                        currentSlideId: a,
                        updateSlideId: e => {
                            u || x || (s(e), n(e), h(!0), console.log("updateSlideId:", e))
                        },
                        isAnimating: u,
                        setIsAnimating: h,
                        isLoading: x,
                        setIsLoading: m,
                        scrollInfo: e,
                        progress: f
                    }
                },
                h = (0, l.createContext)(null),
                x = e => {
                    let {
                        children: t
                    } = e, {
                        currentSlideId: a,
                        updateSlideId: l,
                        isAnimating: i,
                        setIsAnimating: n,
                        isLoading: r,
                        setIsLoading: o,
                        scrollInfo: c,
                        progress: d
                    } = u();
                    return (0, s.jsx)(h.Provider, {
                        value: {
                            currentSlideId: a,
                            updateSlideId: l,
                            isAnimating: i,
                            setIsAnimating: n,
                            isLoading: r,
                            setIsLoading: o,
                            scrollInfo: c,
                            progress: d
                        },
                        children: t
                    })
                },
                m = () => (0, l.useContext)(h);
            var f = a(5127),
                p = a(4599);
            let g = ["/assets/index/slides/slide-2.webp", "/assets/index/slides/slide-1.webp", "/assets/index/slides/slide-3.webp"],
                b = 3 / 4;
            var v = a(7138),
                w = a(4887);
            let y = /^(?:\+?86)?1[3-9]\d{9}$/,
                j = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
                N = new Set(["Asia/Shanghai", "Asia/Chongqing", "Asia/Harbin", "Asia/Urumqi", "Asia/Hong_Kong", "Asia/Macau", "Asia/Taipei"]),
                k = new Set(["CN", "HK", "MO", "TW"]),
                E = new Set(["Asia/Shanghai", "Asia/Chongqing", "Asia/Harbin"]),
                S = e => {
                    let t = e.trim().toLowerCase();
                    return !!t && ("zh" === t || t.startsWith("zh-cn") || t.startsWith("zh-hans") || t.startsWith("zh-sg"))
                },
                C = () => {
                    let e = Array.isArray(navigator.languages) && navigator.languages.length > 0 ? navigator.languages : [navigator.language || ""];
                    return {
                        prefersChinese: e.some(e => /^zh(?:-|$)/i.test(e)),
                        prefersSimplifiedChinese: e.some(e => S(e)),
                        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || ""
                    }
                },
                I = e => {
                    let {
                        prefersChinese: t,
                        timezone: a
                    } = C();
                    return !!(e.countryCode && k.has(e.countryCode) || t || N.has(a))
                },
                T = e => {
                    if ("CN" === e.countryCode) return "phone";
                    if (e.countryCode) return "email";
                    let {
                        prefersSimplifiedChinese: t,
                        timezone: a
                    } = C();
                    return t && E.has(a) ? "phone" : "email"
                },
                P = e => {
                    let t = e.trim().replace(/[\s-]/g, "");
                    return t.startsWith("+86") ? t : t.startsWith("86") ? "+".concat(t) : "+86".concat(t)
                },
                O = e => {
                    let {
                        isOpen: t,
                        onClose: a,
                        onSubmitted: i
                    } = e, [n, r] = (0, l.useState)(""), [o, c] = (0, l.useState)(""), [d, u] = (0, l.useState)(""), [h, x] = (0, l.useState)(""), [m, f] = (0, l.useState)(""), [p, g] = (0, l.useState)(""), [b, N] = (0, l.useState)(""), [k, E] = (0, l.useState)(!1), [S, C] = (0, l.useState)(!1), [O, A] = (0, l.useState)(!1), [L, M] = (0, l.useState)("email"), [_, z] = (0, l.useState)(!0), [F, D] = (0, l.useState)(""), [R, Y] = (0, l.useState)(!1), [U, W] = (0, l.useState)(!1), [B, V] = (0, l.useState)(!1), [q, X] = (0, l.useState)(!1), [G, H] = (0, l.useState)(!1), [K, J] = (0, l.useState)(""), [Q, Z] = (0, l.useState)(0), [$, ee] = (0, l.useState)(null), [et, ea] = (0, l.useState)(""), [es, el] = (0, l.useState)(""), [ei, en] = (0, l.useState)(""), [er, eo] = (0, l.useState)(null), [ec, ed] = (0, l.useState)(!1), eu = (0, l.useRef)(null);
                    (0, l.useEffect)(() => (ed(!0), () => ed(!1)), []), (0, l.useEffect)(() => {
                        let e = !0;
                        return (async () => {
                            let t = () => {
                                M(T({})), z(I({}))
                            };
                            try {
                                var a;
                                let s = await fetch("/api/geo/visitor-region", {
                                        method: "GET",
                                        cache: "no-store"
                                    }),
                                    l = await s.json();
                                if (!s.ok || !l.success || !e) {
                                    t();
                                    return
                                }
                                let i = String((null === (a = l.data) || void 0 === a ? void 0 : a.countryCode) || "").toUpperCase() || null;
                                M(T({
                                    countryCode: i
                                })), z(I({
                                    countryCode: i
                                }))
                            } catch (e) {
                                t()
                            }
                        })(), () => {
                            e = !1
                        }
                    }, []), (0, l.useEffect)(() => () => {
                        document.body.removeAttribute("data-reservation-modal-open")
                    }, []), (0, l.useEffect)(() => {
                        if (!t) {
                            document.body.removeAttribute("data-reservation-modal-open"), r(""), c(""), u(""), x(""), f(""), g(""), N(""), E(!1), C(!1), A(!1), D(""), Y(!1), W(!1), V(!1), H(!1), J(""), ea(""), el(""), en(""), eo(null);
                            return
                        }
                        document.body.setAttribute("data-reservation-modal-open", "true"), eb()
                    }, [t]), (0, l.useEffect)(() => {
                        if (!$) {
                            Z(0);
                            return
                        }
                        let e = () => {
                            let e = Math.max(0, Math.ceil(($ - Date.now()) / 1e3));
                            Z(e), e <= 0 && ee(null)
                        };
                        e();
                        let t = window.setInterval(e, 1e3);
                        return () => window.clearInterval(t)
                    }, [$]);
                    let eh = !_,
                        ex = (0, l.useMemo)(() => ({
                            title: eh ? "Scarlet Tide: ZeroERA Reservation" : "赤潮：零纪元 预约",
                            subtitle: eh ? "Verify your real contact information before submitting your reservation." : "先完成真实联系方式验证，再提交预约",
                            closeLabel: eh ? "Close" : "关闭",
                            successTitle: O ? eh ? "Reservation already confirmed" : "你已完成预约" : eh ? "Reservation successful" : "预约成功",
                            successRank: eh ? "You are reservation No. ".concat(er) : "你是第 ".concat(er, " 位预约用户"),
                            successDesc: O ? eh ? "This contact already has an existing reservation. Future test and launch updates will still be sent to your verified contact." : "该联系方式已存在预约记录，后续测试或上线仍会通过你验证过的联系方式通知。" : eh ? "Thank you. We will send future test and launch updates to your verified contact." : "感谢关注。后续测试与上线会通过你验证过的联系方式通知。",
                            nameLabel: eh ? "Name or nickname *" : "姓名或昵称 *",
                            namePlaceholder: eh ? "Enter your name or nickname" : "请输入你的昵称",
                            contactLabel: "phone" === L ? eh ? "Phone number *" : "手机号 *" : eh ? "Email *" : "邮箱 *",
                            contactPlaceholder: "phone" === L ? eh ? "Enter your mainland China phone number" : "请输入中国大陆手机号" : eh ? "Enter your email, e.g. name@example.com" : "请输入有效邮箱地址",
                            sendCode: eh ? "Send code" : "发送验证码",
                            sendingCode: eh ? "Sending..." : "发送中...",
                            resendSuffix: eh ? "s" : "秒",
                            captcha: eh ? "Captcha *" : "图形验证码 *",
                            captchaPlaceholder: eh ? "Enter captcha" : "请输入图形验证码",
                            captchaLoading: eh ? "Loading..." : "加载中...",
                            captchaRefresh: eh ? "Refresh" : "刷新",
                            verificationCode: eh ? "Verification code *" : "短信/邮箱验证码 *",
                            verificationPlaceholder: eh ? "Enter the 6-digit code" : "请输入 6 位数字验证码",
                            platform: eh ? "Primary device" : "常用设备",
                            platformPlaceholder: eh ? "Select a device" : "请选择设备",
                            platformIOS: "iOS",
                            platformAndroid: "Android",
                            platformPC: "PC",
                            platformUnknown: eh ? "Not sure yet" : "未确定",
                            social: eh ? "Primary social media platform" : "常用社交平台",
                            socialPlaceholder: eh ? "Select a platform" : "请选择平台",
                            socialBilibili: eh ? "Bilibili" : "哔哩哔哩",
                            socialXiaohongshu: eh ? "Xiaohongshu" : "小红书",
                            socialDouyin: eh ? "Douyin" : "抖音",
                            socialKuaishou: eh ? "Kuaishou" : "快手",
                            socialWeibo: eh ? "Weibo" : "微博",
                            socialWeChatChannels: eh ? "WeChat Channels" : "微信视频号",
                            socialX: eh ? "X (Twitter)" : "X（Twitter）",
                            socialTikTok: "TikTok",
                            socialInstagram: "Instagram",
                            socialFacebook: "Facebook",
                            socialReddit: "Reddit",
                            socialYouTube: "YouTube",
                            socialOther: eh ? "Other" : "其他",
                            note: eh ? "Notes (optional)" : "备注（可选）",
                            notePlaceholder: eh ? "For example: gameplay, art style, test expectations" : "例如：玩法、美术风格、测试期待",
                            verified: eh ? "Verification code confirmed" : "验证码已通过校验",
                            termsPrefix: eh ? "I have read and agree to the " : "我已阅读并同意 ",
                            termsAnd: eh ? " and " : " 与 ",
                            userAgreement: eh ? "Terms of Service" : "《用户协议》",
                            privacyPolicy: eh ? "Privacy Policy" : "《隐私政策》",
                            submit: eh ? "Reserve now" : "立即预约",
                            submitting: eh ? "Submitting..." : "提交中...",
                            verifying: eh ? "Verifying..." : "校验中...",
                            invalidPhone: eh ? "Invalid phone number format" : "手机号格式不正确",
                            invalidEmail: eh ? "Invalid email format" : "邮箱格式不正确",
                            needPhone: eh ? "Please enter a valid mainland China phone number first" : "请先输入有效的中国大陆手机号",
                            needEmail: eh ? "Please enter a valid email address first" : "请先输入有效邮箱地址",
                            needCaptcha: eh ? "Please complete the captcha first" : "请先输入图形验证码",
                            codeFormat: eh ? "Please enter the 6-digit verification code" : "请输入 6 位数字验证码",
                            codeTooMany: eh ? "Too many failed attempts. Please request a new code." : "验证码错误次数过多，请重新发送",
                            codeExpired: eh ? "The verification code has expired. Please request a new one." : "验证码已过期，请重新发送",
                            codeInvalid: eh ? "Incorrect verification code. Please try again." : "验证码错误，请重试",
                            codeVerifyFailed: eh ? "Verification failed. Please try again later." : "验证码校验失败，请稍后重试",
                            captchaLoadFailed: eh ? "Captcha failed to load. Please try again later." : "图形验证码加载失败，请稍后重试",
                            captchaInvalid: eh ? "Incorrect captcha. Please try again." : "图形验证码错误，请重试",
                            captchaExpired: eh ? "Captcha expired. Please refresh and try again." : "图形验证码已失效，请刷新后重试",
                            sendTooFrequent: eh ? "Too many requests. Please try again later." : "发送过于频繁，请稍后再试",
                            rateLimitIp: eh ? "Too many requests from this network. Please try again later." : "当前网络请求过于频繁，请稍后再试",
                            rateLimitDevice: eh ? "Too many requests from this device. Please try again later." : "当前设备请求过于频繁，请稍后再试",
                            rateLimitContact: eh ? "Too many requests for this contact. Please try again in one hour." : "该联系方式请求过于频繁，请一小时后再试",
                            sendFailed: eh ? "Failed to send the verification code. Please try again later." : "验证码发送失败，请稍后重试",
                            sendNetworkFailed: eh ? "Failed to send the verification code. Please check your network and try again." : "验证码发送失败，请检查网络后重试",
                            fillName: eh ? "Please enter your name or nickname" : "请填写姓名或昵称",
                            acceptTerms: eh ? "Please read and accept the Terms of Service and Privacy Policy." : "请先勾选同意用户协议和隐私政策",
                            submitFailed: eh ? "Failed to submit your reservation. Please try again later." : "预约提交失败，请稍后重试",
                            verificationExpired: eh ? "Your verification session expired. Please request and verify a new code." : "验证状态已失效，请重新发送并校验验证码",
                            captchaPrompt: eh ? "Complete human verification before sending the code." : "发送验证码前请先完成人机验证",
                            captchaAlt: eh ? "captcha image" : "图形验证码图片",
                            cancel: eh ? "Cancel" : "取消"
                        }), [O, L, eh, er]),
                        em = (0, l.useMemo)(() => "phone" === L ? P(o) : o.trim().toLowerCase(), [L, o]),
                        ef = (0, l.useMemo)(() => !!o.trim() && ("phone" === L ? y.test(em) : j.test(em)), [L, o, em]);
                    if (!t) return null;
                    let ep = () => {
                            u(""), ea("")
                        },
                        eg = async () => {
                            if (!ef) return D("phone" === L ? ex.invalidPhone : ex.invalidEmail), null;
                            if (!/^\d{6}$/.test(d.trim())) return D(ex.codeFormat), null;
                            D(""), W(!0);
                            try {
                                let e = await fetch("/api/verification/verify", {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            channel: L,
                                            contact: em,
                                            code: d.trim()
                                        })
                                    }),
                                    t = await e.json();
                                if (!e.ok || !t.success) return "CODE_ATTEMPTS_EXCEEDED" === t.error ? D(ex.codeTooMany) : "CODE_NOT_FOUND" === t.error ? D(ex.codeExpired) : D(ex.codeInvalid), null;
                                let a = t.data.ticket;
                                return ea(a), a
                            } catch (e) {
                                return D(ex.codeVerifyFailed), null
                            } finally {
                                W(!1)
                            }
                        },
                        eb = async (e, t) => {
                            var a;
                            let s = null === (a = null == t ? void 0 : t.clearModalError) || void 0 === a || a;
                            X(!0);
                            try {
                                let t = await fetch("/api/verification/captcha", {
                                        method: "GET",
                                        cache: "no-store"
                                    }),
                                    a = await t.json();
                                if (!t.ok || !a.success) {
                                    e ? e(ex.captchaLoadFailed) : D(ex.captchaLoadFailed);
                                    return
                                }
                                el(a.data.ticket), en(a.data.image), x(""), s && J("")
                            } catch (t) {
                                e ? e(ex.captchaLoadFailed) : D(ex.captchaLoadFailed)
                            } finally {
                                X(!1)
                            }
                        },
                        ev = async () => {
                            if (!es || !h.trim()) {
                                J(ex.needCaptcha);
                                return
                            }
                            if (!ef) {
                                D("phone" === L ? ex.needPhone : ex.needEmail);
                                return
                            }
                            D(""), J(""), Y(!0);
                            try {
                                var e;
                                let t = {
                                        channel: L,
                                        contact: em,
                                        captchaTicket: es,
                                        captchaCode: h.trim().toUpperCase()
                                    },
                                    a = await fetch("/api/verification/send", {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify(t)
                                    }),
                                    s = await a.json();
                                if (!a.ok || !s.success) {
                                    "SEND_TOO_FREQUENT" === s.error ? D(ex.sendTooFrequent) : "RATE_LIMIT_IP" === s.error ? D(ex.rateLimitIp) : "RATE_LIMIT_DEVICE" === s.error ? D(ex.rateLimitDevice) : "RATE_LIMIT_CONTACT" === s.error ? D(ex.rateLimitContact) : "INVALID_CONTACT" === s.error ? D("phone" === L ? ex.invalidPhone : ex.invalidEmail) : "CAPTCHA_INVALID" === s.error ? J(ex.captchaInvalid) : "CAPTCHA_EXPIRED" === s.error ? J(ex.captchaExpired) : D(ex.sendFailed), await eb(J, {
                                        clearModalError: !1
                                    });
                                    return
                                }
                                ep();
                                let l = (null === (e = s.data) || void 0 === e ? void 0 : e.cooldownSeconds) || 60;
                                ee(Date.now() + 1e3 * l), Z(l), H(!1), await eb()
                            } catch (e) {
                                D(ex.sendNetworkFailed)
                            } finally {
                                Y(!1)
                            }
                        },
                        ew = async () => {
                            if (!ef) {
                                D("phone" === L ? ex.needPhone : ex.needEmail);
                                return
                            }
                            x(""), J(""), H(!0), await eb(J), window.setTimeout(() => {
                                var e;
                                return null === (e = eu.current) || void 0 === e ? void 0 : e.focus()
                            }, 0)
                        },
                        ey = async e => {
                            if (e.preventDefault(), !n.trim()) {
                                D(ex.fillName);
                                return
                            }
                            if (!ef) {
                                D("phone" === L ? ex.invalidPhone : ex.invalidEmail);
                                return
                            }
                            if (!k) {
                                D(ex.acceptTerms);
                                return
                            }
                            let t = et || await eg();
                            if (t) {
                                D(""), V(!0);
                                try {
                                    var a, s, l, r, o;
                                    let e = await fetch("/api/reservations/zeroera", {
                                            method: "POST",
                                            headers: {
                                                "Content-Type": "application/json"
                                            },
                                            body: JSON.stringify({
                                                name: n.trim(),
                                                channel: L,
                                                contact: em,
                                                platform: m,
                                                socialPlatform: p,
                                                message: b.trim(),
                                                verificationTicket: t
                                            })
                                        }),
                                        c = await e.json();
                                    if (!e.ok || !c.success) {
                                        "VERIFICATION_REQUIRED" === c.error || "VERIFICATION_MISMATCH" === c.error ? (D(ex.verificationExpired), ea("")) : D(ex.submitFailed);
                                        return
                                    }
                                    eo(null !== (r = null === (a = c.data) || void 0 === a ? void 0 : a.reservationNumber) && void 0 !== r ? r : null), A(!!(null === (s = c.data) || void 0 === s ? void 0 : s.alreadyReserved)), null == i || i(null !== (o = null === (l = c.data) || void 0 === l ? void 0 : l.reservationNumber) && void 0 !== o ? o : null), C(!0)
                                } catch (e) {
                                    D(ex.submitFailed)
                                } finally {
                                    V(!1)
                                }
                            }
                        },
                        ej = (0, s.jsxs)("div", {
                            className: "fixed inset-0 isolate flex items-center justify-center bg-black/70 px-4",
                            style: {
                                zIndex: 2147483e3
                            },
                            children: [(0, s.jsxs)("div", {
                                "data-slide-scroll-lock": "true",
                                "data-slide-scrollable": "true",
                                className: "max-h-[88vh] w-full max-w-md overflow-y-auto rounded-md border border-white/30 bg-[#111] text-white shadow-2xl",
                                children: [(0, s.jsxs)("div", {
                                    className: "sticky top-0 z-10 flex items-start justify-between border-b border-white/10 bg-[#111] px-5 pb-4 pt-5",
                                    children: [(0, s.jsxs)("div", {
                                        className: "pr-4",
                                        children: [(0, s.jsx)("h3", {
                                            className: "text-xl font-oswald-heavy",
                                            children: ex.title
                                        }), (0, s.jsx)("p", {
                                            className: "mt-1 text-xs text-white/70",
                                            children: ex.subtitle
                                        })]
                                    }), (0, s.jsxs)("button", {
                                        type: "button",
                                        onClick: a,
                                        "aria-label": ex.closeLabel,
                                        className: "relative z-20 ml-4 flex h-12 w-12 shrink-0 items-center justify-center self-start rounded-full border border-white/20 transition hover:bg-white/10",
                                        children: [(0, s.jsx)("span", {
                                            className: "pointer-events-none absolute left-1/2 top-1/2 h-[1.5px] w-4 -translate-x-1/2 -translate-y-1/2 rotate-45 bg-white"
                                        }), (0, s.jsx)("span", {
                                            className: "pointer-events-none absolute left-1/2 top-1/2 h-[1.5px] w-4 -translate-x-1/2 -translate-y-1/2 -rotate-45 bg-white"
                                        })]
                                    })]
                                }), S ? (0, s.jsxs)("div", {
                                    className: "relative overflow-hidden rounded border border-golden/60 bg-golden/10 p-4 text-sm",
                                    children: [(0, s.jsx)("div", {
                                        className: "pointer-events-none absolute inset-0 overflow-hidden",
                                        children: Array.from({
                                            length: 18
                                        }).map((e, t) => (0, s.jsx)("span", {
                                            className: "confetti-piece",
                                            style: {
                                                left: "".concat(13 * t % 100, "%"),
                                                animationDelay: "".concat(.08 * t, "s"),
                                                animationDuration: "".concat(2.6 + t % 5 * .25, "s")
                                            }
                                        }, t))
                                    }), (0, s.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, s.jsx)("p", {
                                            className: "text-base font-source-han-sans-sc-heavy text-golden",
                                            children: ex.successTitle
                                        }), null !== er ? (0, s.jsx)("p", {
                                            className: "mt-2 text-lg font-source-han-sans-sc-heavy text-white",
                                            children: ex.successRank
                                        }) : null, (0, s.jsx)("p", {
                                            className: "mt-2 text-sm text-white/82",
                                            children: ex.successDesc
                                        })]
                                    })]
                                }) : (0, s.jsxs)("form", {
                                    onSubmit: ey,
                                    className: "space-y-3 px-5 py-5",
                                    children: [(0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.nameLabel
                                        }), (0, s.jsx)("input", {
                                            value: n,
                                            onChange: e => {
                                                r(e.target.value), F && D("")
                                            },
                                            className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                            placeholder: ex.namePlaceholder
                                        })]
                                    }), (0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.contactLabel
                                        }), (0, s.jsxs)("div", {
                                            className: "flex gap-2",
                                            children: [(0, s.jsx)("input", {
                                                value: o,
                                                onChange: e => {
                                                    c(e.target.value), ep(), F && D("")
                                                },
                                                type: "phone" === L ? "tel" : "email",
                                                className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                                placeholder: ex.contactPlaceholder
                                            }), (0, s.jsx)("button", {
                                                type: "button",
                                                disabled: R || Q > 0,
                                                onClick: ew,
                                                className: "min-w-[120px] rounded border border-golden px-3 py-2 text-xs text-golden disabled:cursor-not-allowed disabled:opacity-50",
                                                children: Q > 0 ? "".concat(Q).concat(ex.resendSuffix) : R ? ex.sendingCode : ex.sendCode
                                            })]
                                        })]
                                    }), (0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.verificationCode
                                        }), (0, s.jsx)("div", {
                                            className: "flex gap-2",
                                            children: (0, s.jsx)("input", {
                                                value: d,
                                                onChange: e => {
                                                    u(e.target.value.replace(/\D/g, "").slice(0, 6)), F && D("")
                                                },
                                                inputMode: "numeric",
                                                maxLength: 6,
                                                className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                                placeholder: ex.verificationPlaceholder
                                            })
                                        })]
                                    }), (0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.platform
                                        }), (0, s.jsxs)("select", {
                                            value: m,
                                            onChange: e => f(e.target.value),
                                            className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                            children: [(0, s.jsx)("option", {
                                                value: "",
                                                disabled: !0,
                                                children: ex.platformPlaceholder
                                            }), (0, s.jsx)("option", {
                                                value: "iOS",
                                                children: ex.platformIOS
                                            }), (0, s.jsx)("option", {
                                                value: "Android",
                                                children: ex.platformAndroid
                                            }), (0, s.jsx)("option", {
                                                value: "PC",
                                                children: ex.platformPC
                                            }), (0, s.jsx)("option", {
                                                value: ex.platformUnknown,
                                                children: ex.platformUnknown
                                            })]
                                        })]
                                    }), (0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.social
                                        }), (0, s.jsxs)("select", {
                                            value: p,
                                            onChange: e => g(e.target.value),
                                            className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                            children: [(0, s.jsx)("option", {
                                                value: "",
                                                disabled: !0,
                                                children: ex.socialPlaceholder
                                            }), (0, s.jsx)("option", {
                                                value: "Bilibili",
                                                children: ex.socialBilibili
                                            }), (0, s.jsx)("option", {
                                                value: "Xiaohongshu",
                                                children: ex.socialXiaohongshu
                                            }), (0, s.jsx)("option", {
                                                value: "Douyin",
                                                children: ex.socialDouyin
                                            }), (0, s.jsx)("option", {
                                                value: "Kuaishou",
                                                children: ex.socialKuaishou
                                            }), (0, s.jsx)("option", {
                                                value: "Weibo",
                                                children: ex.socialWeibo
                                            }), (0, s.jsx)("option", {
                                                value: "WeChat Channels",
                                                children: ex.socialWeChatChannels
                                            }), (0, s.jsx)("option", {
                                                value: "X",
                                                children: ex.socialX
                                            }), (0, s.jsx)("option", {
                                                value: "TikTok",
                                                children: ex.socialTikTok
                                            }), (0, s.jsx)("option", {
                                                value: "Instagram",
                                                children: ex.socialInstagram
                                            }), (0, s.jsx)("option", {
                                                value: "Facebook",
                                                children: ex.socialFacebook
                                            }), (0, s.jsx)("option", {
                                                value: "Reddit",
                                                children: ex.socialReddit
                                            }), (0, s.jsx)("option", {
                                                value: "YouTube",
                                                children: ex.socialYouTube
                                            }), (0, s.jsx)("option", {
                                                value: "Other",
                                                children: ex.socialOther
                                            })]
                                        })]
                                    }), (0, s.jsxs)("label", {
                                        className: "block",
                                        children: [(0, s.jsx)("span", {
                                            className: "mb-1 block text-xs text-white/70",
                                            children: ex.note
                                        }), (0, s.jsx)("textarea", {
                                            value: b,
                                            onChange: e => N(e.target.value),
                                            className: "h-24 w-full resize-none rounded border border-white/30 bg-black/40 px-3 py-2 text-sm outline-none focus:border-golden",
                                            placeholder: ex.notePlaceholder
                                        })]
                                    }), (0, s.jsx)("div", {
                                        className: "h-44"
                                    }), (0, s.jsxs)("div", {
                                        className: "sticky bottom-0 -mx-5 space-y-3 border-t border-white/10 bg-[#111] px-5 pb-5 pt-4",
                                        children: [et ? (0, s.jsx)("p", {
                                            className: "text-xs text-golden",
                                            children: ex.verified
                                        }) : null, (0, s.jsxs)("label", {
                                            className: "flex items-start gap-3 text-xs leading-5 text-white/72",
                                            children: [(0, s.jsx)("input", {
                                                type: "checkbox",
                                                checked: k,
                                                onChange: e => {
                                                    E(e.target.checked), F && D("")
                                                },
                                                className: "mt-1 h-4 w-4 rounded border border-white/30 bg-black/40 accent-[#d6aa59]"
                                            }), (0, s.jsxs)("span", {
                                                children: [ex.termsPrefix, (0, s.jsx)(v.default, {
                                                    href: "/user-agreement",
                                                    target: "_blank",
                                                    className: "text-golden underline underline-offset-2",
                                                    children: ex.userAgreement
                                                }), ex.termsAnd, (0, s.jsx)(v.default, {
                                                    href: "/privacy-policy",
                                                    target: "_blank",
                                                    className: "text-golden underline underline-offset-2",
                                                    children: ex.privacyPolicy
                                                })]
                                            })]
                                        }), F ? (0, s.jsx)("p", {
                                            className: "text-xs text-[#ff8f8f]",
                                            children: F
                                        }) : null, (0, s.jsx)("button", {
                                            type: "submit",
                                            disabled: B || U,
                                            className: "w-full rounded bg-golden px-4 py-3 text-sm font-bold text-black hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-70",
                                            children: U ? ex.verifying : B ? ex.submitting : ex.submit
                                        })]
                                    })]
                                })]
                            }), G ? (0, s.jsx)("div", {
                                className: "fixed inset-0 isolate flex items-center justify-center bg-black/65 px-4",
                                style: {
                                    zIndex: 2147483001
                                },
                                children: (0, s.jsxs)("div", {
                                    className: "w-full max-w-sm rounded-md border border-white/30 bg-[#141414] p-4 shadow-2xl",
                                    children: [(0, s.jsx)("p", {
                                        className: "text-sm font-source-han-sans-sc-heavy text-white",
                                        children: ex.captcha
                                    }), (0, s.jsx)("p", {
                                        className: "mt-1 text-xs text-white/70",
                                        children: ex.captchaPrompt
                                    }), (0, s.jsxs)("div", {
                                        className: "mt-3 flex gap-2",
                                        children: [(0, s.jsx)("input", {
                                            ref: eu,
                                            value: h,
                                            onChange: e => {
                                                x(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 4)), K && J("")
                                            },
                                            className: "w-full rounded border border-white/30 bg-black/40 px-3 py-2 text-sm uppercase outline-none focus:border-golden",
                                            placeholder: ex.captchaPlaceholder
                                        }), (0, s.jsx)("button", {
                                            type: "button",
                                            onClick: () => void eb(J),
                                            disabled: q,
                                            className: "overflow-hidden rounded border border-white/30 bg-black/20 disabled:cursor-not-allowed disabled:opacity-50",
                                            children: ei ? (0, s.jsx)("img", {
                                                src: ei,
                                                alt: ex.captchaAlt,
                                                className: "h-[42px] w-[132px] object-cover"
                                            }) : (0, s.jsx)("span", {
                                                className: "block min-w-[132px] px-3 text-xs text-white/70",
                                                children: q ? ex.captchaLoading : ex.captchaRefresh
                                            })
                                        })]
                                    }), K ? (0, s.jsx)("p", {
                                        className: "mt-2 text-xs text-[#ff8f8f]",
                                        children: K
                                    }) : null, (0, s.jsxs)("div", {
                                        className: "mt-4 flex justify-end gap-2",
                                        children: [(0, s.jsx)("button", {
                                            type: "button",
                                            className: "rounded border border-white/30 px-3 py-2 text-xs text-white/80 hover:bg-white/10",
                                            onClick: () => {
                                                H(!1), J("")
                                            },
                                            children: ex.cancel
                                        }), (0, s.jsx)("button", {
                                            type: "button",
                                            disabled: R || q,
                                            className: "rounded bg-golden px-3 py-2 text-xs font-bold text-black disabled:cursor-not-allowed disabled:opacity-70",
                                            onClick: () => void ev(),
                                            children: R ? ex.sendingCode : ex.sendCode
                                        })]
                                    })]
                                })
                            }) : null]
                        });
                    return ec ? (0, w.createPortal)(ej, document.body) : null
                },
                A = () => {
                    let {
                        currentSlideId: e,
                        isLoading: t
                    } = m(), a = (0, l.useMemo)(() => "products" === e ? "Products" : "", [e]);
                    return t ? null : (0, s.jsx)("div", {
                        className: "z-20 absolute  left-0 bottom-0  text-white uppercase font-oswald-heavy text-2xl lg:text-[64px] lg:h-[134px] lg:pl-[64px] lg:pt-[23px]",
                        children: a
                    })
                },
                L = e => {
                    let {
                        title: t,
                        description: a,
                        width: l,
                        height: i
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "flex flex-row justify-start items-end border-b border-golden bg-section-header-bg bg-no-repeat bg-left bg-contain mt-2 w-4/5 h-9 lg:h-24",
                        style: {
                            width: l ? "".concat(l, "px") : void 0,
                            height: i ? "".concat(i, "px") : void 0
                        },
                        children: (0, s.jsxs)("div", {
                            className: "h-full flex flex-col justify-items-center items-start ml-6 font-source-han-sans-sc-medium",
                            children: [(0, s.jsx)("h1", {
                                className: "text-primary-black text-sm lg:text-xl font-bold",
                                children: t
                            }), (0, s.jsx)("h2", {
                                className: "text-primary-black text-xs lg:text-xs",
                                children: a
                            })]
                        })
                    })
                };
            L.defaultProps = {
                width: void 0,
                height: void 0
            };
            let M = () => (0, s.jsxs)("div", {
                    className: "w-[328px] font-source-han-sans-sc-medium text-left text-xs not-italic leading-6 text-white whitespace-pre-line lg:text-[14px]",
                    children: ["悠喵YoMio由一群00后于2022年创立，是一支年轻且充满活力的初创团队，致力于二次元ACG文化在各领域的深度探索。出于对二次元文化最本真的热爱，我们相聚于此，先后与众多知名游戏企业展开内容合作。2024年，我们决定书写属于自己的故事——推出原创游戏IP《赤潮：零纪元》，并围绕其打造动画、音乐、周边、漫展等多元内容矩阵。目前，《赤潮：零纪元》已在全球范围内收获超过35万粉丝的关注与期待。\n\n目前悠喵总部位于上海，团队全职伙伴数十人，核心成员来自清华大学、北京大学、中国传媒大学、加州大学伯克利分校、威斯康星大学麦迪逊分校等海内外知名高校及头部游戏/互联网公司。团队氛围轻松融洽，北京office常驻三只猫，等你来rua！\n\n“悠喵必映”，中文谐音“有猫必应”，英文寓意“保持初心”，“必映”亦与“BeYoung”谐音。我们秉承“致心中最初的光”的愿景——永远对所追寻的事业保持热爱，铭记它最初带来的感动，让那份感动成为前行的原动力。时空流转会让人遗忘许多，长河冲刷只留下细沙卵石，但从来熄灭不了的，是那份炽热的信念。\n", "联系方式: ", (0, s.jsx)("a", {
                        href: "mailto:hi@yomio.cn",
                        children: "hi@yomio.cn"
                    })]
                }),
                _ = () => (0, s.jsx)("div", {
                    className: "lg:hidden black h-full w-full flex flex-col justify-start items-start",
                    children: (0, s.jsx)("div", {
                        "data-slide-scroll-lock": "true",
                        "data-slide-scrollable": "true",
                        className: "h-full w-full overflow-y-auto px-4 pb-24",
                        children: (0, s.jsxs)("div", {
                            className: "mx-auto flex w-mobile-without-right-width flex-col justify-start items-center bg-opacity-90",
                            children: [(0, s.jsx)("div", {
                                className: "relative h-[200px] w-full bg-cover bg-center bg-black bg-about-mobile-header",
                                children: (0, s.jsx)("div", {
                                    className: "absolute inset-0 bg-black bg-opacity-10"
                                })
                            }), (0, s.jsx)("img", {
                                src: "/assets/about-us/about-header.webp",
                                alt: "quote",
                                className: "mt-4 w-mobile-without-right-width"
                            }), (0, s.jsxs)("div", {
                                className: "px-4",
                                children: [(0, s.jsx)(L, {
                                    title: "关于 Yomio",
                                    description: "ABOUT YOMIO"
                                }), (0, s.jsx)(M, {})]
                            })]
                        })
                    })
                }),
                z = e => {
                    let {
                        title: t,
                        description: a
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "flex flex-row justify-start items-center w-full lg:w-full lg:h-[48px]  text-[#070707] text-xl font-bold ",
                        children: (0, s.jsx)("div", {
                            className: "w-8/12 lg:w-[500px] border-b-2 border-golden",
                            children: (0, s.jsxs)("div", {
                                className: "h-full flex flex-col justify-center items-center lg:w-[168px] w-[140px] ",
                                style: {
                                    backgroundImage: "url('/assets/common/section-title-bg.webp')",
                                    backgroundSize: "cover"
                                },
                                children: [(0, s.jsx)("div", {
                                    children: (0, s.jsx)("span", {
                                        className: "text-[#070707] text-xl font-bold",
                                        children: t
                                    })
                                }), (0, s.jsx)("span", {
                                    className: " text-[#070707] text-xs",
                                    children: a
                                })]
                            })
                        })
                    })
                },
                F = () => {
                    let {
                        currentSlideId: e
                    } = m();
                    return (0, s.jsxs)(p.E.div, {
                        id: "about-info",
                        "data-slide-scroll-lock": "true",
                        "data-slide-scrollable": "true",
                        className: "z-20 flex h-[calc(100vh-6rem)] w-[408px] flex-shrink-0 flex-grow-0 flex-col items-center justify-start overflow-y-auto overscroll-contain bg-black bg-opacity-90 pb-40 pt-4",
                        children: [(0, s.jsx)("div", {
                            className: "flex flex-col justify-start items-start lg:w-[328px]",
                            children: (0, s.jsx)(z, {
                                title: "关于 Yomio",
                                description: "ABOUT YOMIO"
                            })
                        }), (0, s.jsx)(M, {})]
                    })
                },
                D = e => {
                    let {
                        title: t,
                        description: a,
                        className: l = ""
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "flex flex-row justify-start items-center ".concat(l, " w-[220px] lg:w-[380px] lg:h-[88px] lg:mt-6 mt-2 py-2 lg:py-0"),
                        style: {
                            backgroundImage: "url('/assets/careers/section-item-bg.webp')",
                            backgroundSize: "100% 100%"
                        },
                        children: (0, s.jsxs)("div", {
                            className: "h-full flex flex-col justify-center items-start pl-4 w-full",
                            children: [(0, s.jsx)("span", {
                                className: "text-white text-base lg:text-xl font-bold font-source-han-sans-sc-medium",
                                children: t
                            }), (0, s.jsx)("span", {
                                className: "text-white text-xs mt-2 font-source-han-sans-sc-medium",
                                children: a
                            })]
                        })
                    })
                },
                R = [{
                    title: "美术表现类",
                    description: "资深美术（角色）、资深美术（场景）、游戏UI设计师、Spine动画师"
                }, {
                    title: "产品策划类",
                    description: "游戏策划（文案）、游戏策划（系统/数值/战斗）、大模型产品经理"
                }, {
                    title: "游戏研发类",
                    description: "Unity客户端开发、游戏声效、大模型应用算法工程师"
                }],
                Y = () => {
                    let e = {
                            hidden: {
                                opacity: 0,
                                x: 250
                            },
                            visible: e => ({
                                opacity: 1,
                                x: 0,
                                transition: {
                                    delay: .3 + .4 * e,
                                    duration: .8,
                                    ease: "easeInOut"
                                }
                            })
                        },
                        t = R.map((t, a) => (0, s.jsx)(p.E.div, {
                            custom: a,
                            initial: "hidden",
                            animate: "visible",
                            variants: e,
                            className: " w-3/5",
                            children: (0, s.jsx)(D, {
                                title: t.title,
                                description: t.description
                            })
                        }, a));
                    return (0, s.jsxs)("section", {
                        className: "flex flex-col justify-start items-start w-full mt-36 lg:mt-[185px] lg:ml-20 font-source-han-sans-sc-medium",
                        children: [(0, s.jsx)(z, {
                            title: "加入Yomio",
                            description: "JOIN YOMIO"
                        }), (0, s.jsx)("div", {
                            className: "flex flex-col justify-start items-start w-full lg:w-[380px]",
                            children: t
                        }), (0, s.jsx)("div", {
                            className: "hidden  lg:flex flex-row justify-end items-center",
                            children: (0, s.jsx)(v.default, {
                                href: "https://seknhv55ov.feishu.cn/share/base/form/shrcnQnnegJdKm5MnoVTgByUgxc",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "bg-golden text-[#070707] text-sm font-bold py-2 px-4 mt-6 rounded-sm hover:text-white hover:bg-opacity-70",
                                children: "联系我们"
                            })
                        }), (0, s.jsx)("div", {
                            className: " w-8/12 lg:hidden flex flex-row justify-end items-center",
                            children: (0, s.jsx)(v.default, {
                                href: "https://seknhv55ov.feishu.cn/share/base/form/shrcnQnnegJdKm5MnoVTgByUgxc",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "bg-golden text-[#070707] text-sm font-bold py-2 px-4 mt-6 rounded-sm hover:text-white hover:bg-opacity-70",
                                children: "联系我们"
                            })
                        })]
                    })
                },
                U = e => {
                    let {
                        currentSlideId: t
                    } = e;
                    return "about-us" === t ? null : (0, s.jsx)("div", {
                        className: "z-30 h-24 lg:h-[134px] bg-footer-gradient pointer-events-none absolute left-0 bottom-0 w-full border-t border-[#ffffffd9]",
                        children: (0, s.jsx)("div", {
                            className: "footer-transition-bg__bg"
                        })
                    })
                },
                W = [{
                    id: "index",
                    element: (0, s.jsx)(() => {
                        let [e, t] = (0, l.useState)(0), [a, i] = (0, l.useState)(!1);
                        return (0, l.useEffect)(() => {
                            let e = () => {
                                i(window.innerWidth / window.innerHeight < b)
                            };
                            return e(), window.addEventListener("resize", e), () => {
                                window.removeEventListener("resize", e)
                            }
                        }, []), (0, l.useEffect)(() => {
                            if (g.length <= 1) return;
                            let e = window.setInterval(() => {
                                t(e => (e + 1) % g.length)
                            }, 4500);
                            return () => {
                                window.clearInterval(e)
                            }
                        }, []), (0, s.jsxs)("div", {
                            className: "relative flex h-screen w-full items-center justify-start overflow-hidden bg-black",
                            children: [(0, s.jsx)("div", {
                                className: "absolute inset-0 overflow-hidden",
                                children: g.map((t, l) => (0, s.jsx)("img", {
                                    src: t,
                                    alt: "YOMIO 首页轮播图 ".concat(l + 1),
                                    className: "absolute inset-0 h-full w-full object-center transition-opacity duration-[1400ms] ease-out ".concat(a ? "object-contain" : "object-cover", " ").concat(l === e ? "opacity-100" : "opacity-0"),
                                    loading: 0 === l ? "eager" : "lazy"
                                }, t))
                            }), (0, s.jsx)("div", {
                                className: "absolute inset-0 bg-[radial-gradient(circle_at_72%_28%,rgba(212,165,72,0.16),transparent_28%),linear-gradient(90deg,rgba(0,0,0,0.82)_0%,rgba(0,0,0,0.46)_38%,rgba(0,0,0,0.18)_72%,rgba(0,0,0,0.62)_100%)]"
                            }), g.length > 1 ? (0, s.jsx)("div", {
                                className: "absolute bottom-32 right-6 z-10 flex gap-2 lg:bottom-40 lg:right-10",
                                children: g.map((a, l) => (0, s.jsx)("button", {
                                    type: "button",
                                    "aria-label": "切换到第 ".concat(l + 1, " 张首页图"),
                                    onClick: () => t(l),
                                    className: "h-1.5 rounded-full transition-all duration-300 ".concat(l === e ? "w-10 bg-golden" : "w-5 bg-white/45 hover:bg-white/70")
                                }, "".concat(a, "-indicator")))
                            }) : null]
                        })
                    }, {})
                }, {
                    id: "products",
                    element: (0, s.jsx)(() => {
                        let {
                            currentSlideId: e
                        } = m(), [t, a] = (0, l.useState)(!1), [i, n] = (0, l.useState)(null);
                        return (0, l.useEffect)(() => {
                            let e = !0;
                            return (async () => {
                                try {
                                    let t = await fetch("/api/reservations/zeroera/count", {
                                            method: "GET",
                                            cache: "no-store"
                                        }),
                                        a = await t.json();
                                    if (!t.ok || !a.success || !e) return;
                                    n(a.data.count)
                                } catch (e) {}
                            })(), () => {
                                e = !1
                            }
                        }, []), (0, l.useEffect)(() => {
                            "products" !== e && t && a(!1)
                        }, [e, t]), (0, s.jsxs)("div", {
                            className: "relative flex h-screen w-screen flex-col items-start justify-start overflow-hidden bg-black",
                            children: [(0, s.jsxs)("div", {
                                className: "absolute inset-0",
                                children: [(0, s.jsx)("img", {
                                    src: "/assets/products/bg-5.webp",
                                    alt: "赤潮：零纪元海报",
                                    className: "h-full w-full object-cover object-center"
                                }), (0, s.jsx)("div", {
                                    className: "absolute inset-0 bg-[radial-gradient(circle_at_72%_28%,rgba(212,165,72,0.12),transparent_28%),linear-gradient(90deg,rgba(0,0,0,0.82)_0%,rgba(0,0,0,0.48)_38%,rgba(0,0,0,0.14)_72%,rgba(0,0,0,0.58)_100%)]"
                                })]
                            }), (0, s.jsx)("div", {
                                className: "relative z-10 flex h-full w-full items-center px-6 pt-20 lg:px-20",
                                children: (0, s.jsxs)("div", {
                                    className: "max-w-[680px]",
                                    children: [(0, s.jsx)("p", {
                                        className: "font-bender text-xs uppercase tracking-[0.42em] text-golden/80 lg:text-sm",
                                        children: "Scarlet Tide: ZeroERA"
                                    }), (0, s.jsx)("h1", {
                                        className: "mt-4 whitespace-nowrap text-[38px] font-oswald-heavy leading-[0.94] text-white lg:text-[92px]",
                                        children: "赤潮：零纪元"
                                    }), (0, s.jsx)("p", {
                                        className: "mt-5 max-w-[420px] text-sm leading-6 text-white/78 lg:text-base",
                                        children: "与正太少年们展开一场奇幻之旅！"
                                    }), null !== i ? (0, s.jsxs)("p", {
                                        className: "mt-4 font-bender text-sm uppercase tracking-[0.18em] text-golden lg:text-base",
                                        children: [i.toLocaleString("en-US"), " Reservations"]
                                    }) : null, (0, s.jsx)("button", {
                                        type: "button",
                                        onClick: () => a(!0),
                                        className: "mt-8 inline-flex min-w-[176px] items-center justify-center rounded-sm border border-golden bg-golden px-7 py-3 text-base font-source-han-sans-sc-heavy text-black transition hover:bg-[#f2c96d] lg:min-w-[204px] lg:text-lg",
                                        children: "立即预约 / RESERVE NOW"
                                    })]
                                })
                            }), (0, s.jsx)(O, {
                                isOpen: t,
                                onClose: () => a(!1),
                                onSubmitted: e => {
                                    "number" == typeof e && n(e)
                                }
                            }), (0, s.jsx)(A, {})]
                        })
                    }, {})
                }, {
                    id: "about-us",
                    element: (0, s.jsx)(() => (0, s.jsxs)("div", {
                        className: "w-full h-full flex flex-col justify-start items-start",
                        children: [(0, s.jsx)("div", {
                            className: "absolute top-0 left-0  lg:h-24 lg:bg-black w-full "
                        }), (0, s.jsx)("div", {
                            className: "hidden w-screen h-screen lg:flex flex-col justify-start items-start bg-cover bg-center bg-black",
                            style: {
                                backgroundImage: "url(/assets/about-us/background.webp)",
                                backgroundPosition: "center -72px"
                            },
                            children: (0, s.jsxs)("div", {
                                className: "w-full flex flex-row justify-start items-start lg:pt-24",
                                children: [(0, s.jsx)("div", {
                                    className: "flex-none",
                                    children: (0, s.jsx)(F, {})
                                }), (0, s.jsx)("div", {
                                    id: "tran",
                                    className: "flex-grow h-screen ",
                                    children: (0, s.jsx)("div", {
                                        className: "absolute inset-0 left-[408px]",
                                        style: {
                                            background: "radial-gradient(circle, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.5) 50%, rgba(0, 0, 0, 1) 100%)"
                                        }
                                    })
                                })]
                            })
                        }), (0, s.jsx)(_, {}), (0, s.jsx)(A, {})]
                    }), {})
                }, {
                    id: "careers",
                    element: (0, s.jsx)(() => (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("div", {
                            className: "hidden h-screen lg:flex flex-row items-start justify-start  w-full bg-cover bg-center bg-careers-bg",
                            children: (0, s.jsx)(Y, {})
                        }), (0, s.jsx)("div", {
                            className: "lg:hidden h-screen flex flex-row items-start justify-start  w-full bg-cover bg-center bg-careers-bg-mobile",
                            children: (0, s.jsx)(Y, {})
                        }), (0, s.jsx)(U, {
                            currentSlideId: "careers"
                        }), (0, s.jsx)(A, {})]
                    }), {})
                }],
                B = e => {
                    let {
                        currentSlideId: t,
                        setIsAnimating: a
                    } = e, [i, n] = (0, l.useState)(null);
                    (0, l.useEffect)(() => {
                        i !== t && (a(!0), n(t))
                    }, [t, i, a]);
                    let r = W.filter(e => e.id === t || e.id === i);
                    return (0, s.jsx)("div", {
                        className: "absolute left-0 top-0 w-screen flex flex-row justify-start items-start",
                        children: r.map(e => {
                            let l = t === e.id,
                                n = i === e.id;
                            return (0, s.jsx)(p.E.div, {
                                initial: {
                                    width: l ? "0%" : n ? "100%" : "0%",
                                    zIndex: l ? 1 : 0
                                },
                                animate: {
                                    width: l ? "100%" : "0%",
                                    zIndex: l ? 2 : 1
                                },
                                transition: {
                                    duration: 1,
                                    ease: "easeInOut"
                                },
                                onAnimationComplete: () => {
                                    n && a(!1)
                                },
                                className: "flex-shrink-0 flex items-center justify-center text-3xl text-white font-bold",
                                style: {
                                    width: "100vw",
                                    height: "100vh",
                                    overflow: "hidden"
                                },
                                children: e.element
                            }, e.id)
                        })
                    })
                },
                V = e => {
                    let {
                        isLoading: t,
                        currentSlideId: a
                    } = e, [i, n] = (0, l.useState)(!1);
                    return (0, l.useEffect)(() => {
                        t || "products" === a || "about-us" === a ? n(!1) : n(!0)
                    }, [t, a]), (0, s.jsx)(p.E.div, {
                        className: "hidden lg:flex h-screen absolute z-10 border-l border-white-50 bg-opacity-50 w-[1px] right-48 top-0",
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: i ? 1 : 0
                        },
                        exit: {
                            opacity: 0
                        },
                        transition: {
                            duration: 1
                        }
                    })
                },
                q = e => {
                    let {
                        isLoading: t,
                        currentSlideId: a
                    } = e, [i, n] = (0, l.useState)(!1);
                    return (0, l.useEffect)(() => {
                        t || "products" === a || "about-us" === a ? n(!1) : n(!0)
                    }, [t, a]), (0, s.jsx)(p.E.div, {
                        className: "lg:hidden md:hidden h-screen absolute z-10 border-l border-white-50 bg-opacity-50 w-[1px]  right-12 top-0",
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: i ? 1 : 0
                        },
                        exit: {
                            opacity: 0
                        },
                        transition: {
                            duration: 1
                        }
                    })
                },
                X = e => {
                    let {
                        isLoading: t,
                        currentSlideId: a
                    } = e;
                    return t || "about-us" === a ? null : (0, s.jsx)("div", {
                        "data-global-scroll-ui": "true",
                        className: "w-full flex flex-col justify-center items-center lg:h-16 h-4 fixed left-0 bottom-16 lg:bottom-12 z-50",
                        children: (0, s.jsx)("img", {
                            src: "/assets/common/scroll-arrow.webp",
                            alt: "scroll arrow",
                            className: "animate-bounce-and-fade w-8 h-6 lg:w-12 lg:h-9"
                        })
                    })
                },
                G = [{
                    id: "index",
                    name: "INDEX",
                    zhName: "首页",
                    link: "/#index",
                    isActived: !1
                }, {
                    id: "products",
                    name: "PRODUCTS",
                    zhName: "产品",
                    link: "/#products",
                    isActived: !1
                }, {
                    id: "about-us",
                    name: "ABOUT US",
                    zhName: "关于我们",
                    link: "/#about-us",
                    isActived: !1
                }, {
                    id: "careers",
                    name: "CAREERS",
                    zhName: "加入我们",
                    link: "/#careers",
                    isActived: !1
                }],
                H = e => {
                    let {
                        isLoading: t,
                        slash: a,
                        markerText: l,
                        menuItemName: i,
                        animationDuration: n,
                        isMovingDown: r
                    } = e;
                    return (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsxs)("div", {
                            className: "hidden lg:flex lg:flex-row lg:justify-start lg:items-end",
                            children: [(0, s.jsx)("div", {
                                className: "lg:overflow-hidden lg:h-[40px]",
                                children: t ? (0, s.jsx)("div", {
                                    className: "lg:font-extrabold lg:text-[54px] lg:text-golden lg:leading-[54px] lg:text-right lg:font-source-han-sans-sc-heavy",
                                    children: l
                                }) : (0, s.jsx)(p.E.div, {
                                    className: "lg:font-extrabold lg:text-[54px] lg:text-golden lg:leading-[54px] lg:text-right lg:font-source-han-sans-sc-heavy",
                                    initial: {
                                        y: r ? 50 : -50,
                                        opacity: 0
                                    },
                                    animate: {
                                        y: 0,
                                        opacity: 1
                                    },
                                    exit: {
                                        y: r ? -50 : 50,
                                        opacity: 0
                                    },
                                    transition: {
                                        duration: n,
                                        delay: 0
                                    },
                                    children: l
                                }, l)
                            }), t ? (0, s.jsxs)("div", {
                                className: "lg:font-bender lg:text-white",
                                children: [a, a, l, "/04"]
                            }) : (0, s.jsxs)(p.E.div, {
                                className: "lg:font-bender lg:text-white",
                                initial: {
                                    y: r ? 50 : -50,
                                    opacity: 0
                                },
                                animate: {
                                    y: 0,
                                    opacity: 1
                                },
                                exit: {
                                    y: r ? -50 : 50,
                                    opacity: 0
                                },
                                transition: {
                                    duration: n,
                                    delay: .1
                                },
                                children: [a, a, l, "/04"]
                            }, "".concat(l, "-slash"))]
                        }), t ? (0, s.jsx)("div", {
                            className: "hidden lg:w-full lg:flex lg:flex-row lg:justify-end lg:items-center lg:font-extrabold lg:text-[14px] lg:text-white lg:leading-[14px] lg:text-center lg:uppercase lg:font-source-han-sans-sc-medium",
                            children: i
                        }) : (0, s.jsx)(p.E.div, {
                            className: "hidden lg:w-full lg:flex lg:flex-row lg:justify-end lg:items-center lg:font-extrabold lg:text-[14px] lg:text-white lg:leading-[14px] lg:text-center lg:uppercase lg:font-source-han-sans-sc-medium",
                            initial: {
                                y: r ? 50 : -50,
                                opacity: 0
                            },
                            animate: {
                                y: 0,
                                opacity: 1
                            },
                            exit: {
                                y: r ? -50 : 50,
                                opacity: 0
                            },
                            transition: {
                                duration: n,
                                delay: .2
                            },
                            children: i
                        }, i)]
                    })
                },
                K = e => {
                    let {
                        isLoading: t,
                        slash: a,
                        markerText: l,
                        menuItemName: i,
                        animationDuration: n,
                        isMovingDown: r
                    } = e;
                    return t ? null : (0, s.jsxs)("div", {
                        className: "overflow-hidden lg:hidden relative w-10 h-20 font-source-han-sans-sc-heavy right-0",
                        children: [(0, s.jsxs)(p.E.div, {
                            className: "text-white font-bender text-base absolute top-0 left-10 leading-6",
                            initial: {
                                rotate: 90,
                                transformOrigin: "top left",
                                opacity: 0,
                                y: r ? 50 : -50
                            },
                            animate: {
                                rotate: 90,
                                opacity: 1,
                                y: 0
                            },
                            exit: {
                                rotate: 90,
                                opacity: 0,
                                y: r ? -50 : 50
                            },
                            transition: {
                                duration: n,
                                delay: 0
                            },
                            children: [a, a, l, "/04"]
                        }), (0, s.jsx)(p.E.div, {
                            className: "text-white text-xs h-4 absolute top-0 left-5 whitespace-nowrap",
                            initial: {
                                rotate: 90,
                                transformOrigin: "top left",
                                opacity: 0,
                                y: r ? 50 : -50
                            },
                            animate: {
                                rotate: 90,
                                opacity: 1,
                                y: 0
                            },
                            exit: {
                                rotate: 90,
                                opacity: 0,
                                y: r ? -50 : 50
                            },
                            transition: {
                                duration: n,
                                delay: 0
                            },
                            children: i
                        }), (0, s.jsx)(p.E.div, {
                            className: "absolute -bottom-3 text-golden text-4xl font-extrabold",
                            initial: {
                                y: r ? 50 : -50,
                                opacity: 0
                            },
                            animate: {
                                y: 0,
                                opacity: 1
                            },
                            exit: {
                                y: r ? -50 : 50,
                                opacity: 0
                            },
                            transition: {
                                duration: n,
                                delay: 0
                            },
                            children: l
                        }, l)]
                    })
                },
                J = e => {
                    let t = G.findIndex(t => t.id === e),
                        a = "0".concat(t + 1).slice(-2);
                    return "".concat(a)
                },
                Q = e => {
                    let t = G.find(t => t.id === e);
                    return t ? t.name : ""
                },
                Z = e => {
                    let {
                        isLoading: t,
                        currentSlideId: a
                    } = e, i = (0, l.useMemo)(() => J(a), [a]), n = (0, l.useMemo)(() => Q(a), [a]);
                    t && (i = "00", n = "Loading");
                    let [r, o] = (0, l.useState)(null), c = (0, l.useMemo)(() => G.findIndex(e => e.id === a), [a]), d = null !== r && c > r;
                    return ((0, l.useEffect)(() => {
                        o(c)
                    }, [a]), "about-us" === a) ? null : (0, s.jsxs)("div", {
                        "data-global-scroll-ui": "true",
                        className: "absolute right-0 lg:right-7 bottom-64 lg:bottom-11 lg:flex lg:flex-col lg:justify-center lg:items-start z-50  ",
                        children: [(0, s.jsx)(H, {
                            isLoading: t,
                            slash: "/",
                            markerText: i,
                            menuItemName: n,
                            animationDuration: 1,
                            isMovingDown: d
                        }), (0, s.jsx)(K, {
                            isLoading: t,
                            slash: "/",
                            markerText: i,
                            menuItemName: n,
                            animationDuration: 1,
                            isMovingDown: d
                        })]
                    })
                },
                $ = e => {
                    let {
                        setIsLoading: t,
                        progress: a
                    } = e;
                    return (0, s.jsxs)("div", {
                        className: "w-screen h-screen fixed top-0 left-0 bg-pri z-50 flex flex-col justify-center items-center  text-golden pointer-events-none bg-black",
                        children: [(0, s.jsx)("div", {
                            className: "w-2/3 lg:w-1/2 h-[192px] flex justify-center items-center pointer-events-none",
                            children: (0, s.jsx)("img", {
                                src: "/assets/loading/loading-logo@x2.webp",
                                alt: "loading",
                                style: {
                                    width: "auto",
                                    height: "auto"
                                }
                            })
                        }), (0, s.jsxs)("div", {
                            id: "loading-status",
                            className: "flex flex-col justify-start items-center",
                            children: [(0, s.jsxs)("div", {
                                className: "flex flex-row justify-start items-center h-28 text-golden font-bender",
                                children: [(0, s.jsx)("img", {
                                    src: "/assets/loading/right-arrow.webp",
                                    alt: "arrow",
                                    width: 28,
                                    height: 28,
                                    style: {
                                        objectFit: "contain"
                                    }
                                }), (0, s.jsxs)("span", {
                                    children: ["LOADING ", Math.round(100 * a), "%"]
                                })]
                            }), (0, s.jsxs)("div", {
                                id: "loading-bar",
                                className: "relative w-full lg:w-[500px] h-12 flex justify-between items-center lg:mt-[120px]",
                                children: [(0, s.jsx)("div", {
                                    className: "w-3 h-3 bg-[#939393]"
                                }), (0, s.jsx)("div", {
                                    className: "absolute top-1/2 left-3 right-3 transform -translate-y-1/2 h-1 bg-[#939393]",
                                    children: (0, s.jsx)("div", {
                                        className: "absolute top-1/2 transform -translate-y-1/2 h-3 bg-golden",
                                        style: {
                                            width: "".concat(100 * a, "%")
                                        }
                                    })
                                }), (0, s.jsx)("div", {
                                    className: "w-3 h-3 bg-[#939393]"
                                })]
                            })]
                        })]
                    })
                },
                ee = () => {
                    let {
                        currentSlideId: e,
                        isLoading: t
                    } = m(), [a, i] = (0, l.useState)(!1);
                    return (0, l.useEffect)(() => {
                        t || i(!0)
                    }, [t]), (0, s.jsx)(p.E.div, {
                        initial: {
                            y: a && "index" === e ? 0 : "100%"
                        },
                        animate: {
                            y: "index" === e ? 0 : "100%"
                        },
                        transition: {
                            duration: 1
                        },
                        "data-global-footer": "true",
                        className: "w-screen h-24 lg:h-[134px] absolute left-0 bottom-0 border-t border-[#ffffffd9] z-30",
                        children: (0, s.jsxs)("div", {
                            className: "flex flex-col justify-start items-start lg:pl-16 pl-4 h-24 lg:h-[134px] absolute bottom-0 w-screen z-30",
                            children: [(0, s.jsx)("h1", {
                                className: "font-extrabold lg:text-4xl text-2xl text-white  text-left font-oswald-heavy mt-2",
                                children: "YOMIO"
                            }), (0, s.jsx)("h2", {
                                className: "text-white font-medium text-xs mt-1 lg:mt-0 lg:text-xl text-right lg:leading-1 font-regular font-source-han-sans-sc-heavy",
                                children: "\xa92024YoMioBEYOUNG"
                            }), (0, s.jsx)("a", {
                                href: "https://beian.miit.gov.cn",
                                target: "_blank",
                                className: "text-white font-medium",
                                children: "京ICP备2024070889号-1"
                            })]
                        })
                    })
                },
                et = e => {
                    let {
                        currentSlideId: t
                    } = e;
                    return "products" === t || "about-us" === t ? null : (0, s.jsx)(f.M, {
                        children: (0, s.jsx)(p.E.div, {
                            className: "hidden md:block lg:block absolute right-48 h-screen w-64 overflow-hidden z-10 opacity-30 -mr-2",
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .5,
                                ease: "easeInOut"
                            },
                            children: (0, s.jsx)("div", {
                                className: "w-full h-full user-select-none",
                                children: (0, s.jsxs)(p.E.div, {
                                    className: "flex flex-col items-center h-[200%] opacity-30 hover:opacity-50 transition-opacity duration-300",
                                    initial: {
                                        y: "0%"
                                    },
                                    animate: {
                                        y: "-50%"
                                    },
                                    transition: {
                                        duration: 20,
                                        repeat: 1 / 0,
                                        ease: "linear"
                                    },
                                    children: [(0, s.jsx)("div", {
                                        className: "text-9xl font-black text-golden transform -rotate-90",
                                        children: "YOMIOBEYONGYOMIOBEYONGYOMIOBEYONGYOMIOBEYONGYOMIOBEYONG"
                                    }), (0, s.jsx)("div", {
                                        className: "text-3xl font-black text-golden transform -rotate-90 ml-36",
                                        children: "//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"
                                    })]
                                })
                            })
                        }, "scrolling-text")
                    })
                },
                ea = e => {
                    let {
                        currentSlideId: t
                    } = e;
                    return null
                },
                es = () => {
                    let {
                        currentSlideId: e,
                        updateSlideId: t,
                        isAnimating: a,
                        setIsAnimating: l,
                        isLoading: i,
                        setIsLoading: n,
                        progress: r
                    } = m();
                    return (0, s.jsxs)("div", {
                        className: "w-screen",
                        children: [(0, s.jsx)(f.M, {
                            children: i ? (0, s.jsx)(p.E.div, {
                                initial: {
                                    opacity: 1
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                transition: {
                                    duration: 2
                                },
                                className: "absolute inset-0 flex items-center justify-center bg-white",
                                children: (0, s.jsx)($, {
                                    setIsLoading: n,
                                    progress: r
                                })
                            }, "loading") : (0, s.jsxs)(p.E.div, {
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                transition: {
                                    duration: 2
                                },
                                className: "w-full h-full",
                                children: [(0, s.jsx)(B, {
                                    currentSlideId: e,
                                    setIsAnimating: l
                                }), (0, s.jsx)(V, {
                                    isLoading: i,
                                    currentSlideId: e
                                }), (0, s.jsx)(q, {
                                    isLoading: i,
                                    currentSlideId: e
                                }), (0, s.jsx)(X, {
                                    isLoading: i,
                                    currentSlideId: e
                                })]
                            }, "content")
                        }), !i && (0, s.jsx)(ee, {}), (0, s.jsx)(et, {
                            currentSlideId: e
                        }), (0, s.jsx)(ea, {
                            currentSlideId: e
                        }), (0, s.jsx)(Z, {
                            isLoading: i,
                            currentSlideId: e
                        })]
                    })
                },
                el = () => (0, s.jsx)(v.default, {
                    href: "/",
                    onClick: () => {
                        window && (window.location.href = "/")
                    },
                    children: (0, s.jsx)("img", {
                        src: "/assets/common/logo/logo@2x.webp",
                        alt: "logo",
                        className: "lg:ml-4 ml-2 lg:w-32 lg:h-12 w-24 h-9"
                    })
                }),
                ei = e => {
                    let {
                        currentSlideId: t,
                        updateSlideId: a
                    } = e;
                    return (0, s.jsx)("div", {
                        className: "hidden lg:flex flex-row items-center justify-between space-x-12 h-full mr-8 z-50",
                        children: G.map(e => (0, s.jsxs)(v.default, {
                            href: e.link,
                            className: "text-base hover:text-golden flex flex-col justify-start items-start ".concat(t === e.id ? "text-golden" : "text-white", " "),
                            onClick: () => {
                                n(e.id), a(e.id)
                            },
                            children: [(0, s.jsx)("h2", {
                                className: "font-oswald-heavy",
                                children: e.name
                            }), (0, s.jsx)("h2", {
                                className: "source-han-sans-sc-heavy",
                                children: e.zhName
                            })]
                        }, e.id))
                    })
                },
                en = e => {
                    window.location.hash = e
                },
                er = e => {
                    let {
                        currentSlideId: t,
                        updateSlideId: a
                    } = e, [i, n] = (0, l.useState)(!1);
                    return (0, s.jsxs)("div", {
                        className: "fixed right-0 top-0 lg:hidden md:hidden flex flex-col justify-center items-center z-50 w-12 h-full",
                        children: [(0, s.jsx)("div", {
                            onClick: () => {
                                n(!i)
                            },
                            className: "cursor-pointer p-2  rounded-md w-12",
                            children: i ? (0, s.jsx)("div", {
                                className: "text-white text-2xl font-bold",
                                children: "X"
                            }) : (0, s.jsxs)("div", {
                                className: "flex flex-col justify-center space-y-1.5 items-center h-6 w-6",
                                children: [(0, s.jsx)("span", {
                                    className: "block h-0.5 bg-white w-10/12"
                                }), (0, s.jsx)("span", {
                                    className: "block h-0.5 bg-white w-10/12"
                                }), (0, s.jsx)("span", {
                                    className: "block h-0.5 bg-white  w-10/12"
                                })]
                            })
                        }), i && (0, s.jsxs)("div", {
                            className: "fixed left-0 top-20 mb-20 w-screen h-screen flex flex-row justify-start items-start bg-opacity-90 bg-black",
                            children: [(0, s.jsxs)("div", {
                                className: "flex flex-grow flex-col justify-start items-center h-full",
                                children: [(0, s.jsx)("div", {
                                    className: "w-10/12 flex flex-col justify-start items-center",
                                    children: G.map(e => (0, s.jsxs)(v.default, {
                                        href: e.link,
                                        className: "w-full flex justify-between items-center border-b border-white  ".concat(t === e.id ? "text-golden" : "text-white", " h-20"),
                                        onClick: () => {
                                            en(e.id), a(e.id), n(!1)
                                        },
                                        children: [(0, s.jsx)("span", {
                                            className: " font-oswald-medium",
                                            children: e.name
                                        }), (0, s.jsx)("div", {
                                            className: "  h-full flex flex-col justify-center items-center border-b-8  font-source-han-sans-sc-medium ".concat(t === e.id ? "border-golden" : "border-transparent", " mt-2"),
                                            children: e.zhName
                                        })]
                                    }, e.id))
                                }), (0, s.jsx)("div", {
                                    className: "w-16 "
                                })]
                            }), (0, s.jsx)("div", {
                                className: "w-12"
                            })]
                        })]
                    })
                },
                eo = () => {
                    let e = "-100%",
                        {
                            currentSlideId: t,
                            updateSlideId: a,
                            isLoading: l
                        } = m();
                    return l ? null : (0, s.jsx)("div", {
                        className: "w-full h-20 lg:h-24  flex flex-col justify-start items-start",
                        children: (0, s.jsxs)(p.E.div, {
                            className: "w-full h-20 lg:h-24 fixed top-0 left-0 flex flex-row items-center justify-between z-20 bg-gradient-to-b from-black to-transparent",
                            initial: {
                                y: e,
                                opacity: 0
                            },
                            animate: {
                                y: "0%",
                                opacity: 1
                            },
                            exit: {
                                y: e,
                                opacity: 0
                            },
                            transition: {
                                duration: 1
                            },
                            children: [(0, s.jsx)(el, {}), (0, s.jsx)("div", {
                                className: "flex flex-row justify-start items-center lg:py-0 py-2 lg:mr-0 mr-16",
                                children: (0, s.jsx)(ei, {
                                    currentSlideId: t,
                                    updateSlideId: a
                                })
                            }), (0, s.jsx)(p.E.div, {
                                className: "absolute bottom-0 left-0 w-full border-b border-white-50 ".concat("careers" === t ? "lg:border-white-50" : "lg:border-transparent"),
                                initial: {
                                    opacity: 0,
                                    y: "-100%"
                                },
                                animate: {
                                    opacity: 1,
                                    y: "0%"
                                },
                                exit: {
                                    opacity: 0,
                                    y: "-100%"
                                },
                                transition: {
                                    duration: 1
                                }
                            }), (0, s.jsx)(er, {
                                currentSlideId: t,
                                updateSlideId: a
                            })]
                        })
                    })
                };
            var ec = () => (0, s.jsx)(x, {
                children: (0, s.jsxs)("div", {
                    className: "h-screen w-screen",
                    children: [(0, s.jsx)(eo, {}), (0, s.jsx)(es, {})]
                })
            })
        }
    },
    function(e) {
        e.O(0, [194, 971, 23, 744], function() {
            return e(e.s = 7986)
        }), _N_E = e.O()
    }
]);